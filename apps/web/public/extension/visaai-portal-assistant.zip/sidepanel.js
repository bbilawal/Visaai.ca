var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/portal-page.ts
var OPEN_DRAFT = 'open your application with "Continue" on the draft in your IRCC account. Keep this panel open \u2014 the next form page fills automatically.';
var MESSAGES = {
  signin: `Sign in to your IRCC account (you do this \u2014 the assistant never enters passwords), then ${OPEN_DRAFT}`,
  // IRCC shows its terms and sign-in steps at the same address after a
  // sign-out (live 2026-10-17), so this page may still need a sign-in.
  account: `You are on your IRCC account pages. Accept the terms and sign in if IRCC asks (you do this yourself), then ${OPEN_DRAFT}`,
  error: "IRCC showed its error page \u2014 usually an expired session or a bookmarked link. Nothing you saved is lost. Go to your IRCC account, sign in if asked, then " + OPEN_DRAFT,
  yours: "This page is yours: the assistant never fills fees, the declaration, your signature or payment. Complete it on IRCC yourself.",
  language: 'Switch the Permanent Residence Portal to English (the "English" link at the top of the page). The assistant fills its English pages only; nothing is written on a French page.',
  review: 'The questionnaire is done: the assistant stops here. Check every answer on this list (use "Modify my Answers" to correct one), then continue to your document checklist yourself. Uploads, signature and payment are yours.'
};
function isSignIn(host, path) {
  if (host === "portal-portail.apps.cic.gc.ca") return /^\/(signin|sign-in|login|logout)\b/i.test(path);
  if (host === "onlineservices-servicesenligne.cic.gc.ca") return /\/(mycic\/start|signin|login)\b/i.test(path);
  if (host === "ircc.canada.ca") return /\/portal\b/i.test(path);
  if (host === PR_HOST) return /^\/(en|fr)\/(login|logout)\b/i.test(path);
  return /(^|\.)clegc-gckey\.gc\.ca$/.test(host);
}
var YOURS = /^\/(fees?|pay|payment|consent|declaration|e-?sign|signature|complete|confirmation|submit)(\/|$|-)/i;
var PR_HOST = "prson-srpel.apps.cic.gc.ca";
var PR_YOURS = /\/(fee|fees|payment|declaration|consent|submit|submission)(\/|$|-)/i;
var EAPP_HOST = "onlineservices-servicesenligne.cic.gc.ca";
var EAPP_AFTER = /^\/eapp\/(comeToCanadaReviewPage|previousAnswers|comeToCanadaInstructions|documentsToSubmit|comeToCanadaResult|comeToCanadaHowToApply)\b/i;
function isServerPagedUrl(url2) {
  try {
    const u = new URL(url2 ?? "");
    return u.hostname.toLowerCase() === EAPP_HOST && /^\/eapp\/eapp\/?$/i.test(u.pathname);
  } catch {
    return false;
  }
}
function isEappEditUrl(url2) {
  try {
    return isServerPagedUrl(url2) && new URL(url2 ?? "").searchParams.has("modifyCaller");
  } catch {
    return false;
  }
}
function followPageKey(url2) {
  let u;
  try {
    u = new URL(url2 ?? "");
  } catch {
    return null;
  }
  const pageId = u.hostname.toLowerCase() === PR_HOST ? u.searchParams.get("pageId") : null;
  return pageId ? `${u.pathname}?pageId=${pageId}` : u.pathname;
}
var FLOW_OF_PORTAL = {
  ircc: "trrt",
  "ircc-eta": "eta",
  "ircc-study": "eapp",
  "ircc-work": "eapp",
  "ircc-pr-family": "pr"
};
var GO_TO = {
  trrt: "This visa is applied for on the IRCC Portal \u2014 sign in at portal-portail.apps.cic.gc.ca and start or continue your visitor visa application.",
  eta: "An eTA is applied for on its own IRCC form \u2014 open onlineservices-servicesenligne.cic.gc.ca/eta/welcome and start or continue your eTA application there.",
  eapp: 'This permit is applied for in your IRCC secure account \u2014 sign in, choose "Apply to come to Canada" and answer the eligibility questionnaire there.',
  pr: "This application is made on the IRCC Permanent Residence Portal \u2014 sign in at prson-srpel.apps.cic.gc.ca and open your application there."
};
var WRONG_PAGE = " This tab is on a different IRCC application, so the assistant fills nothing here. Keep this panel open \u2014 the right page fills automatically once you open it.";
function flowOfUrl(host, path) {
  if (host === "tr-rt.apps.cic.gc.ca") return "trrt";
  if (host === PR_HOST) return "pr";
  if (host === "eta.onlineservices-servicesenligne.apps.cic.gc.ca") return "eta";
  if (host === EAPP_HOST && /^\/eta\//i.test(path)) return "eta";
  if (host === EAPP_HOST && /^\/eapp\//i.test(path)) return "eapp";
  return null;
}
function classifyPortalPage(url2, portalId) {
  const page = classifyUnscoped(url2);
  const expected = portalId ? FLOW_OF_PORTAL[portalId] : void 0;
  if (!expected) return page;
  let u;
  try {
    u = new URL(url2 ?? "");
  } catch {
    return page;
  }
  const flow = flowOfUrl(u.hostname.toLowerCase(), u.pathname);
  if (flow && flow !== expected) return { kind: "wrong-portal", message: GO_TO[expected] + WRONG_PAGE };
  return page;
}
function classifyUnscoped(url2) {
  let u;
  try {
    u = new URL(url2 ?? "");
  } catch {
    return { kind: "form" };
  }
  const host = u.hostname.toLowerCase();
  const path = u.pathname;
  if (isSignIn(host, path)) return { kind: "signin", message: MESSAGES.signin };
  if (host === "portal-portail.apps.cic.gc.ca") return { kind: "account", message: MESSAGES.account };
  if (host === EAPP_HOST && EAPP_AFTER.test(path)) return { kind: "review", message: MESSAGES.review };
  if (host === PR_HOST) {
    if (/^\/(en|fr)\/application\/(dashboard|start)\b/i.test(path)) return { kind: "account", message: MESSAGES.account };
    if (PR_YOURS.test(path)) return { kind: "yours", message: MESSAGES.yours };
    if (/^\/fr\//i.test(path)) return { kind: "language", message: MESSAGES.language };
  }
  if (host === "tr-rt.apps.cic.gc.ca") {
    if (/^\/error\b/i.test(path)) return { kind: "error", message: MESSAGES.error };
    if (path === "/" || /^\/landing-page\b/i.test(path)) return { kind: "account", message: MESSAGES.account };
    if (YOURS.test(path)) return { kind: "yours", message: MESSAGES.yours };
  }
  return { kind: "form" };
}

// src/portal-tab.ts
var PORTAL_HOSTS = [/\.cic\.gc\.ca$/, /\.canada\.ca$/, /^cic\.gc\.ca$/, /^canada\.ca$/];
function isPortalUrl(url2) {
  if (!url2) return false;
  try {
    const u = new URL(url2);
    return u.protocol === "https:" && PORTAL_HOSTS.some((re2) => re2.test(u.hostname));
  } catch {
    return false;
  }
}
function pickActivePortalTab(tabs) {
  const active = tabs.find((t) => t.active);
  return active?.id != null && isPortalUrl(active.url) ? active.id : null;
}

// src/executor/row-match.ts
var ROW_FILLER = /* @__PURE__ */ new Set(["since", "born", "the", "and", "of", "to", "at", "now"]);
function rowSummaryPresent(summary, rows) {
  const norm = (t) => t.toLowerCase().replace(/[^a-z0-9\-]+/g, " ");
  const words = norm(summary).split(/\s+/).filter((w) => w.length >= 2 && !ROW_FILLER.has(w) && w !== "-");
  if (words.length < 2) return false;
  const need = /* @__PURE__ */ new Map();
  for (const w of words) need.set(w, (need.get(w) ?? 0) + 1);
  return rows.some((r) => {
    const have = /* @__PURE__ */ new Map();
    for (const w of norm(r).split(/\s+/)) have.set(w, (have.get(w) ?? 0) + 1);
    return [...need].every(([w, n]) => (have.get(w) ?? 0) >= n);
  });
}

// src/executor/stale-rows.ts
function staleRows(pageRows, reviewedSummaries) {
  if (reviewedSummaries.length === 0) return [];
  return pageRows.filter((r) => /\bdelete\b/i.test(r)).map(
    (r) => r.replace(/\b(edit|delete_forever|delete)\b/gi, " ").replace(/\s+/g, " ").trim()
  ).filter((r) => r !== "" && !reviewedSummaries.some((s) => rowSummaryPresent(s, [r])));
}

// src/executor/file-attach.ts
var UPLOAD_MAX_BYTES = 5 * 1024 * 1024;
var PR_CASE_PAGE = /^\/(?:en|fr)\/application\/case\/\d+\/?$/i;
function onPrCasePage(path = location.pathname) {
  return PR_CASE_PAGE.test(path);
}

// src/trrt-pages.ts
var TRRT_HOST = "tr-rt.apps.cic.gc.ca";
var AUTO_ADVANCE_PAGES = Object.freeze([
  "/group-questions",
  "/purpose",
  "/special-event-code",
  "/representative",
  "/bio-data",
  "/bio-data-travel-docs",
  "/nationality",
  "/national-id-doc",
  "/other-names",
  "/contact-info",
  "/minors-guardian",
  "/biometrics",
  "/inviter-info",
  "/finances",
  "/activities",
  "/travel-history",
  "/validity-status",
  "/crime-activity",
  "/security-questions",
  "/medical-background-questions",
  "/medical-tuberculosis",
  "/medical-questions",
  "/family-info",
  "/family-info-children",
  "/family-info-parents",
  "/language",
  "/contact-info-email",
  "/contact-info-tel"
]);
function isAutoAdvancePath(path) {
  if (typeof path !== "string") return false;
  const p = path.replace(/\/+$/, "") || "/";
  return AUTO_ADVANCE_PAGES.includes(p.toLowerCase());
}
function isAutoAdvanceUrl(url2) {
  try {
    const u = new URL(url2 ?? "");
    return u.protocol === "https:" && u.hostname.toLowerCase() === TRRT_HOST && isAutoAdvancePath(u.pathname);
  } catch {
    return false;
  }
}
function isTrrtSummaryUrl(url2) {
  try {
    const u = new URL(url2 ?? "");
    return u.hostname.toLowerCase() === TRRT_HOST && /^\/summary(\/|$|-)/i.test(u.pathname);
  } catch {
    return false;
  }
}
function isTrrtInfoUrl(url2) {
  try {
    const u = new URL(url2 ?? "");
    return u.protocol === "https:" && u.hostname.toLowerCase() === TRRT_HOST && /^\/application-type\/[a-z0-9-]+\/?$/i.test(u.pathname);
  } catch {
    return false;
  }
}

// ../../node_modules/.pnpm/engine.io-parser@5.2.3/node_modules/engine.io-parser/build/esm/commons.js
var PACKET_TYPES = /* @__PURE__ */ Object.create(null);
PACKET_TYPES["open"] = "0";
PACKET_TYPES["close"] = "1";
PACKET_TYPES["ping"] = "2";
PACKET_TYPES["pong"] = "3";
PACKET_TYPES["message"] = "4";
PACKET_TYPES["upgrade"] = "5";
PACKET_TYPES["noop"] = "6";
var PACKET_TYPES_REVERSE = /* @__PURE__ */ Object.create(null);
Object.keys(PACKET_TYPES).forEach((key) => {
  PACKET_TYPES_REVERSE[PACKET_TYPES[key]] = key;
});
var ERROR_PACKET = { type: "error", data: "parser error" };

// ../../node_modules/.pnpm/engine.io-parser@5.2.3/node_modules/engine.io-parser/build/esm/encodePacket.browser.js
var withNativeBlob = typeof Blob === "function" || typeof Blob !== "undefined" && Object.prototype.toString.call(Blob) === "[object BlobConstructor]";
var withNativeArrayBuffer = typeof ArrayBuffer === "function";
var isView = (obj) => {
  return typeof ArrayBuffer.isView === "function" ? ArrayBuffer.isView(obj) : obj && obj.buffer instanceof ArrayBuffer;
};
var encodePacket = ({ type, data }, supportsBinary, callback) => {
  if (withNativeBlob && data instanceof Blob) {
    if (supportsBinary) {
      return callback(data);
    } else {
      return encodeBlobAsBase64(data, callback);
    }
  } else if (withNativeArrayBuffer && (data instanceof ArrayBuffer || isView(data))) {
    if (supportsBinary) {
      return callback(data);
    } else {
      return encodeBlobAsBase64(new Blob([data]), callback);
    }
  }
  return callback(PACKET_TYPES[type] + (data || ""));
};
var encodeBlobAsBase64 = (data, callback) => {
  const fileReader = new FileReader();
  fileReader.onload = function() {
    const content = fileReader.result.split(",")[1];
    callback("b" + (content || ""));
  };
  return fileReader.readAsDataURL(data);
};
function toArray(data) {
  if (data instanceof Uint8Array) {
    return data;
  } else if (data instanceof ArrayBuffer) {
    return new Uint8Array(data);
  } else {
    return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
  }
}
var TEXT_ENCODER;
function encodePacketToBinary(packet, callback) {
  if (withNativeBlob && packet.data instanceof Blob) {
    return packet.data.arrayBuffer().then(toArray).then(callback);
  } else if (withNativeArrayBuffer && (packet.data instanceof ArrayBuffer || isView(packet.data))) {
    return callback(toArray(packet.data));
  }
  encodePacket(packet, false, (encoded) => {
    if (!TEXT_ENCODER) {
      TEXT_ENCODER = new TextEncoder();
    }
    callback(TEXT_ENCODER.encode(encoded));
  });
}

// ../../node_modules/.pnpm/engine.io-parser@5.2.3/node_modules/engine.io-parser/build/esm/contrib/base64-arraybuffer.js
var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
var lookup = typeof Uint8Array === "undefined" ? [] : new Uint8Array(256);
for (let i = 0; i < chars.length; i++) {
  lookup[chars.charCodeAt(i)] = i;
}
var decode = (base64) => {
  let bufferLength = base64.length * 0.75, len = base64.length, i, p = 0, encoded1, encoded2, encoded3, encoded4;
  if (base64[base64.length - 1] === "=") {
    bufferLength--;
    if (base64[base64.length - 2] === "=") {
      bufferLength--;
    }
  }
  const arraybuffer = new ArrayBuffer(bufferLength), bytes = new Uint8Array(arraybuffer);
  for (i = 0; i < len; i += 4) {
    encoded1 = lookup[base64.charCodeAt(i)];
    encoded2 = lookup[base64.charCodeAt(i + 1)];
    encoded3 = lookup[base64.charCodeAt(i + 2)];
    encoded4 = lookup[base64.charCodeAt(i + 3)];
    bytes[p++] = encoded1 << 2 | encoded2 >> 4;
    bytes[p++] = (encoded2 & 15) << 4 | encoded3 >> 2;
    bytes[p++] = (encoded3 & 3) << 6 | encoded4 & 63;
  }
  return arraybuffer;
};

// ../../node_modules/.pnpm/engine.io-parser@5.2.3/node_modules/engine.io-parser/build/esm/decodePacket.browser.js
var withNativeArrayBuffer2 = typeof ArrayBuffer === "function";
var decodePacket = (encodedPacket, binaryType) => {
  if (typeof encodedPacket !== "string") {
    return {
      type: "message",
      data: mapBinary(encodedPacket, binaryType)
    };
  }
  const type = encodedPacket.charAt(0);
  if (type === "b") {
    return {
      type: "message",
      data: decodeBase64Packet(encodedPacket.substring(1), binaryType)
    };
  }
  const packetType = PACKET_TYPES_REVERSE[type];
  if (!packetType) {
    return ERROR_PACKET;
  }
  return encodedPacket.length > 1 ? {
    type: PACKET_TYPES_REVERSE[type],
    data: encodedPacket.substring(1)
  } : {
    type: PACKET_TYPES_REVERSE[type]
  };
};
var decodeBase64Packet = (data, binaryType) => {
  if (withNativeArrayBuffer2) {
    const decoded = decode(data);
    return mapBinary(decoded, binaryType);
  } else {
    return { base64: true, data };
  }
};
var mapBinary = (data, binaryType) => {
  switch (binaryType) {
    case "blob":
      if (data instanceof Blob) {
        return data;
      } else {
        return new Blob([data]);
      }
    case "arraybuffer":
    default:
      if (data instanceof ArrayBuffer) {
        return data;
      } else {
        return data.buffer;
      }
  }
};

// ../../node_modules/.pnpm/engine.io-parser@5.2.3/node_modules/engine.io-parser/build/esm/index.js
var SEPARATOR = String.fromCharCode(30);
var encodePayload = (packets, callback) => {
  const length = packets.length;
  const encodedPackets = new Array(length);
  let count = 0;
  packets.forEach((packet, i) => {
    encodePacket(packet, false, (encodedPacket) => {
      encodedPackets[i] = encodedPacket;
      if (++count === length) {
        callback(encodedPackets.join(SEPARATOR));
      }
    });
  });
};
var decodePayload = (encodedPayload, binaryType) => {
  const encodedPackets = encodedPayload.split(SEPARATOR);
  const packets = [];
  for (let i = 0; i < encodedPackets.length; i++) {
    const decodedPacket = decodePacket(encodedPackets[i], binaryType);
    packets.push(decodedPacket);
    if (decodedPacket.type === "error") {
      break;
    }
  }
  return packets;
};
function createPacketEncoderStream() {
  return new TransformStream({
    transform(packet, controller) {
      encodePacketToBinary(packet, (encodedPacket) => {
        const payloadLength = encodedPacket.length;
        let header;
        if (payloadLength < 126) {
          header = new Uint8Array(1);
          new DataView(header.buffer).setUint8(0, payloadLength);
        } else if (payloadLength < 65536) {
          header = new Uint8Array(3);
          const view = new DataView(header.buffer);
          view.setUint8(0, 126);
          view.setUint16(1, payloadLength);
        } else {
          header = new Uint8Array(9);
          const view = new DataView(header.buffer);
          view.setUint8(0, 127);
          view.setBigUint64(1, BigInt(payloadLength));
        }
        if (packet.data && typeof packet.data !== "string") {
          header[0] |= 128;
        }
        controller.enqueue(header);
        controller.enqueue(encodedPacket);
      });
    }
  });
}
var TEXT_DECODER;
function totalLength(chunks) {
  return chunks.reduce((acc, chunk) => acc + chunk.length, 0);
}
function concatChunks(chunks, size) {
  if (chunks[0].length === size) {
    return chunks.shift();
  }
  const buffer = new Uint8Array(size);
  let j = 0;
  for (let i = 0; i < size; i++) {
    buffer[i] = chunks[0][j++];
    if (j === chunks[0].length) {
      chunks.shift();
      j = 0;
    }
  }
  if (chunks.length && j < chunks[0].length) {
    chunks[0] = chunks[0].slice(j);
  }
  return buffer;
}
function createPacketDecoderStream(maxPayload, binaryType) {
  if (!TEXT_DECODER) {
    TEXT_DECODER = new TextDecoder();
  }
  const chunks = [];
  let state = 0;
  let expectedLength = -1;
  let isBinary2 = false;
  return new TransformStream({
    transform(chunk, controller) {
      chunks.push(chunk);
      while (true) {
        if (state === 0) {
          if (totalLength(chunks) < 1) {
            break;
          }
          const header = concatChunks(chunks, 1);
          isBinary2 = (header[0] & 128) === 128;
          expectedLength = header[0] & 127;
          if (expectedLength < 126) {
            state = 3;
          } else if (expectedLength === 126) {
            state = 1;
          } else {
            state = 2;
          }
        } else if (state === 1) {
          if (totalLength(chunks) < 2) {
            break;
          }
          const headerArray = concatChunks(chunks, 2);
          expectedLength = new DataView(headerArray.buffer, headerArray.byteOffset, headerArray.length).getUint16(0);
          state = 3;
        } else if (state === 2) {
          if (totalLength(chunks) < 8) {
            break;
          }
          const headerArray = concatChunks(chunks, 8);
          const view = new DataView(headerArray.buffer, headerArray.byteOffset, headerArray.length);
          const n = view.getUint32(0);
          if (n > Math.pow(2, 53 - 32) - 1) {
            controller.enqueue(ERROR_PACKET);
            break;
          }
          expectedLength = n * Math.pow(2, 32) + view.getUint32(4);
          state = 3;
        } else {
          if (totalLength(chunks) < expectedLength) {
            break;
          }
          const data = concatChunks(chunks, expectedLength);
          controller.enqueue(decodePacket(isBinary2 ? data : TEXT_DECODER.decode(data), binaryType));
          state = 0;
        }
        if (expectedLength === 0 || expectedLength > maxPayload) {
          controller.enqueue(ERROR_PACKET);
          break;
        }
      }
    }
  });
}
var protocol = 4;

// ../../node_modules/.pnpm/@socket.io+component-emitter@3.1.2/node_modules/@socket.io/component-emitter/lib/esm/index.js
function Emitter(obj) {
  if (obj) return mixin(obj);
}
function mixin(obj) {
  for (var key in Emitter.prototype) {
    obj[key] = Emitter.prototype[key];
  }
  return obj;
}
Emitter.prototype.on = Emitter.prototype.addEventListener = function(event, fn) {
  this._callbacks = this._callbacks || {};
  (this._callbacks["$" + event] = this._callbacks["$" + event] || []).push(fn);
  return this;
};
Emitter.prototype.once = function(event, fn) {
  function on2() {
    this.off(event, on2);
    fn.apply(this, arguments);
  }
  on2.fn = fn;
  this.on(event, on2);
  return this;
};
Emitter.prototype.off = Emitter.prototype.removeListener = Emitter.prototype.removeAllListeners = Emitter.prototype.removeEventListener = function(event, fn) {
  this._callbacks = this._callbacks || {};
  if (0 == arguments.length) {
    this._callbacks = {};
    return this;
  }
  var callbacks = this._callbacks["$" + event];
  if (!callbacks) return this;
  if (1 == arguments.length) {
    delete this._callbacks["$" + event];
    return this;
  }
  var cb;
  for (var i = 0; i < callbacks.length; i++) {
    cb = callbacks[i];
    if (cb === fn || cb.fn === fn) {
      callbacks.splice(i, 1);
      break;
    }
  }
  if (callbacks.length === 0) {
    delete this._callbacks["$" + event];
  }
  return this;
};
Emitter.prototype.emit = function(event) {
  this._callbacks = this._callbacks || {};
  var args = new Array(arguments.length - 1), callbacks = this._callbacks["$" + event];
  for (var i = 1; i < arguments.length; i++) {
    args[i - 1] = arguments[i];
  }
  if (callbacks) {
    callbacks = callbacks.slice(0);
    for (var i = 0, len = callbacks.length; i < len; ++i) {
      callbacks[i].apply(this, args);
    }
  }
  return this;
};
Emitter.prototype.emitReserved = Emitter.prototype.emit;
Emitter.prototype.listeners = function(event) {
  this._callbacks = this._callbacks || {};
  return this._callbacks["$" + event] || [];
};
Emitter.prototype.hasListeners = function(event) {
  return !!this.listeners(event).length;
};

// ../../node_modules/.pnpm/engine.io-client@6.6.5/node_modules/engine.io-client/build/esm/globals.js
var nextTick = (() => {
  const isPromiseAvailable = typeof Promise === "function" && typeof Promise.resolve === "function";
  if (isPromiseAvailable) {
    return (cb) => Promise.resolve().then(cb);
  } else {
    return (cb, setTimeoutFn) => setTimeoutFn(cb, 0);
  }
})();
var globalThisShim = (() => {
  if (typeof self !== "undefined") {
    return self;
  } else if (typeof window !== "undefined") {
    return window;
  } else {
    return Function("return this")();
  }
})();
var defaultBinaryType = "arraybuffer";
function createCookieJar() {
}

// ../../node_modules/.pnpm/engine.io-client@6.6.5/node_modules/engine.io-client/build/esm/util.js
function pick(obj, ...attr) {
  return attr.reduce((acc, k) => {
    if (obj.hasOwnProperty(k)) {
      acc[k] = obj[k];
    }
    return acc;
  }, {});
}
var NATIVE_SET_TIMEOUT = globalThisShim.setTimeout;
var NATIVE_CLEAR_TIMEOUT = globalThisShim.clearTimeout;
function installTimerFunctions(obj, opts) {
  if (opts.useNativeTimers) {
    obj.setTimeoutFn = NATIVE_SET_TIMEOUT.bind(globalThisShim);
    obj.clearTimeoutFn = NATIVE_CLEAR_TIMEOUT.bind(globalThisShim);
  } else {
    obj.setTimeoutFn = globalThisShim.setTimeout.bind(globalThisShim);
    obj.clearTimeoutFn = globalThisShim.clearTimeout.bind(globalThisShim);
  }
}
var BASE64_OVERHEAD = 1.33;
function byteLength(obj) {
  if (typeof obj === "string") {
    return utf8Length(obj);
  }
  return Math.ceil((obj.byteLength || obj.size) * BASE64_OVERHEAD);
}
function utf8Length(str) {
  let c = 0, length = 0;
  for (let i = 0, l = str.length; i < l; i++) {
    c = str.charCodeAt(i);
    if (c < 128) {
      length += 1;
    } else if (c < 2048) {
      length += 2;
    } else if (c < 55296 || c >= 57344) {
      length += 3;
    } else {
      i++;
      length += 4;
    }
  }
  return length;
}
function randomString() {
  return Date.now().toString(36).substring(3) + Math.random().toString(36).substring(2, 5);
}

// ../../node_modules/.pnpm/engine.io-client@6.6.5/node_modules/engine.io-client/build/esm/contrib/parseqs.js
function encode(obj) {
  let str = "";
  for (let i in obj) {
    if (obj.hasOwnProperty(i)) {
      if (str.length)
        str += "&";
      str += encodeURIComponent(i) + "=" + encodeURIComponent(obj[i]);
    }
  }
  return str;
}
function decode2(qs) {
  let qry = {};
  let pairs = qs.split("&");
  for (let i = 0, l = pairs.length; i < l; i++) {
    let pair = pairs[i].split("=");
    qry[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1]);
  }
  return qry;
}

// ../../node_modules/.pnpm/engine.io-client@6.6.5/node_modules/engine.io-client/build/esm/transport.js
var TransportError = class extends Error {
  constructor(reason, description, context) {
    super(reason);
    this.description = description;
    this.context = context;
    this.type = "TransportError";
  }
};
var Transport = class extends Emitter {
  /**
   * Transport abstract constructor.
   *
   * @param {Object} opts - options
   * @protected
   */
  constructor(opts) {
    super();
    this.writable = false;
    installTimerFunctions(this, opts);
    this.opts = opts;
    this.query = opts.query;
    this.socket = opts.socket;
    this.supportsBinary = !opts.forceBase64;
  }
  /**
   * Emits an error.
   *
   * @param {String} reason
   * @param description
   * @param context - the error context
   * @return {Transport} for chaining
   * @protected
   */
  onError(reason, description, context) {
    super.emitReserved("error", new TransportError(reason, description, context));
    return this;
  }
  /**
   * Opens the transport.
   */
  open() {
    this.readyState = "opening";
    this.doOpen();
    return this;
  }
  /**
   * Closes the transport.
   */
  close() {
    if (this.readyState === "opening" || this.readyState === "open") {
      this.doClose();
      this.onClose();
    }
    return this;
  }
  /**
   * Sends multiple packets.
   *
   * @param {Array} packets
   */
  send(packets) {
    if (this.readyState === "open") {
      this.write(packets);
    } else {
    }
  }
  /**
   * Called upon open
   *
   * @protected
   */
  onOpen() {
    this.readyState = "open";
    this.writable = true;
    super.emitReserved("open");
  }
  /**
   * Called with data.
   *
   * @param {String} data
   * @protected
   */
  onData(data) {
    const packet = decodePacket(data, this.socket.binaryType);
    this.onPacket(packet);
  }
  /**
   * Called with a decoded packet.
   *
   * @protected
   */
  onPacket(packet) {
    super.emitReserved("packet", packet);
  }
  /**
   * Called upon close.
   *
   * @protected
   */
  onClose(details) {
    this.readyState = "closed";
    super.emitReserved("close", details);
  }
  /**
   * Pauses the transport, in order not to lose packets during an upgrade.
   *
   * @param onPause
   */
  pause(onPause) {
  }
  createUri(schema, query = {}) {
    return schema + "://" + this._hostname() + this._port() + this.opts.path + this._query(query);
  }
  _hostname() {
    const hostname = this.opts.hostname;
    return hostname.indexOf(":") === -1 ? hostname : "[" + hostname + "]";
  }
  _port() {
    if (this.opts.port && (this.opts.secure && Number(this.opts.port) !== 443 || !this.opts.secure && Number(this.opts.port) !== 80)) {
      return ":" + this.opts.port;
    } else {
      return "";
    }
  }
  _query(query) {
    const encodedQuery = encode(query);
    return encodedQuery.length ? "?" + encodedQuery : "";
  }
};

// ../../node_modules/.pnpm/engine.io-client@6.6.5/node_modules/engine.io-client/build/esm/transports/polling.js
var Polling = class extends Transport {
  constructor() {
    super(...arguments);
    this._polling = false;
  }
  get name() {
    return "polling";
  }
  /**
   * Opens the socket (triggers polling). We write a PING message to determine
   * when the transport is open.
   *
   * @protected
   */
  doOpen() {
    this._poll();
  }
  /**
   * Pauses polling.
   *
   * @param {Function} onPause - callback upon buffers are flushed and transport is paused
   * @package
   */
  pause(onPause) {
    this.readyState = "pausing";
    const pause = () => {
      this.readyState = "paused";
      onPause();
    };
    if (this._polling || !this.writable) {
      let total = 0;
      if (this._polling) {
        total++;
        this.once("pollComplete", function() {
          --total || pause();
        });
      }
      if (!this.writable) {
        total++;
        this.once("drain", function() {
          --total || pause();
        });
      }
    } else {
      pause();
    }
  }
  /**
   * Starts polling cycle.
   *
   * @private
   */
  _poll() {
    this._polling = true;
    this.doPoll();
    this.emitReserved("poll");
  }
  /**
   * Overloads onData to detect payloads.
   *
   * @protected
   */
  onData(data) {
    const callback = (packet) => {
      if ("opening" === this.readyState && packet.type === "open") {
        this.onOpen();
      }
      if ("close" === packet.type) {
        this.onClose({ description: "transport closed by the server" });
        return false;
      }
      this.onPacket(packet);
    };
    decodePayload(data, this.socket.binaryType).forEach(callback);
    if ("closed" !== this.readyState) {
      this._polling = false;
      this.emitReserved("pollComplete");
      if ("open" === this.readyState) {
        this._poll();
      } else {
      }
    }
  }
  /**
   * For polling, send a close packet.
   *
   * @protected
   */
  doClose() {
    const close = () => {
      this.write([{ type: "close" }]);
    };
    if ("open" === this.readyState) {
      close();
    } else {
      this.once("open", close);
    }
  }
  /**
   * Writes a packets payload.
   *
   * @param {Array} packets - data packets
   * @protected
   */
  write(packets) {
    this.writable = false;
    encodePayload(packets, (data) => {
      this.doWrite(data, () => {
        this.writable = true;
        this.emitReserved("drain");
      });
    });
  }
  /**
   * Generates uri for connection.
   *
   * @private
   */
  uri() {
    const schema = this.opts.secure ? "https" : "http";
    const query = this.query || {};
    if (false !== this.opts.timestampRequests) {
      query[this.opts.timestampParam] = randomString();
    }
    if (!this.supportsBinary && !query.sid) {
      query.b64 = 1;
    }
    return this.createUri(schema, query);
  }
};

// ../../node_modules/.pnpm/engine.io-client@6.6.5/node_modules/engine.io-client/build/esm/contrib/has-cors.js
var value = false;
try {
  value = typeof XMLHttpRequest !== "undefined" && "withCredentials" in new XMLHttpRequest();
} catch (err) {
}
var hasCORS = value;

// ../../node_modules/.pnpm/engine.io-client@6.6.5/node_modules/engine.io-client/build/esm/transports/polling-xhr.js
function empty() {
}
var BaseXHR = class extends Polling {
  /**
   * XHR Polling constructor.
   *
   * @param {Object} opts
   * @package
   */
  constructor(opts) {
    super(opts);
    if (typeof location !== "undefined") {
      const isSSL = "https:" === location.protocol;
      let port = location.port;
      if (!port) {
        port = isSSL ? "443" : "80";
      }
      this.xd = typeof location !== "undefined" && opts.hostname !== location.hostname || port !== opts.port;
    }
  }
  /**
   * Sends data.
   *
   * @param {String} data - data to send.
   * @param {Function} fn - called upon flush.
   * @private
   */
  doWrite(data, fn) {
    const req = this.request({
      method: "POST",
      data
    });
    req.on("success", fn);
    req.on("error", (xhrStatus, context) => {
      this.onError("xhr post error", xhrStatus, context);
    });
  }
  /**
   * Starts a poll cycle.
   *
   * @private
   */
  doPoll() {
    const req = this.request();
    req.on("data", this.onData.bind(this));
    req.on("error", (xhrStatus, context) => {
      this.onError("xhr poll error", xhrStatus, context);
    });
    this.pollXhr = req;
  }
};
var Request = class _Request extends Emitter {
  /**
   * Request constructor
   *
   * @param {Object} options
   * @package
   */
  constructor(createRequest, uri, opts) {
    super();
    this.createRequest = createRequest;
    installTimerFunctions(this, opts);
    this._opts = opts;
    this._method = opts.method || "GET";
    this._uri = uri;
    this._data = void 0 !== opts.data ? opts.data : null;
    this._create();
  }
  /**
   * Creates the XHR object and sends the request.
   *
   * @private
   */
  _create() {
    var _a;
    const opts = pick(this._opts, "agent", "pfx", "key", "passphrase", "cert", "ca", "ciphers", "rejectUnauthorized", "autoUnref");
    opts.xdomain = !!this._opts.xd;
    const xhr = this._xhr = this.createRequest(opts);
    try {
      xhr.open(this._method, this._uri, true);
      try {
        if (this._opts.extraHeaders) {
          xhr.setDisableHeaderCheck && xhr.setDisableHeaderCheck(true);
          for (let i in this._opts.extraHeaders) {
            if (this._opts.extraHeaders.hasOwnProperty(i)) {
              xhr.setRequestHeader(i, this._opts.extraHeaders[i]);
            }
          }
        }
      } catch (e) {
      }
      if ("POST" === this._method) {
        try {
          xhr.setRequestHeader("Content-type", "text/plain;charset=UTF-8");
        } catch (e) {
        }
      }
      try {
        xhr.setRequestHeader("Accept", "*/*");
      } catch (e) {
      }
      (_a = this._opts.cookieJar) === null || _a === void 0 ? void 0 : _a.addCookies(xhr);
      if ("withCredentials" in xhr) {
        xhr.withCredentials = this._opts.withCredentials;
      }
      if (this._opts.requestTimeout) {
        xhr.timeout = this._opts.requestTimeout;
      }
      xhr.onreadystatechange = () => {
        var _a2;
        if (xhr.readyState === 3) {
          (_a2 = this._opts.cookieJar) === null || _a2 === void 0 ? void 0 : _a2.parseCookies(
            // @ts-ignore
            xhr.getResponseHeader("set-cookie")
          );
        }
        if (4 !== xhr.readyState)
          return;
        if (200 === xhr.status || 1223 === xhr.status) {
          this._onLoad();
        } else {
          this.setTimeoutFn(() => {
            this._onError(typeof xhr.status === "number" ? xhr.status : 0);
          }, 0);
        }
      };
      xhr.send(this._data);
    } catch (e) {
      this.setTimeoutFn(() => {
        this._onError(e);
      }, 0);
      return;
    }
    if (typeof document !== "undefined") {
      this._index = _Request.requestsCount++;
      _Request.requests[this._index] = this;
    }
  }
  /**
   * Called upon error.
   *
   * @private
   */
  _onError(err) {
    this.emitReserved("error", err, this._xhr);
    this._cleanup(true);
  }
  /**
   * Cleans up house.
   *
   * @private
   */
  _cleanup(fromError) {
    if ("undefined" === typeof this._xhr || null === this._xhr) {
      return;
    }
    this._xhr.onreadystatechange = empty;
    if (fromError) {
      try {
        this._xhr.abort();
      } catch (e) {
      }
    }
    if (typeof document !== "undefined") {
      delete _Request.requests[this._index];
    }
    this._xhr = null;
  }
  /**
   * Called upon load.
   *
   * @private
   */
  _onLoad() {
    const data = this._xhr.responseText;
    if (data !== null) {
      this.emitReserved("data", data);
      this.emitReserved("success");
      this._cleanup();
    }
  }
  /**
   * Aborts the request.
   *
   * @package
   */
  abort() {
    this._cleanup();
  }
};
Request.requestsCount = 0;
Request.requests = {};
if (typeof document !== "undefined") {
  if (typeof attachEvent === "function") {
    attachEvent("onunload", unloadHandler);
  } else if (typeof addEventListener === "function") {
    const terminationEvent = "onpagehide" in globalThisShim ? "pagehide" : "unload";
    addEventListener(terminationEvent, unloadHandler, false);
  }
}
function unloadHandler() {
  for (let i in Request.requests) {
    if (Request.requests.hasOwnProperty(i)) {
      Request.requests[i].abort();
    }
  }
}
var hasXHR2 = function() {
  const xhr = newRequest({
    xdomain: false
  });
  return xhr && xhr.responseType !== null;
}();
var XHR = class extends BaseXHR {
  constructor(opts) {
    super(opts);
    const forceBase64 = opts && opts.forceBase64;
    this.supportsBinary = hasXHR2 && !forceBase64;
  }
  request(opts = {}) {
    Object.assign(opts, { xd: this.xd }, this.opts);
    return new Request(newRequest, this.uri(), opts);
  }
};
function newRequest(opts) {
  const xdomain = opts.xdomain;
  try {
    if ("undefined" !== typeof XMLHttpRequest && (!xdomain || hasCORS)) {
      return new XMLHttpRequest();
    }
  } catch (e) {
  }
  if (!xdomain) {
    try {
      return new globalThisShim[["Active"].concat("Object").join("X")]("Microsoft.XMLHTTP");
    } catch (e) {
    }
  }
}

// ../../node_modules/.pnpm/engine.io-client@6.6.5/node_modules/engine.io-client/build/esm/transports/websocket.js
var isReactNative = typeof navigator !== "undefined" && typeof navigator.product === "string" && navigator.product.toLowerCase() === "reactnative";
var BaseWS = class extends Transport {
  get name() {
    return "websocket";
  }
  doOpen() {
    const uri = this.uri();
    const protocols = this.opts.protocols;
    const opts = isReactNative ? {} : pick(this.opts, "agent", "perMessageDeflate", "pfx", "key", "passphrase", "cert", "ca", "ciphers", "rejectUnauthorized", "localAddress", "protocolVersion", "origin", "maxPayload", "family", "checkServerIdentity");
    if (this.opts.extraHeaders) {
      opts.headers = this.opts.extraHeaders;
    }
    try {
      this.ws = this.createSocket(uri, protocols, opts);
    } catch (err) {
      return this.emitReserved("error", err);
    }
    this.ws.binaryType = this.socket.binaryType;
    this.addEventListeners();
  }
  /**
   * Adds event listeners to the socket
   *
   * @private
   */
  addEventListeners() {
    this.ws.onopen = () => {
      if (this.opts.autoUnref) {
        this.ws._socket.unref();
      }
      this.onOpen();
    };
    this.ws.onclose = (closeEvent) => this.onClose({
      description: "websocket connection closed",
      context: closeEvent
    });
    this.ws.onmessage = (ev) => this.onData(ev.data);
    this.ws.onerror = (e) => this.onError("websocket error", e);
  }
  write(packets) {
    this.writable = false;
    for (let i = 0; i < packets.length; i++) {
      const packet = packets[i];
      const lastPacket = i === packets.length - 1;
      encodePacket(packet, this.supportsBinary, (data) => {
        try {
          this.doWrite(packet, data);
        } catch (e) {
        }
        if (lastPacket) {
          nextTick(() => {
            this.writable = true;
            this.emitReserved("drain");
          }, this.setTimeoutFn);
        }
      });
    }
  }
  doClose() {
    if (typeof this.ws !== "undefined") {
      this.ws.onerror = () => {
      };
      this.ws.close();
      this.ws = null;
    }
  }
  /**
   * Generates uri for connection.
   *
   * @private
   */
  uri() {
    const schema = this.opts.secure ? "wss" : "ws";
    const query = this.query || {};
    if (this.opts.timestampRequests) {
      query[this.opts.timestampParam] = randomString();
    }
    if (!this.supportsBinary) {
      query.b64 = 1;
    }
    return this.createUri(schema, query);
  }
};
var WebSocketCtor = globalThisShim.WebSocket || globalThisShim.MozWebSocket;
var WS = class extends BaseWS {
  createSocket(uri, protocols, opts) {
    return !isReactNative ? protocols ? new WebSocketCtor(uri, protocols) : new WebSocketCtor(uri) : new WebSocketCtor(uri, protocols, opts);
  }
  doWrite(_packet, data) {
    this.ws.send(data);
  }
};

// ../../node_modules/.pnpm/engine.io-client@6.6.5/node_modules/engine.io-client/build/esm/transports/webtransport.js
var WT = class extends Transport {
  get name() {
    return "webtransport";
  }
  doOpen() {
    try {
      this._transport = new WebTransport(this.createUri("https"), this.opts.transportOptions[this.name]);
    } catch (err) {
      return this.emitReserved("error", err);
    }
    this._transport.closed.then(() => {
      this.onClose();
    }).catch((err) => {
      this.onError("webtransport error", err);
    });
    this._transport.ready.then(() => {
      this._transport.createBidirectionalStream().then((stream) => {
        const decoderStream = createPacketDecoderStream(Number.MAX_SAFE_INTEGER, this.socket.binaryType);
        const reader = stream.readable.pipeThrough(decoderStream).getReader();
        const encoderStream = createPacketEncoderStream();
        encoderStream.readable.pipeTo(stream.writable);
        this._writer = encoderStream.writable.getWriter();
        const read = () => {
          reader.read().then(({ done, value: value2 }) => {
            if (done) {
              return;
            }
            this.onPacket(value2);
            read();
          }).catch((err) => {
          });
        };
        read();
        const packet = { type: "open" };
        if (this.query.sid) {
          packet.data = `{"sid":"${this.query.sid}"}`;
        }
        this._writer.write(packet).then(() => this.onOpen());
      });
    });
  }
  write(packets) {
    this.writable = false;
    for (let i = 0; i < packets.length; i++) {
      const packet = packets[i];
      const lastPacket = i === packets.length - 1;
      this._writer.write(packet).then(() => {
        if (lastPacket) {
          nextTick(() => {
            this.writable = true;
            this.emitReserved("drain");
          }, this.setTimeoutFn);
        }
      });
    }
  }
  doClose() {
    var _a;
    (_a = this._transport) === null || _a === void 0 ? void 0 : _a.close();
  }
};

// ../../node_modules/.pnpm/engine.io-client@6.6.5/node_modules/engine.io-client/build/esm/transports/index.js
var transports = {
  websocket: WS,
  webtransport: WT,
  polling: XHR
};

// ../../node_modules/.pnpm/engine.io-client@6.6.5/node_modules/engine.io-client/build/esm/contrib/parseuri.js
var re = /^(?:(?![^:@\/?#]+:[^:@\/]*@)(http|https|ws|wss):\/\/)?((?:(([^:@\/?#]*)(?::([^:@\/?#]*))?)?@)?((?:[a-f0-9]{0,4}:){2,7}[a-f0-9]{0,4}|[^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/;
var parts = [
  "source",
  "protocol",
  "authority",
  "userInfo",
  "user",
  "password",
  "host",
  "port",
  "relative",
  "path",
  "directory",
  "file",
  "query",
  "anchor"
];
function parse(str) {
  if (str.length > 8e3) {
    throw "URI too long";
  }
  const src = str, b = str.indexOf("["), e = str.indexOf("]");
  if (b != -1 && e != -1) {
    str = str.substring(0, b) + str.substring(b, e).replace(/:/g, ";") + str.substring(e, str.length);
  }
  let m = re.exec(str || ""), uri = {}, i = 14;
  while (i--) {
    uri[parts[i]] = m[i] || "";
  }
  if (b != -1 && e != -1) {
    uri.source = src;
    uri.host = uri.host.substring(1, uri.host.length - 1).replace(/;/g, ":");
    uri.authority = uri.authority.replace("[", "").replace("]", "").replace(/;/g, ":");
    uri.ipv6uri = true;
  }
  uri.pathNames = pathNames(uri, uri["path"]);
  uri.queryKey = queryKey(uri, uri["query"]);
  return uri;
}
function pathNames(obj, path) {
  const regx = /\/{2,9}/g, names = path.replace(regx, "/").split("/");
  if (path.slice(0, 1) == "/" || path.length === 0) {
    names.splice(0, 1);
  }
  if (path.slice(-1) == "/") {
    names.splice(names.length - 1, 1);
  }
  return names;
}
function queryKey(uri, query) {
  const data = {};
  query.replace(/(?:^|&)([^&=]*)=?([^&]*)/g, function($0, $1, $2) {
    if ($1) {
      data[$1] = $2;
    }
  });
  return data;
}

// ../../node_modules/.pnpm/engine.io-client@6.6.5/node_modules/engine.io-client/build/esm/socket.js
var withEventListeners = typeof addEventListener === "function" && typeof removeEventListener === "function";
var OFFLINE_EVENT_LISTENERS = [];
if (withEventListeners) {
  addEventListener("offline", () => {
    OFFLINE_EVENT_LISTENERS.forEach((listener) => listener());
  }, false);
}
var SocketWithoutUpgrade = class _SocketWithoutUpgrade extends Emitter {
  /**
   * Socket constructor.
   *
   * @param {String|Object} uri - uri or options
   * @param {Object} opts - options
   */
  constructor(uri, opts) {
    super();
    this.binaryType = defaultBinaryType;
    this.writeBuffer = [];
    this._prevBufferLen = 0;
    this._pingInterval = -1;
    this._pingTimeout = -1;
    this._maxPayload = -1;
    this._pingTimeoutTime = Infinity;
    if (uri && "object" === typeof uri) {
      opts = uri;
      uri = null;
    }
    if (uri) {
      const parsedUri = parse(uri);
      opts.hostname = parsedUri.host;
      opts.secure = parsedUri.protocol === "https" || parsedUri.protocol === "wss";
      opts.port = parsedUri.port;
      if (parsedUri.query)
        opts.query = parsedUri.query;
    } else if (opts.host) {
      opts.hostname = parse(opts.host).host;
    }
    installTimerFunctions(this, opts);
    this.secure = null != opts.secure ? opts.secure : typeof location !== "undefined" && "https:" === location.protocol;
    if (opts.hostname && !opts.port) {
      opts.port = this.secure ? "443" : "80";
    }
    this.hostname = opts.hostname || (typeof location !== "undefined" ? location.hostname : "localhost");
    this.port = opts.port || (typeof location !== "undefined" && location.port ? location.port : this.secure ? "443" : "80");
    this.transports = [];
    this._transportsByName = {};
    opts.transports.forEach((t) => {
      const transportName = t.prototype.name;
      this.transports.push(transportName);
      this._transportsByName[transportName] = t;
    });
    this.opts = Object.assign({
      path: "/engine.io",
      agent: false,
      withCredentials: false,
      upgrade: true,
      timestampParam: "t",
      rememberUpgrade: false,
      addTrailingSlash: true,
      rejectUnauthorized: true,
      perMessageDeflate: {
        threshold: 1024
      },
      transportOptions: {},
      closeOnBeforeunload: false
    }, opts);
    this.opts.path = this.opts.path.replace(/\/$/, "") + (this.opts.addTrailingSlash ? "/" : "");
    if (typeof this.opts.query === "string") {
      this.opts.query = decode2(this.opts.query);
    }
    if (withEventListeners) {
      if (this.opts.closeOnBeforeunload) {
        this._beforeunloadEventListener = () => {
          if (this.transport) {
            this.transport.removeAllListeners();
            this.transport.close();
          }
        };
        addEventListener("beforeunload", this._beforeunloadEventListener, false);
      }
      if (this.hostname !== "localhost") {
        this._offlineEventListener = () => {
          this._onClose("transport close", {
            description: "network connection lost"
          });
        };
        OFFLINE_EVENT_LISTENERS.push(this._offlineEventListener);
      }
    }
    if (this.opts.withCredentials) {
      this._cookieJar = createCookieJar();
    }
    this._open();
  }
  /**
   * Creates transport of the given type.
   *
   * @param {String} name - transport name
   * @return {Transport}
   * @private
   */
  createTransport(name) {
    const query = Object.assign({}, this.opts.query);
    query.EIO = protocol;
    query.transport = name;
    if (this.id)
      query.sid = this.id;
    const opts = Object.assign({}, this.opts, {
      query,
      socket: this,
      hostname: this.hostname,
      secure: this.secure,
      port: this.port
    }, this.opts.transportOptions[name]);
    return new this._transportsByName[name](opts);
  }
  /**
   * Initializes transport to use and starts probe.
   *
   * @private
   */
  _open() {
    if (this.transports.length === 0) {
      this.setTimeoutFn(() => {
        this.emitReserved("error", "No transports available");
      }, 0);
      return;
    }
    const transportName = this.opts.rememberUpgrade && _SocketWithoutUpgrade.priorWebsocketSuccess && this.transports.indexOf("websocket") !== -1 ? "websocket" : this.transports[0];
    this.readyState = "opening";
    const transport = this.createTransport(transportName);
    transport.open();
    this.setTransport(transport);
  }
  /**
   * Sets the current transport. Disables the existing one (if any).
   *
   * @private
   */
  setTransport(transport) {
    if (this.transport) {
      this.transport.removeAllListeners();
    }
    this.transport = transport;
    transport.on("drain", this._onDrain.bind(this)).on("packet", this._onPacket.bind(this)).on("error", this._onError.bind(this)).on("close", (reason) => this._onClose("transport close", reason));
  }
  /**
   * Called when connection is deemed open.
   *
   * @private
   */
  onOpen() {
    this.readyState = "open";
    _SocketWithoutUpgrade.priorWebsocketSuccess = "websocket" === this.transport.name;
    this.emitReserved("open");
    this.flush();
  }
  /**
   * Handles a packet.
   *
   * @private
   */
  _onPacket(packet) {
    if ("opening" === this.readyState || "open" === this.readyState || "closing" === this.readyState) {
      this.emitReserved("packet", packet);
      this.emitReserved("heartbeat");
      switch (packet.type) {
        case "open":
          this.onHandshake(JSON.parse(packet.data));
          break;
        case "ping":
          this._sendPacket("pong");
          this.emitReserved("ping");
          this.emitReserved("pong");
          this._resetPingTimeout();
          break;
        case "error":
          const err = new Error("server error");
          err.code = packet.data;
          this._onError(err);
          break;
        case "message":
          this.emitReserved("data", packet.data);
          this.emitReserved("message", packet.data);
          break;
      }
    } else {
    }
  }
  /**
   * Called upon handshake completion.
   *
   * @param {Object} data - handshake obj
   * @private
   */
  onHandshake(data) {
    this.emitReserved("handshake", data);
    this.id = data.sid;
    this.transport.query.sid = data.sid;
    this._pingInterval = data.pingInterval;
    this._pingTimeout = data.pingTimeout;
    this._maxPayload = data.maxPayload;
    this.onOpen();
    if ("closed" === this.readyState)
      return;
    this._resetPingTimeout();
  }
  /**
   * Sets and resets ping timeout timer based on server pings.
   *
   * @private
   */
  _resetPingTimeout() {
    this.clearTimeoutFn(this._pingTimeoutTimer);
    const delay = this._pingInterval + this._pingTimeout;
    this._pingTimeoutTime = Date.now() + delay;
    this._pingTimeoutTimer = this.setTimeoutFn(() => {
      this._onClose("ping timeout");
    }, delay);
    if (this.opts.autoUnref) {
      this._pingTimeoutTimer.unref();
    }
  }
  /**
   * Called on `drain` event
   *
   * @private
   */
  _onDrain() {
    this.writeBuffer.splice(0, this._prevBufferLen);
    this._prevBufferLen = 0;
    if (0 === this.writeBuffer.length) {
      this.emitReserved("drain");
    } else {
      this.flush();
    }
  }
  /**
   * Flush write buffers.
   *
   * @private
   */
  flush() {
    if ("closed" !== this.readyState && this.transport.writable && !this.upgrading && this.writeBuffer.length) {
      const packets = this._getWritablePackets();
      this.transport.send(packets);
      this._prevBufferLen = packets.length;
      this.emitReserved("flush");
    }
  }
  /**
   * Ensure the encoded size of the writeBuffer is below the maxPayload value sent by the server (only for HTTP
   * long-polling)
   *
   * @private
   */
  _getWritablePackets() {
    const shouldCheckPayloadSize = this._maxPayload && this.transport.name === "polling" && this.writeBuffer.length > 1;
    if (!shouldCheckPayloadSize) {
      return this.writeBuffer;
    }
    let payloadSize = 1;
    for (let i = 0; i < this.writeBuffer.length; i++) {
      const data = this.writeBuffer[i].data;
      if (data) {
        payloadSize += byteLength(data);
      }
      if (i > 0 && payloadSize > this._maxPayload) {
        return this.writeBuffer.slice(0, i);
      }
      payloadSize += 2;
    }
    return this.writeBuffer;
  }
  /**
   * Checks whether the heartbeat timer has expired but the socket has not yet been notified.
   *
   * Note: this method is private for now because it does not really fit the WebSocket API, but if we put it in the
   * `write()` method then the message would not be buffered by the Socket.IO client.
   *
   * @return {boolean}
   * @private
   */
  /* private */
  _hasPingExpired() {
    if (!this._pingTimeoutTime)
      return true;
    const hasExpired = Date.now() > this._pingTimeoutTime;
    if (hasExpired) {
      this._pingTimeoutTime = 0;
      nextTick(() => {
        this._onClose("ping timeout");
      }, this.setTimeoutFn);
    }
    return hasExpired;
  }
  /**
   * Sends a message.
   *
   * @param {String} msg - message.
   * @param {Object} options.
   * @param {Function} fn - callback function.
   * @return {Socket} for chaining.
   */
  write(msg, options, fn) {
    this._sendPacket("message", msg, options, fn);
    return this;
  }
  /**
   * Sends a message. Alias of {@link Socket#write}.
   *
   * @param {String} msg - message.
   * @param {Object} options.
   * @param {Function} fn - callback function.
   * @return {Socket} for chaining.
   */
  send(msg, options, fn) {
    this._sendPacket("message", msg, options, fn);
    return this;
  }
  /**
   * Sends a packet.
   *
   * @param {String} type - packet type.
   * @param {String} data.
   * @param {Object} options.
   * @param {Function} fn - callback function.
   * @private
   */
  _sendPacket(type, data, options, fn) {
    if ("function" === typeof data) {
      fn = data;
      data = void 0;
    }
    if ("function" === typeof options) {
      fn = options;
      options = null;
    }
    if ("closing" === this.readyState || "closed" === this.readyState) {
      return;
    }
    options = options || {};
    options.compress = false !== options.compress;
    const packet = {
      type,
      data,
      options
    };
    this.emitReserved("packetCreate", packet);
    this.writeBuffer.push(packet);
    if (fn)
      this.once("flush", fn);
    this.flush();
  }
  /**
   * Closes the connection.
   */
  close() {
    const close = () => {
      this._onClose("forced close");
      this.transport.close();
    };
    const cleanupAndClose = () => {
      this.off("upgrade", cleanupAndClose);
      this.off("upgradeError", cleanupAndClose);
      close();
    };
    const waitForUpgrade = () => {
      this.once("upgrade", cleanupAndClose);
      this.once("upgradeError", cleanupAndClose);
    };
    if ("opening" === this.readyState || "open" === this.readyState) {
      this.readyState = "closing";
      if (this.writeBuffer.length) {
        this.once("drain", () => {
          if (this.upgrading) {
            waitForUpgrade();
          } else {
            close();
          }
        });
      } else if (this.upgrading) {
        waitForUpgrade();
      } else {
        close();
      }
    }
    return this;
  }
  /**
   * Called upon transport error
   *
   * @private
   */
  _onError(err) {
    _SocketWithoutUpgrade.priorWebsocketSuccess = false;
    if (this.opts.tryAllTransports && this.transports.length > 1 && this.readyState === "opening") {
      this.transports.shift();
      return this._open();
    }
    this.emitReserved("error", err);
    this._onClose("transport error", err);
  }
  /**
   * Called upon transport close.
   *
   * @private
   */
  _onClose(reason, description) {
    if ("opening" === this.readyState || "open" === this.readyState || "closing" === this.readyState) {
      this.clearTimeoutFn(this._pingTimeoutTimer);
      this.transport.removeAllListeners("close");
      this.transport.close();
      this.transport.removeAllListeners();
      if (withEventListeners) {
        if (this._beforeunloadEventListener) {
          removeEventListener("beforeunload", this._beforeunloadEventListener, false);
        }
        if (this._offlineEventListener) {
          const i = OFFLINE_EVENT_LISTENERS.indexOf(this._offlineEventListener);
          if (i !== -1) {
            OFFLINE_EVENT_LISTENERS.splice(i, 1);
          }
        }
      }
      this.readyState = "closed";
      this.id = null;
      this.emitReserved("close", reason, description);
      this.writeBuffer = [];
      this._prevBufferLen = 0;
    }
  }
};
SocketWithoutUpgrade.protocol = protocol;
var SocketWithUpgrade = class extends SocketWithoutUpgrade {
  constructor() {
    super(...arguments);
    this._upgrades = [];
  }
  onOpen() {
    super.onOpen();
    if ("open" === this.readyState && this.opts.upgrade) {
      for (let i = 0; i < this._upgrades.length; i++) {
        this._probe(this._upgrades[i]);
      }
    }
  }
  /**
   * Probes a transport.
   *
   * @param {String} name - transport name
   * @private
   */
  _probe(name) {
    let transport = this.createTransport(name);
    let failed = false;
    SocketWithoutUpgrade.priorWebsocketSuccess = false;
    const onTransportOpen = () => {
      if (failed)
        return;
      transport.send([{ type: "ping", data: "probe" }]);
      transport.once("packet", (msg) => {
        if (failed)
          return;
        if ("pong" === msg.type && "probe" === msg.data) {
          this.upgrading = true;
          this.emitReserved("upgrading", transport);
          if (!transport)
            return;
          SocketWithoutUpgrade.priorWebsocketSuccess = "websocket" === transport.name;
          this.transport.pause(() => {
            if (failed)
              return;
            if ("closed" === this.readyState)
              return;
            cleanup();
            this.setTransport(transport);
            transport.send([{ type: "upgrade" }]);
            this.emitReserved("upgrade", transport);
            transport = null;
            this.upgrading = false;
            this.flush();
          });
        } else {
          const err = new Error("probe error");
          err.transport = transport.name;
          this.emitReserved("upgradeError", err);
        }
      });
    };
    function freezeTransport() {
      if (failed)
        return;
      failed = true;
      cleanup();
      transport.close();
      transport = null;
    }
    const onerror = (err) => {
      const error = new Error("probe error: " + err);
      error.transport = transport.name;
      freezeTransport();
      this.emitReserved("upgradeError", error);
    };
    function onTransportClose() {
      onerror("transport closed");
    }
    function onclose() {
      onerror("socket closed");
    }
    function onupgrade(to) {
      if (transport && to.name !== transport.name) {
        freezeTransport();
      }
    }
    const cleanup = () => {
      transport.removeListener("open", onTransportOpen);
      transport.removeListener("error", onerror);
      transport.removeListener("close", onTransportClose);
      this.off("close", onclose);
      this.off("upgrading", onupgrade);
    };
    transport.once("open", onTransportOpen);
    transport.once("error", onerror);
    transport.once("close", onTransportClose);
    this.once("close", onclose);
    this.once("upgrading", onupgrade);
    if (this._upgrades.indexOf("webtransport") !== -1 && name !== "webtransport") {
      this.setTimeoutFn(() => {
        if (!failed) {
          transport.open();
        }
      }, 200);
    } else {
      transport.open();
    }
  }
  onHandshake(data) {
    this._upgrades = this._filterUpgrades(data.upgrades);
    super.onHandshake(data);
  }
  /**
   * Filters upgrades, returning only those matching client transports.
   *
   * @param {Array} upgrades - server upgrades
   * @private
   */
  _filterUpgrades(upgrades) {
    const filteredUpgrades = [];
    for (let i = 0; i < upgrades.length; i++) {
      if (~this.transports.indexOf(upgrades[i]))
        filteredUpgrades.push(upgrades[i]);
    }
    return filteredUpgrades;
  }
};
var Socket = class extends SocketWithUpgrade {
  constructor(uri, opts = {}) {
    const o = typeof uri === "object" ? uri : opts;
    if (!o.transports || o.transports && typeof o.transports[0] === "string") {
      o.transports = (o.transports || ["polling", "websocket", "webtransport"]).map((transportName) => transports[transportName]).filter((t) => !!t);
    }
    super(uri, o);
  }
};

// ../../node_modules/.pnpm/engine.io-client@6.6.5/node_modules/engine.io-client/build/esm/index.js
var protocol2 = Socket.protocol;

// ../../node_modules/.pnpm/socket.io-client@4.8.3/node_modules/socket.io-client/build/esm/url.js
function url(uri, path = "", loc) {
  let obj = uri;
  loc = loc || typeof location !== "undefined" && location;
  if (null == uri)
    uri = loc.protocol + "//" + loc.host;
  if (typeof uri === "string") {
    if ("/" === uri.charAt(0)) {
      if ("/" === uri.charAt(1)) {
        uri = loc.protocol + uri;
      } else {
        uri = loc.host + uri;
      }
    }
    if (!/^(https?|wss?):\/\//.test(uri)) {
      if ("undefined" !== typeof loc) {
        uri = loc.protocol + "//" + uri;
      } else {
        uri = "https://" + uri;
      }
    }
    obj = parse(uri);
  }
  if (!obj.port) {
    if (/^(http|ws)$/.test(obj.protocol)) {
      obj.port = "80";
    } else if (/^(http|ws)s$/.test(obj.protocol)) {
      obj.port = "443";
    }
  }
  obj.path = obj.path || "/";
  const ipv6 = obj.host.indexOf(":") !== -1;
  const host = ipv6 ? "[" + obj.host + "]" : obj.host;
  obj.id = obj.protocol + "://" + host + ":" + obj.port + path;
  obj.href = obj.protocol + "://" + host + (loc && loc.port === obj.port ? "" : ":" + obj.port);
  return obj;
}

// ../../node_modules/.pnpm/socket.io-parser@4.2.7/node_modules/socket.io-parser/build/esm/index.js
var esm_exports = {};
__export(esm_exports, {
  Decoder: () => Decoder,
  Encoder: () => Encoder,
  PacketType: () => PacketType,
  isPacketValid: () => isPacketValid,
  protocol: () => protocol3
});

// ../../node_modules/.pnpm/socket.io-parser@4.2.7/node_modules/socket.io-parser/build/esm/is-binary.js
var withNativeArrayBuffer3 = typeof ArrayBuffer === "function";
var isView2 = (obj) => {
  return typeof ArrayBuffer.isView === "function" ? ArrayBuffer.isView(obj) : obj.buffer instanceof ArrayBuffer;
};
var toString = Object.prototype.toString;
var withNativeBlob2 = typeof Blob === "function" || typeof Blob !== "undefined" && toString.call(Blob) === "[object BlobConstructor]";
var withNativeFile = typeof File === "function" || typeof File !== "undefined" && toString.call(File) === "[object FileConstructor]";
function isBinary(obj) {
  return withNativeArrayBuffer3 && (obj instanceof ArrayBuffer || isView2(obj)) || withNativeBlob2 && obj instanceof Blob || withNativeFile && obj instanceof File;
}
function hasBinary(obj, toJSON) {
  if (!obj || typeof obj !== "object") {
    return false;
  }
  if (Array.isArray(obj)) {
    for (let i = 0, l = obj.length; i < l; i++) {
      if (hasBinary(obj[i])) {
        return true;
      }
    }
    return false;
  }
  if (isBinary(obj)) {
    return true;
  }
  if (obj.toJSON && typeof obj.toJSON === "function" && arguments.length === 1) {
    return hasBinary(obj.toJSON(), true);
  }
  for (const key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key) && hasBinary(obj[key])) {
      return true;
    }
  }
  return false;
}

// ../../node_modules/.pnpm/socket.io-parser@4.2.7/node_modules/socket.io-parser/build/esm/binary.js
function deconstructPacket(packet) {
  const buffers = [];
  const packetData = packet.data;
  const pack = packet;
  pack.data = _deconstructPacket(packetData, buffers);
  pack.attachments = buffers.length;
  return { packet: pack, buffers };
}
function _deconstructPacket(data, buffers, toJSON) {
  if (!data)
    return data;
  if (isBinary(data)) {
    const placeholder = { _placeholder: true, num: buffers.length };
    buffers.push(data);
    return placeholder;
  } else if (Array.isArray(data)) {
    const newData = new Array(data.length);
    for (let i = 0; i < data.length; i++) {
      newData[i] = _deconstructPacket(data[i], buffers);
    }
    return newData;
  } else if (typeof data === "object" && !(data instanceof Date)) {
    if (data.toJSON && typeof data.toJSON === "function" && !toJSON) {
      return _deconstructPacket(data.toJSON(), buffers, true);
    }
    const newData = {};
    for (const key in data) {
      if (Object.prototype.hasOwnProperty.call(data, key)) {
        newData[key] = _deconstructPacket(data[key], buffers);
      }
    }
    return newData;
  }
  return data;
}
function reconstructPacket(packet, buffers) {
  packet.data = _reconstructPacket(packet.data, buffers);
  delete packet.attachments;
  return packet;
}
function _reconstructPacket(data, buffers) {
  if (!data)
    return data;
  if (data && data._placeholder === true) {
    const isIndexValid = typeof data.num === "number" && data.num >= 0 && data.num < buffers.length;
    if (isIndexValid) {
      return buffers[data.num];
    } else {
      throw new Error("illegal attachments");
    }
  } else if (Array.isArray(data)) {
    for (let i = 0; i < data.length; i++) {
      data[i] = _reconstructPacket(data[i], buffers);
    }
  } else if (typeof data === "object") {
    for (const key in data) {
      if (Object.prototype.hasOwnProperty.call(data, key)) {
        data[key] = _reconstructPacket(data[key], buffers);
      }
    }
  }
  return data;
}

// ../../node_modules/.pnpm/socket.io-parser@4.2.7/node_modules/socket.io-parser/build/esm/index.js
var RESERVED_EVENTS = [
  "connect",
  // used on the client side
  "connect_error",
  // used on the client side
  "disconnect",
  // used on both sides
  "disconnecting",
  // used on the server side
  "newListener",
  // used by the Node.js EventEmitter
  "removeListener"
  // used by the Node.js EventEmitter
];
var protocol3 = 5;
var PacketType;
(function(PacketType2) {
  PacketType2[PacketType2["CONNECT"] = 0] = "CONNECT";
  PacketType2[PacketType2["DISCONNECT"] = 1] = "DISCONNECT";
  PacketType2[PacketType2["EVENT"] = 2] = "EVENT";
  PacketType2[PacketType2["ACK"] = 3] = "ACK";
  PacketType2[PacketType2["CONNECT_ERROR"] = 4] = "CONNECT_ERROR";
  PacketType2[PacketType2["BINARY_EVENT"] = 5] = "BINARY_EVENT";
  PacketType2[PacketType2["BINARY_ACK"] = 6] = "BINARY_ACK";
})(PacketType || (PacketType = {}));
var Encoder = class {
  /**
   * Encoder constructor
   *
   * @param {function} replacer - custom replacer to pass down to JSON.parse
   */
  constructor(replacer) {
    this.replacer = replacer;
  }
  /**
   * Encode a packet as a single string if non-binary, or as a
   * buffer sequence, depending on packet type.
   *
   * @param {Object} obj - packet object
   */
  encode(obj) {
    if (obj.type === PacketType.EVENT || obj.type === PacketType.ACK) {
      if (hasBinary(obj)) {
        return this.encodeAsBinary({
          type: obj.type === PacketType.EVENT ? PacketType.BINARY_EVENT : PacketType.BINARY_ACK,
          nsp: obj.nsp,
          data: obj.data,
          id: obj.id
        });
      }
    }
    return [this.encodeAsString(obj)];
  }
  /**
   * Encode packet as string.
   */
  encodeAsString(obj) {
    let str = "" + obj.type;
    if (obj.type === PacketType.BINARY_EVENT || obj.type === PacketType.BINARY_ACK) {
      str += obj.attachments + "-";
    }
    if (obj.nsp && "/" !== obj.nsp) {
      str += obj.nsp + ",";
    }
    if (null != obj.id) {
      str += obj.id;
    }
    if (null != obj.data) {
      str += JSON.stringify(obj.data, this.replacer);
    }
    return str;
  }
  /**
   * Encode packet as 'buffer sequence' by removing blobs, and
   * deconstructing packet into object with placeholders and
   * a list of buffers.
   */
  encodeAsBinary(obj) {
    const deconstruction = deconstructPacket(obj);
    const pack = this.encodeAsString(deconstruction.packet);
    const buffers = deconstruction.buffers;
    buffers.unshift(pack);
    return buffers;
  }
};
var Decoder = class _Decoder extends Emitter {
  /**
   * Decoder constructor
   */
  constructor(opts) {
    super();
    this.opts = Object.assign({
      reviver: void 0,
      maxAttachments: 10
    }, typeof opts === "function" ? { reviver: opts } : opts);
  }
  /**
   * Decodes an encoded packet string into packet JSON.
   *
   * @param {String} obj - encoded packet
   */
  add(obj) {
    let packet;
    if (typeof obj === "string") {
      if (this.reconstructor) {
        throw new Error("got plaintext data when reconstructing a packet");
      }
      packet = this.decodeString(obj);
      const isBinaryEvent = packet.type === PacketType.BINARY_EVENT;
      if (isBinaryEvent || packet.type === PacketType.BINARY_ACK) {
        packet.type = isBinaryEvent ? PacketType.EVENT : PacketType.ACK;
        this.reconstructor = new BinaryReconstructor(packet);
      } else {
        super.emitReserved("decoded", packet);
      }
    } else if (isBinary(obj) || obj.base64) {
      if (!this.reconstructor) {
        throw new Error("got binary data when not reconstructing a packet");
      } else {
        packet = this.reconstructor.takeBinaryData(obj);
        if (packet) {
          this.reconstructor = null;
          super.emitReserved("decoded", packet);
        }
      }
    } else {
      throw new Error("Unknown type: " + obj);
    }
  }
  /**
   * Decode a packet String (JSON data)
   *
   * @param {String} str
   * @return {Object} packet
   */
  decodeString(str) {
    let i = 0;
    const p = {
      type: Number(str.charAt(0))
    };
    if (PacketType[p.type] === void 0) {
      throw new Error("unknown packet type " + p.type);
    }
    if (p.type === PacketType.BINARY_EVENT || p.type === PacketType.BINARY_ACK) {
      const start = i + 1;
      while (str.charAt(++i) !== "-" && i != str.length) {
      }
      const buf = str.substring(start, i);
      if (buf != Number(buf) || str.charAt(i) !== "-") {
        throw new Error("Illegal attachments");
      }
      const n = Number(buf);
      if (!isInteger(n) || n < 1) {
        throw new Error("Illegal attachments");
      } else if (n > this.opts.maxAttachments) {
        throw new Error("too many attachments");
      }
      p.attachments = n;
    }
    if ("/" === str.charAt(i + 1)) {
      const start = i + 1;
      while (++i) {
        const c = str.charAt(i);
        if ("," === c)
          break;
        if (i === str.length)
          break;
      }
      p.nsp = str.substring(start, i);
    } else {
      p.nsp = "/";
    }
    const next = str.charAt(i + 1);
    if ("" !== next && Number(next) == next) {
      const start = i + 1;
      while (++i) {
        const c = str.charAt(i);
        if (null == c || Number(c) != c) {
          --i;
          break;
        }
        if (i === str.length)
          break;
      }
      p.id = Number(str.substring(start, i + 1));
    }
    if (str.charAt(++i)) {
      const payload = this.tryParse(str.substr(i));
      if (_Decoder.isPayloadValid(p.type, payload)) {
        p.data = payload;
      } else {
        throw new Error("invalid payload");
      }
    }
    return p;
  }
  tryParse(str) {
    try {
      return JSON.parse(str, this.opts.reviver);
    } catch (e) {
      return false;
    }
  }
  static isPayloadValid(type, payload) {
    switch (type) {
      case PacketType.CONNECT:
        return isObject(payload);
      case PacketType.DISCONNECT:
        return payload === void 0;
      case PacketType.CONNECT_ERROR:
        return typeof payload === "string" || isObject(payload);
      case PacketType.EVENT:
      case PacketType.BINARY_EVENT:
        return Array.isArray(payload) && (typeof payload[0] === "number" || typeof payload[0] === "string" && RESERVED_EVENTS.indexOf(payload[0]) === -1);
      case PacketType.ACK:
      case PacketType.BINARY_ACK:
        return Array.isArray(payload);
    }
  }
  /**
   * Deallocates a parser's resources
   */
  destroy() {
    if (this.reconstructor) {
      this.reconstructor.finishedReconstruction();
      this.reconstructor = null;
    }
  }
};
var BinaryReconstructor = class {
  constructor(packet) {
    this.packet = packet;
    this.buffers = [];
    this.reconPack = packet;
  }
  /**
   * Method to be called when binary data received from connection
   * after a BINARY_EVENT packet.
   *
   * @param {Buffer | ArrayBuffer} binData - the raw binary data received
   * @return {null | Object} returns null if more binary data is expected or
   *   a reconstructed packet object if all buffers have been received.
   */
  takeBinaryData(binData) {
    this.buffers.push(binData);
    if (this.buffers.length === this.reconPack.attachments) {
      const packet = reconstructPacket(this.reconPack, this.buffers);
      this.finishedReconstruction();
      return packet;
    }
    return null;
  }
  /**
   * Cleans up binary packet reconstruction variables.
   */
  finishedReconstruction() {
    this.reconPack = null;
    this.buffers = [];
  }
};
function isNamespaceValid(nsp) {
  return typeof nsp === "string";
}
var isInteger = Number.isInteger || function(value2) {
  return typeof value2 === "number" && isFinite(value2) && Math.floor(value2) === value2;
};
function isAckIdValid(id) {
  return id === void 0 || isInteger(id);
}
function isObject(value2) {
  return Object.prototype.toString.call(value2) === "[object Object]";
}
function isDataValid(type, payload) {
  switch (type) {
    case PacketType.CONNECT:
      return payload === void 0 || isObject(payload);
    case PacketType.DISCONNECT:
      return payload === void 0;
    case PacketType.EVENT:
      return Array.isArray(payload) && (typeof payload[0] === "number" || typeof payload[0] === "string" && RESERVED_EVENTS.indexOf(payload[0]) === -1);
    case PacketType.ACK:
      return Array.isArray(payload);
    case PacketType.CONNECT_ERROR:
      return typeof payload === "string" || isObject(payload);
    default:
      return false;
  }
}
function isPacketValid(packet) {
  return isNamespaceValid(packet.nsp) && isAckIdValid(packet.id) && isDataValid(packet.type, packet.data);
}

// ../../node_modules/.pnpm/socket.io-client@4.8.3/node_modules/socket.io-client/build/esm/on.js
function on(obj, ev, fn) {
  obj.on(ev, fn);
  return function subDestroy() {
    obj.off(ev, fn);
  };
}

// ../../node_modules/.pnpm/socket.io-client@4.8.3/node_modules/socket.io-client/build/esm/socket.js
var RESERVED_EVENTS2 = Object.freeze({
  connect: 1,
  connect_error: 1,
  disconnect: 1,
  disconnecting: 1,
  // EventEmitter reserved events: https://nodejs.org/api/events.html#events_event_newlistener
  newListener: 1,
  removeListener: 1
});
var Socket2 = class extends Emitter {
  /**
   * `Socket` constructor.
   */
  constructor(io, nsp, opts) {
    super();
    this.connected = false;
    this.recovered = false;
    this.receiveBuffer = [];
    this.sendBuffer = [];
    this._queue = [];
    this._queueSeq = 0;
    this.ids = 0;
    this.acks = {};
    this.flags = {};
    this.io = io;
    this.nsp = nsp;
    if (opts && opts.auth) {
      this.auth = opts.auth;
    }
    this._opts = Object.assign({}, opts);
    if (this.io._autoConnect)
      this.open();
  }
  /**
   * Whether the socket is currently disconnected
   *
   * @example
   * const socket = io();
   *
   * socket.on("connect", () => {
   *   console.log(socket.disconnected); // false
   * });
   *
   * socket.on("disconnect", () => {
   *   console.log(socket.disconnected); // true
   * });
   */
  get disconnected() {
    return !this.connected;
  }
  /**
   * Subscribe to open, close and packet events
   *
   * @private
   */
  subEvents() {
    if (this.subs)
      return;
    const io = this.io;
    this.subs = [
      on(io, "open", this.onopen.bind(this)),
      on(io, "packet", this.onpacket.bind(this)),
      on(io, "error", this.onerror.bind(this)),
      on(io, "close", this.onclose.bind(this))
    ];
  }
  /**
   * Whether the Socket will try to reconnect when its Manager connects or reconnects.
   *
   * @example
   * const socket = io();
   *
   * console.log(socket.active); // true
   *
   * socket.on("disconnect", (reason) => {
   *   if (reason === "io server disconnect") {
   *     // the disconnection was initiated by the server, you need to manually reconnect
   *     console.log(socket.active); // false
   *   }
   *   // else the socket will automatically try to reconnect
   *   console.log(socket.active); // true
   * });
   */
  get active() {
    return !!this.subs;
  }
  /**
   * "Opens" the socket.
   *
   * @example
   * const socket = io({
   *   autoConnect: false
   * });
   *
   * socket.connect();
   */
  connect() {
    if (this.connected)
      return this;
    this.subEvents();
    if (!this.io["_reconnecting"])
      this.io.open();
    if ("open" === this.io._readyState)
      this.onopen();
    return this;
  }
  /**
   * Alias for {@link connect()}.
   */
  open() {
    return this.connect();
  }
  /**
   * Sends a `message` event.
   *
   * This method mimics the WebSocket.send() method.
   *
   * @see https://developer.mozilla.org/en-US/docs/Web/API/WebSocket/send
   *
   * @example
   * socket.send("hello");
   *
   * // this is equivalent to
   * socket.emit("message", "hello");
   *
   * @return self
   */
  send(...args) {
    args.unshift("message");
    this.emit.apply(this, args);
    return this;
  }
  /**
   * Override `emit`.
   * If the event is in `events`, it's emitted normally.
   *
   * @example
   * socket.emit("hello", "world");
   *
   * // all serializable datastructures are supported (no need to call JSON.stringify)
   * socket.emit("hello", 1, "2", { 3: ["4"], 5: Uint8Array.from([6]) });
   *
   * // with an acknowledgement from the server
   * socket.emit("hello", "world", (val) => {
   *   // ...
   * });
   *
   * @return self
   */
  emit(ev, ...args) {
    var _a, _b, _c;
    if (RESERVED_EVENTS2.hasOwnProperty(ev)) {
      throw new Error('"' + ev.toString() + '" is a reserved event name');
    }
    args.unshift(ev);
    if (this._opts.retries && !this.flags.fromQueue && !this.flags.volatile) {
      this._addToQueue(args);
      return this;
    }
    const packet = {
      type: PacketType.EVENT,
      data: args
    };
    packet.options = {};
    packet.options.compress = this.flags.compress !== false;
    if ("function" === typeof args[args.length - 1]) {
      const id = this.ids++;
      const ack = args.pop();
      this._registerAckCallback(id, ack);
      packet.id = id;
    }
    const isTransportWritable = (_b = (_a = this.io.engine) === null || _a === void 0 ? void 0 : _a.transport) === null || _b === void 0 ? void 0 : _b.writable;
    const isConnected = this.connected && !((_c = this.io.engine) === null || _c === void 0 ? void 0 : _c._hasPingExpired());
    const discardPacket = this.flags.volatile && !isTransportWritable;
    if (discardPacket) {
    } else if (isConnected) {
      this.notifyOutgoingListeners(packet);
      this.packet(packet);
    } else {
      this.sendBuffer.push(packet);
    }
    this.flags = {};
    return this;
  }
  /**
   * @private
   */
  _registerAckCallback(id, ack) {
    var _a;
    const timeout = (_a = this.flags.timeout) !== null && _a !== void 0 ? _a : this._opts.ackTimeout;
    if (timeout === void 0) {
      this.acks[id] = ack;
      return;
    }
    const timer = this.io.setTimeoutFn(() => {
      delete this.acks[id];
      for (let i = 0; i < this.sendBuffer.length; i++) {
        if (this.sendBuffer[i].id === id) {
          this.sendBuffer.splice(i, 1);
        }
      }
      ack.call(this, new Error("operation has timed out"));
    }, timeout);
    const fn = (...args) => {
      this.io.clearTimeoutFn(timer);
      ack.apply(this, args);
    };
    fn.withError = true;
    this.acks[id] = fn;
  }
  /**
   * Emits an event and waits for an acknowledgement
   *
   * @example
   * // without timeout
   * const response = await socket.emitWithAck("hello", "world");
   *
   * // with a specific timeout
   * try {
   *   const response = await socket.timeout(1000).emitWithAck("hello", "world");
   * } catch (err) {
   *   // the server did not acknowledge the event in the given delay
   * }
   *
   * @return a Promise that will be fulfilled when the server acknowledges the event
   */
  emitWithAck(ev, ...args) {
    return new Promise((resolve, reject) => {
      const fn = (arg1, arg2) => {
        return arg1 ? reject(arg1) : resolve(arg2);
      };
      fn.withError = true;
      args.push(fn);
      this.emit(ev, ...args);
    });
  }
  /**
   * Add the packet to the queue.
   * @param args
   * @private
   */
  _addToQueue(args) {
    let ack;
    if (typeof args[args.length - 1] === "function") {
      ack = args.pop();
    }
    const packet = {
      id: this._queueSeq++,
      tryCount: 0,
      pending: false,
      args,
      flags: Object.assign({ fromQueue: true }, this.flags)
    };
    args.push((err, ...responseArgs) => {
      if (packet !== this._queue[0]) {
      }
      const hasError = err !== null;
      if (hasError) {
        if (packet.tryCount > this._opts.retries) {
          this._queue.shift();
          if (ack) {
            ack(err);
          }
        }
      } else {
        this._queue.shift();
        if (ack) {
          ack(null, ...responseArgs);
        }
      }
      packet.pending = false;
      return this._drainQueue();
    });
    this._queue.push(packet);
    this._drainQueue();
  }
  /**
   * Send the first packet of the queue, and wait for an acknowledgement from the server.
   * @param force - whether to resend a packet that has not been acknowledged yet
   *
   * @private
   */
  _drainQueue(force = false) {
    if (!this.connected || this._queue.length === 0) {
      return;
    }
    const packet = this._queue[0];
    if (packet.pending && !force) {
      return;
    }
    packet.pending = true;
    packet.tryCount++;
    this.flags = packet.flags;
    this.emit.apply(this, packet.args);
  }
  /**
   * Sends a packet.
   *
   * @param packet
   * @private
   */
  packet(packet) {
    packet.nsp = this.nsp;
    this.io._packet(packet);
  }
  /**
   * Called upon engine `open`.
   *
   * @private
   */
  onopen() {
    if (typeof this.auth == "function") {
      this.auth((data) => {
        this._sendConnectPacket(data);
      });
    } else {
      this._sendConnectPacket(this.auth);
    }
  }
  /**
   * Sends a CONNECT packet to initiate the Socket.IO session.
   *
   * @param data
   * @private
   */
  _sendConnectPacket(data) {
    this.packet({
      type: PacketType.CONNECT,
      data: this._pid ? Object.assign({ pid: this._pid, offset: this._lastOffset }, data) : data
    });
  }
  /**
   * Called upon engine or manager `error`.
   *
   * @param err
   * @private
   */
  onerror(err) {
    if (!this.connected) {
      this.emitReserved("connect_error", err);
    }
  }
  /**
   * Called upon engine `close`.
   *
   * @param reason
   * @param description
   * @private
   */
  onclose(reason, description) {
    this.connected = false;
    delete this.id;
    this.emitReserved("disconnect", reason, description);
    this._clearAcks();
  }
  /**
   * Clears the acknowledgement handlers upon disconnection, since the client will never receive an acknowledgement from
   * the server.
   *
   * @private
   */
  _clearAcks() {
    Object.keys(this.acks).forEach((id) => {
      const isBuffered = this.sendBuffer.some((packet) => String(packet.id) === id);
      if (!isBuffered) {
        const ack = this.acks[id];
        delete this.acks[id];
        if (ack.withError) {
          ack.call(this, new Error("socket has been disconnected"));
        }
      }
    });
  }
  /**
   * Called with socket packet.
   *
   * @param packet
   * @private
   */
  onpacket(packet) {
    const sameNamespace = packet.nsp === this.nsp;
    if (!sameNamespace)
      return;
    switch (packet.type) {
      case PacketType.CONNECT:
        if (packet.data && packet.data.sid) {
          this.onconnect(packet.data.sid, packet.data.pid);
        } else {
          this.emitReserved("connect_error", new Error("It seems you are trying to reach a Socket.IO server in v2.x with a v3.x client, but they are not compatible (more information here: https://socket.io/docs/v3/migrating-from-2-x-to-3-0/)"));
        }
        break;
      case PacketType.EVENT:
      case PacketType.BINARY_EVENT:
        this.onevent(packet);
        break;
      case PacketType.ACK:
      case PacketType.BINARY_ACK:
        this.onack(packet);
        break;
      case PacketType.DISCONNECT:
        this.ondisconnect();
        break;
      case PacketType.CONNECT_ERROR:
        this.destroy();
        const err = new Error(packet.data.message);
        err.data = packet.data.data;
        this.emitReserved("connect_error", err);
        break;
    }
  }
  /**
   * Called upon a server event.
   *
   * @param packet
   * @private
   */
  onevent(packet) {
    const args = packet.data || [];
    if (null != packet.id) {
      args.push(this.ack(packet.id));
    }
    if (this.connected) {
      this.emitEvent(args);
    } else {
      this.receiveBuffer.push(Object.freeze(args));
    }
  }
  emitEvent(args) {
    if (this._anyListeners && this._anyListeners.length) {
      const listeners = this._anyListeners.slice();
      for (const listener of listeners) {
        listener.apply(this, args);
      }
    }
    super.emit.apply(this, args);
    if (this._pid && args.length && typeof args[args.length - 1] === "string") {
      this._lastOffset = args[args.length - 1];
    }
  }
  /**
   * Produces an ack callback to emit with an event.
   *
   * @private
   */
  ack(id) {
    const self2 = this;
    let sent = false;
    return function(...args) {
      if (sent)
        return;
      sent = true;
      self2.packet({
        type: PacketType.ACK,
        id,
        data: args
      });
    };
  }
  /**
   * Called upon a server acknowledgement.
   *
   * @param packet
   * @private
   */
  onack(packet) {
    const ack = this.acks[packet.id];
    if (typeof ack !== "function") {
      return;
    }
    delete this.acks[packet.id];
    if (ack.withError) {
      packet.data.unshift(null);
    }
    ack.apply(this, packet.data);
  }
  /**
   * Called upon server connect.
   *
   * @private
   */
  onconnect(id, pid) {
    this.id = id;
    this.recovered = pid && this._pid === pid;
    this._pid = pid;
    this.connected = true;
    this.emitBuffered();
    this._drainQueue(true);
    this.emitReserved("connect");
  }
  /**
   * Emit buffered events (received and emitted).
   *
   * @private
   */
  emitBuffered() {
    this.receiveBuffer.forEach((args) => this.emitEvent(args));
    this.receiveBuffer = [];
    this.sendBuffer.forEach((packet) => {
      this.notifyOutgoingListeners(packet);
      this.packet(packet);
    });
    this.sendBuffer = [];
  }
  /**
   * Called upon server disconnect.
   *
   * @private
   */
  ondisconnect() {
    this.destroy();
    this.onclose("io server disconnect");
  }
  /**
   * Called upon forced client/server side disconnections,
   * this method ensures the manager stops tracking us and
   * that reconnections don't get triggered for this.
   *
   * @private
   */
  destroy() {
    if (this.subs) {
      this.subs.forEach((subDestroy) => subDestroy());
      this.subs = void 0;
    }
    this.io["_destroy"](this);
  }
  /**
   * Disconnects the socket manually. In that case, the socket will not try to reconnect.
   *
   * If this is the last active Socket instance of the {@link Manager}, the low-level connection will be closed.
   *
   * @example
   * const socket = io();
   *
   * socket.on("disconnect", (reason) => {
   *   // console.log(reason); prints "io client disconnect"
   * });
   *
   * socket.disconnect();
   *
   * @return self
   */
  disconnect() {
    if (this.connected) {
      this.packet({ type: PacketType.DISCONNECT });
    }
    this.destroy();
    if (this.connected) {
      this.onclose("io client disconnect");
    }
    return this;
  }
  /**
   * Alias for {@link disconnect()}.
   *
   * @return self
   */
  close() {
    return this.disconnect();
  }
  /**
   * Sets the compress flag.
   *
   * @example
   * socket.compress(false).emit("hello");
   *
   * @param compress - if `true`, compresses the sending data
   * @return self
   */
  compress(compress) {
    this.flags.compress = compress;
    return this;
  }
  /**
   * Sets a modifier for a subsequent event emission that the event message will be dropped when this socket is not
   * ready to send messages.
   *
   * @example
   * socket.volatile.emit("hello"); // the server may or may not receive it
   *
   * @returns self
   */
  get volatile() {
    this.flags.volatile = true;
    return this;
  }
  /**
   * Sets a modifier for a subsequent event emission that the callback will be called with an error when the
   * given number of milliseconds have elapsed without an acknowledgement from the server:
   *
   * @example
   * socket.timeout(5000).emit("my-event", (err) => {
   *   if (err) {
   *     // the server did not acknowledge the event in the given delay
   *   }
   * });
   *
   * @returns self
   */
  timeout(timeout) {
    this.flags.timeout = timeout;
    return this;
  }
  /**
   * Adds a listener that will be fired when any event is emitted. The event name is passed as the first argument to the
   * callback.
   *
   * @example
   * socket.onAny((event, ...args) => {
   *   console.log(`got ${event}`);
   * });
   *
   * @param listener
   */
  onAny(listener) {
    this._anyListeners = this._anyListeners || [];
    this._anyListeners.push(listener);
    return this;
  }
  /**
   * Adds a listener that will be fired when any event is emitted. The event name is passed as the first argument to the
   * callback. The listener is added to the beginning of the listeners array.
   *
   * @example
   * socket.prependAny((event, ...args) => {
   *   console.log(`got event ${event}`);
   * });
   *
   * @param listener
   */
  prependAny(listener) {
    this._anyListeners = this._anyListeners || [];
    this._anyListeners.unshift(listener);
    return this;
  }
  /**
   * Removes the listener that will be fired when any event is emitted.
   *
   * @example
   * const catchAllListener = (event, ...args) => {
   *   console.log(`got event ${event}`);
   * }
   *
   * socket.onAny(catchAllListener);
   *
   * // remove a specific listener
   * socket.offAny(catchAllListener);
   *
   * // or remove all listeners
   * socket.offAny();
   *
   * @param listener
   */
  offAny(listener) {
    if (!this._anyListeners) {
      return this;
    }
    if (listener) {
      const listeners = this._anyListeners;
      for (let i = 0; i < listeners.length; i++) {
        if (listener === listeners[i]) {
          listeners.splice(i, 1);
          return this;
        }
      }
    } else {
      this._anyListeners = [];
    }
    return this;
  }
  /**
   * Returns an array of listeners that are listening for any event that is specified. This array can be manipulated,
   * e.g. to remove listeners.
   */
  listenersAny() {
    return this._anyListeners || [];
  }
  /**
   * Adds a listener that will be fired when any event is emitted. The event name is passed as the first argument to the
   * callback.
   *
   * Note: acknowledgements sent to the server are not included.
   *
   * @example
   * socket.onAnyOutgoing((event, ...args) => {
   *   console.log(`sent event ${event}`);
   * });
   *
   * @param listener
   */
  onAnyOutgoing(listener) {
    this._anyOutgoingListeners = this._anyOutgoingListeners || [];
    this._anyOutgoingListeners.push(listener);
    return this;
  }
  /**
   * Adds a listener that will be fired when any event is emitted. The event name is passed as the first argument to the
   * callback. The listener is added to the beginning of the listeners array.
   *
   * Note: acknowledgements sent to the server are not included.
   *
   * @example
   * socket.prependAnyOutgoing((event, ...args) => {
   *   console.log(`sent event ${event}`);
   * });
   *
   * @param listener
   */
  prependAnyOutgoing(listener) {
    this._anyOutgoingListeners = this._anyOutgoingListeners || [];
    this._anyOutgoingListeners.unshift(listener);
    return this;
  }
  /**
   * Removes the listener that will be fired when any event is emitted.
   *
   * @example
   * const catchAllListener = (event, ...args) => {
   *   console.log(`sent event ${event}`);
   * }
   *
   * socket.onAnyOutgoing(catchAllListener);
   *
   * // remove a specific listener
   * socket.offAnyOutgoing(catchAllListener);
   *
   * // or remove all listeners
   * socket.offAnyOutgoing();
   *
   * @param [listener] - the catch-all listener (optional)
   */
  offAnyOutgoing(listener) {
    if (!this._anyOutgoingListeners) {
      return this;
    }
    if (listener) {
      const listeners = this._anyOutgoingListeners;
      for (let i = 0; i < listeners.length; i++) {
        if (listener === listeners[i]) {
          listeners.splice(i, 1);
          return this;
        }
      }
    } else {
      this._anyOutgoingListeners = [];
    }
    return this;
  }
  /**
   * Returns an array of listeners that are listening for any event that is specified. This array can be manipulated,
   * e.g. to remove listeners.
   */
  listenersAnyOutgoing() {
    return this._anyOutgoingListeners || [];
  }
  /**
   * Notify the listeners for each packet sent
   *
   * @param packet
   *
   * @private
   */
  notifyOutgoingListeners(packet) {
    if (this._anyOutgoingListeners && this._anyOutgoingListeners.length) {
      const listeners = this._anyOutgoingListeners.slice();
      for (const listener of listeners) {
        listener.apply(this, packet.data);
      }
    }
  }
};

// ../../node_modules/.pnpm/socket.io-client@4.8.3/node_modules/socket.io-client/build/esm/contrib/backo2.js
function Backoff(opts) {
  opts = opts || {};
  this.ms = opts.min || 100;
  this.max = opts.max || 1e4;
  this.factor = opts.factor || 2;
  this.jitter = opts.jitter > 0 && opts.jitter <= 1 ? opts.jitter : 0;
  this.attempts = 0;
}
Backoff.prototype.duration = function() {
  var ms = this.ms * Math.pow(this.factor, this.attempts++);
  if (this.jitter) {
    var rand = Math.random();
    var deviation = Math.floor(rand * this.jitter * ms);
    ms = (Math.floor(rand * 10) & 1) == 0 ? ms - deviation : ms + deviation;
  }
  return Math.min(ms, this.max) | 0;
};
Backoff.prototype.reset = function() {
  this.attempts = 0;
};
Backoff.prototype.setMin = function(min) {
  this.ms = min;
};
Backoff.prototype.setMax = function(max) {
  this.max = max;
};
Backoff.prototype.setJitter = function(jitter) {
  this.jitter = jitter;
};

// ../../node_modules/.pnpm/socket.io-client@4.8.3/node_modules/socket.io-client/build/esm/manager.js
var Manager = class extends Emitter {
  constructor(uri, opts) {
    var _a;
    super();
    this.nsps = {};
    this.subs = [];
    if (uri && "object" === typeof uri) {
      opts = uri;
      uri = void 0;
    }
    opts = opts || {};
    opts.path = opts.path || "/socket.io";
    this.opts = opts;
    installTimerFunctions(this, opts);
    this.reconnection(opts.reconnection !== false);
    this.reconnectionAttempts(opts.reconnectionAttempts || Infinity);
    this.reconnectionDelay(opts.reconnectionDelay || 1e3);
    this.reconnectionDelayMax(opts.reconnectionDelayMax || 5e3);
    this.randomizationFactor((_a = opts.randomizationFactor) !== null && _a !== void 0 ? _a : 0.5);
    this.backoff = new Backoff({
      min: this.reconnectionDelay(),
      max: this.reconnectionDelayMax(),
      jitter: this.randomizationFactor()
    });
    this.timeout(null == opts.timeout ? 2e4 : opts.timeout);
    this._readyState = "closed";
    this.uri = uri;
    const _parser = opts.parser || esm_exports;
    this.encoder = new _parser.Encoder();
    this.decoder = new _parser.Decoder();
    this._autoConnect = opts.autoConnect !== false;
    if (this._autoConnect)
      this.open();
  }
  reconnection(v) {
    if (!arguments.length)
      return this._reconnection;
    this._reconnection = !!v;
    if (!v) {
      this.skipReconnect = true;
    }
    return this;
  }
  reconnectionAttempts(v) {
    if (v === void 0)
      return this._reconnectionAttempts;
    this._reconnectionAttempts = v;
    return this;
  }
  reconnectionDelay(v) {
    var _a;
    if (v === void 0)
      return this._reconnectionDelay;
    this._reconnectionDelay = v;
    (_a = this.backoff) === null || _a === void 0 ? void 0 : _a.setMin(v);
    return this;
  }
  randomizationFactor(v) {
    var _a;
    if (v === void 0)
      return this._randomizationFactor;
    this._randomizationFactor = v;
    (_a = this.backoff) === null || _a === void 0 ? void 0 : _a.setJitter(v);
    return this;
  }
  reconnectionDelayMax(v) {
    var _a;
    if (v === void 0)
      return this._reconnectionDelayMax;
    this._reconnectionDelayMax = v;
    (_a = this.backoff) === null || _a === void 0 ? void 0 : _a.setMax(v);
    return this;
  }
  timeout(v) {
    if (!arguments.length)
      return this._timeout;
    this._timeout = v;
    return this;
  }
  /**
   * Starts trying to reconnect if reconnection is enabled and we have not
   * started reconnecting yet
   *
   * @private
   */
  maybeReconnectOnOpen() {
    if (!this._reconnecting && this._reconnection && this.backoff.attempts === 0) {
      this.reconnect();
    }
  }
  /**
   * Sets the current transport `socket`.
   *
   * @param {Function} fn - optional, callback
   * @return self
   * @public
   */
  open(fn) {
    if (~this._readyState.indexOf("open"))
      return this;
    this.engine = new Socket(this.uri, this.opts);
    const socket2 = this.engine;
    const self2 = this;
    this._readyState = "opening";
    this.skipReconnect = false;
    const openSubDestroy = on(socket2, "open", function() {
      self2.onopen();
      fn && fn();
    });
    const onError = (err) => {
      this.cleanup();
      this._readyState = "closed";
      this.emitReserved("error", err);
      if (fn) {
        fn(err);
      } else {
        this.maybeReconnectOnOpen();
      }
    };
    const errorSub = on(socket2, "error", onError);
    if (false !== this._timeout) {
      const timeout = this._timeout;
      const timer = this.setTimeoutFn(() => {
        openSubDestroy();
        onError(new Error("timeout"));
        socket2.close();
      }, timeout);
      if (this.opts.autoUnref) {
        timer.unref();
      }
      this.subs.push(() => {
        this.clearTimeoutFn(timer);
      });
    }
    this.subs.push(openSubDestroy);
    this.subs.push(errorSub);
    return this;
  }
  /**
   * Alias for open()
   *
   * @return self
   * @public
   */
  connect(fn) {
    return this.open(fn);
  }
  /**
   * Called upon transport open.
   *
   * @private
   */
  onopen() {
    this.cleanup();
    this._readyState = "open";
    this.emitReserved("open");
    const socket2 = this.engine;
    this.subs.push(
      on(socket2, "ping", this.onping.bind(this)),
      on(socket2, "data", this.ondata.bind(this)),
      on(socket2, "error", this.onerror.bind(this)),
      on(socket2, "close", this.onclose.bind(this)),
      // @ts-ignore
      on(this.decoder, "decoded", this.ondecoded.bind(this))
    );
  }
  /**
   * Called upon a ping.
   *
   * @private
   */
  onping() {
    this.emitReserved("ping");
  }
  /**
   * Called with data.
   *
   * @private
   */
  ondata(data) {
    try {
      this.decoder.add(data);
    } catch (e) {
      this.onclose("parse error", e);
    }
  }
  /**
   * Called when parser fully decodes a packet.
   *
   * @private
   */
  ondecoded(packet) {
    nextTick(() => {
      this.emitReserved("packet", packet);
    }, this.setTimeoutFn);
  }
  /**
   * Called upon socket error.
   *
   * @private
   */
  onerror(err) {
    this.emitReserved("error", err);
  }
  /**
   * Creates a new socket for the given `nsp`.
   *
   * @return {Socket}
   * @public
   */
  socket(nsp, opts) {
    let socket2 = this.nsps[nsp];
    if (!socket2) {
      socket2 = new Socket2(this, nsp, opts);
      this.nsps[nsp] = socket2;
    } else if (this._autoConnect && !socket2.active) {
      socket2.connect();
    }
    return socket2;
  }
  /**
   * Called upon a socket close.
   *
   * @param socket
   * @private
   */
  _destroy(socket2) {
    const nsps = Object.keys(this.nsps);
    for (const nsp of nsps) {
      const socket3 = this.nsps[nsp];
      if (socket3.active) {
        return;
      }
    }
    this._close();
  }
  /**
   * Writes a packet.
   *
   * @param packet
   * @private
   */
  _packet(packet) {
    const encodedPackets = this.encoder.encode(packet);
    for (let i = 0; i < encodedPackets.length; i++) {
      this.engine.write(encodedPackets[i], packet.options);
    }
  }
  /**
   * Clean up transport subscriptions and packet buffer.
   *
   * @private
   */
  cleanup() {
    this.subs.forEach((subDestroy) => subDestroy());
    this.subs.length = 0;
    this.decoder.destroy();
  }
  /**
   * Close the current socket.
   *
   * @private
   */
  _close() {
    this.skipReconnect = true;
    this._reconnecting = false;
    this.onclose("forced close");
  }
  /**
   * Alias for close()
   *
   * @private
   */
  disconnect() {
    return this._close();
  }
  /**
   * Called when:
   *
   * - the low-level engine is closed
   * - the parser encountered a badly formatted packet
   * - all sockets are disconnected
   *
   * @private
   */
  onclose(reason, description) {
    var _a;
    this.cleanup();
    (_a = this.engine) === null || _a === void 0 ? void 0 : _a.close();
    this.backoff.reset();
    this._readyState = "closed";
    this.emitReserved("close", reason, description);
    if (this._reconnection && !this.skipReconnect) {
      this.reconnect();
    }
  }
  /**
   * Attempt a reconnection.
   *
   * @private
   */
  reconnect() {
    if (this._reconnecting || this.skipReconnect)
      return this;
    const self2 = this;
    if (this.backoff.attempts >= this._reconnectionAttempts) {
      this.backoff.reset();
      this.emitReserved("reconnect_failed");
      this._reconnecting = false;
    } else {
      const delay = this.backoff.duration();
      this._reconnecting = true;
      const timer = this.setTimeoutFn(() => {
        if (self2.skipReconnect)
          return;
        this.emitReserved("reconnect_attempt", self2.backoff.attempts);
        if (self2.skipReconnect)
          return;
        self2.open((err) => {
          if (err) {
            self2._reconnecting = false;
            self2.reconnect();
            this.emitReserved("reconnect_error", err);
          } else {
            self2.onreconnect();
          }
        });
      }, delay);
      if (this.opts.autoUnref) {
        timer.unref();
      }
      this.subs.push(() => {
        this.clearTimeoutFn(timer);
      });
    }
  }
  /**
   * Called upon successful reconnect.
   *
   * @private
   */
  onreconnect() {
    const attempt = this.backoff.attempts;
    this._reconnecting = false;
    this.backoff.reset();
    this.emitReserved("reconnect", attempt);
  }
};

// ../../node_modules/.pnpm/socket.io-client@4.8.3/node_modules/socket.io-client/build/esm/index.js
var cache = {};
function lookup2(uri, opts) {
  if (typeof uri === "object") {
    opts = uri;
    uri = void 0;
  }
  opts = opts || {};
  const parsed = url(uri, opts.path || "/socket.io");
  const source = parsed.source;
  const id = parsed.id;
  const path = parsed.path;
  const sameNamespace = cache[id] && path in cache[id]["nsps"];
  const newConnection = opts.forceNew || opts["force new connection"] || false === opts.multiplex || sameNamespace;
  let io;
  if (newConnection) {
    io = new Manager(source, opts);
  } else {
    if (!cache[id]) {
      cache[id] = new Manager(source, opts);
    }
    io = cache[id];
  }
  if (parsed.query && !opts.query) {
    opts.query = parsed.queryKey;
  }
  return io.socket(parsed.path, opts);
}
Object.assign(lookup2, {
  Manager,
  Socket: Socket2,
  io: lookup2,
  connect: lookup2
});

// src/shared.ts
var PENDING_SESSION_TTL_MS = 5 * 60 * 1e3;
var PORTAL_FILL_PROTOCOL_VERSION = 2;
function isPortalFillProtocolCompatible(protocol4) {
  return protocol4 === PORTAL_FILL_PROTOCOL_VERSION;
}
function isTrustedApiUrl(apiUrl) {
  try {
    const u = new URL(apiUrl);
    const host = u.hostname;
    if (u.protocol === "https:" && (host === "visaai.co" || host.endsWith(".visaai.co")))
      return true;
    if ((u.protocol === "http:" || u.protocol === "https:") && (host === "localhost" || host === "127.0.0.1"))
      return true;
    return false;
  } catch {
    return false;
  }
}

// src/sidepanel.ts
var $ = (id) => document.getElementById(id);
var socket = null;
var boundExecutionId = null;
var fieldCount = 0;
var startRequested = false;
var reviewedRows = [];
async function showStaleRows() {
  const el = document.getElementById("stale");
  if (el) el.style.display = "none";
  const reviewed = reviewedRows;
  reviewedRows = [];
  if (reviewed.length === 0 || !el) return false;
  let rows = [];
  try {
    const res = await chrome.runtime.sendMessage({ type: "pf-page-rows" });
    rows = Array.isArray(res) ? res : [];
  } catch {
    return false;
  }
  const stale = staleRows(rows, reviewed);
  if (stale.length === 0) return false;
  el.textContent = "On IRCC but not in your reviewed application \u2014 delete it on IRCC yourself if it is wrong: " + stale.join(" \xB7 ");
  el.style.display = "block";
  return true;
}
var autoAdvance = false;
var lastAdvancedPath = null;
var advanceFrom = null;
var advanceWatch = null;
var sessionWarningUp = false;
var onInfoPage = false;
var ADVANCE_NAV_MS = 15e3;
var AUTO_ADVANCE_LABEL = "Auto-advance: press Save and continue for me after each page is filled (stops at Summary, never submits)";
var SUMMARY_STOP = "You reached the Summary. Review the summary yourself; nothing was submitted.";
var autoAdvanceAvailable = () => sessionPortalId === "ircc";
function setAdvanceNote(text) {
  const el = document.getElementById("autoAdvanceNote");
  if (!el) return;
  el.textContent = text;
  el.style.display = text ? "block" : "none";
}
function clearAdvanceWatch() {
  if (advanceWatch) clearTimeout(advanceWatch);
  advanceWatch = null;
  advanceFrom = null;
}
function resetAutoAdvance() {
  autoAdvance = false;
  lastAdvancedPath = null;
  clearAdvanceWatch();
  const box = document.getElementById("autoAdvance");
  if (box) box.checked = false;
  const wrap = document.getElementById("autoAdvanceWrap");
  if (wrap) wrap.style.display = autoAdvanceAvailable() ? "block" : "none";
  setAdvanceNote("");
}
function pauseAutoAdvance(reason) {
  if (!autoAdvance) return;
  autoAdvance = false;
  clearAdvanceWatch();
  const box = document.getElementById("autoAdvance");
  if (box) box.checked = false;
  setAdvanceNote(`Auto-advance paused: ${reason} Turn it back on when you are ready.`);
}
document.getElementById("autoAdvance")?.addEventListener("change", (ev) => {
  const on2 = ev.target.checked && autoAdvanceAvailable();
  autoAdvance = on2;
  if (!on2) {
    clearAdvanceWatch();
    ev.target.checked = false;
    setAdvanceNote("");
    return;
  }
  lastAdvancedPath = null;
  setAdvanceNote(
    "Auto-advance is on from the next page that fills. On this page, press Save and continue on IRCC yourself."
  );
});
async function maybeAutoAdvance(left, staleShown) {
  if (!autoAdvance) return;
  const tabId = followTabId;
  if (tabId == null) return pauseAutoAdvance("the IRCC tab could not be found.");
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  const url2 = tab?.url;
  const page = classifyPortalPage(url2, sessionPortalId);
  if (page.kind === "wrong-portal") return pauseAutoAdvance("this tab is on a different IRCC application.");
  if (isTrrtSummaryUrl(url2)) return pauseAutoAdvance(SUMMARY_STOP);
  if (isTrrtInfoUrl(url2)) return;
  if (page.kind !== "form" || !isAutoAdvanceUrl(url2))
    return pauseAutoAdvance("this is not a form page auto-advance knows. Continue on IRCC yourself.");
  const path = followPageKey(url2);
  if (!path) return pauseAutoAdvance("the IRCC page could not be read.");
  if (path === lastAdvancedPath)
    return pauseAutoAdvance("IRCC showed the same page again after Save and continue. Check it for a message.");
  if (sessionWarningUp)
    return pauseAutoAdvance('IRCC is about to sign you out. Click "Continue session" on IRCC first.');
  if (staleShown)
    return pauseAutoAdvance("this page has rows that are not in your reviewed application (listed below). Check them first.");
  if (!Array.isArray(left))
    return pauseAutoAdvance("the assistant could not confirm nothing is left for you on this page. Check it and press Save and continue yourself.");
  if (left.length > 0)
    return pauseAutoAdvance(
      `fill these on this page yourself, then press Save and continue on IRCC: ${left.map(String).join("; ")}.`
    );
  setAdvanceNote("Auto-advance: waiting for the page to settle before Save and continue\u2026");
  let check = null;
  try {
    check = await chrome.tabs.sendMessage(tabId, { type: "advance-check" });
  } catch {
    check = null;
  }
  if (!autoAdvance) return;
  if (!check || typeof check !== "object") return pauseAutoAdvance("the IRCC page could not be read.");
  if (!check.settled)
    return pauseAutoAdvance("the page kept changing (a dialog open or rows still being added). Check it and press Save and continue yourself.");
  if (check.sessionWarning || sessionWarningUp)
    return pauseAutoAdvance('IRCC is about to sign you out. Click "Continue session" on IRCC first.');
  if (Array.isArray(check.errors) && check.errors.length)
    return pauseAutoAdvance(`IRCC shows a message on this page: ${check.errors.slice(0, 3).join(" \xB7 ")}. Fix it, then press Save and continue yourself.`);
  if (Array.isArray(check.required) && check.required.length)
    return pauseAutoAdvance(
      `IRCC still needs an answer to: ${check.required.slice(0, 5).join("; ")}. Answer ${check.required.length === 1 ? "it" : "them"}, then press Save and continue yourself.`
    );
  const again = await chrome.tabs.get(tabId).catch(() => null);
  if (!autoAdvance) return;
  if (followPageKey(again?.url) !== path || boundExecutionId || startRequested)
    return pauseAutoAdvance("the page changed before Save and continue was pressed.");
  lastAdvancedPath = path;
  let res = null;
  try {
    res = await chrome.tabs.sendMessage(tabId, {
      type: "advance-press",
      path,
      rows: check.rows
    });
  } catch {
    res = null;
  }
  if (!res?.pressed)
    return pauseAutoAdvance(`Save and continue was not pressed (${res?.reason ?? "no answer from the page"}).`);
  setAdvanceNote("Auto-advance pressed Save and continue. The next page fills when IRCC opens it.");
  clearAdvanceWatch();
  advanceFrom = path;
  advanceWatch = setTimeout(() => {
    advanceWatch = null;
    void chrome.tabs.get(tabId).then((t) => {
      if (advanceFrom === path && followPageKey(t?.url) === path)
        pauseAutoAdvance("IRCC did not move on after Save and continue. Check the page for a message and fix it.");
    }).catch(() => void 0);
  }, ADVANCE_NAV_MS);
}
var filledThisLaunch = /* @__PURE__ */ new Set();
var answerLabel = (label) => label.replace(/ — (year|month|day)$/, "").replace(/ \(confirm\)$/, "");
var followToken = null;
var runApproval = null;
var interruptedApproval = null;
var RESUME_LABEL = "Continue filling";
var FILL_AGAIN_LABEL = "Fill newly shown questions";
function startRun(approval) {
  runApproval = approval;
  socket?.emit("portal-fill:start", { readbackToken: approval });
}
var sessionPortalId = null;
var followTabId = null;
var lastRunPath = null;
var lastRunServerPaged = false;
var lastRunEditing = false;
var eappButton = () => lastRunEditing ? "Update information" : "Next";
var followTimer = null;
var followLoads = 0;
var lastRunLoad = -1;
var filledScreens = /* @__PURE__ */ new Set();
var pendingScreen = null;
var lastRemaining = [];
async function screenSignature(tabId) {
  try {
    const qs = await chrome.tabs.sendMessage(tabId, { type: "screen-questions" });
    return Array.isArray(qs) && qs.length > 0 ? qs.join("\n") : null;
  } catch {
    return null;
  }
}
function showNeverFilled() {
  const never = lastRemaining.filter((l) => !filledThisLaunch.has(answerLabel(l)));
  if (never.length === 0) return;
  const el = document.getElementById("next");
  if (!el) return;
  el.textContent = `Not filled \u2014 the assistant never found these questions on a screen (IRCC may have changed their wording): ${never.join(", ")}. Check them on "Review your answers" and answer them yourself.`;
  el.style.display = "block";
}
var FOLLOW_SETTLE_MS = 2500;
function followTo(tabId, url2) {
  if (tabId === followTabId) onInfoPage = isTrrtInfoUrl(url2);
  if (tabId !== followTabId || !isPortalUrl(url2)) return;
  const page = classifyPortalPage(url2, sessionPortalId);
  if (advanceFrom && followPageKey(url2) !== advanceFrom) clearAdvanceWatch();
  if (autoAdvance && onInfoPage && page.kind !== "wrong-portal")
    setAdvanceNote(
      'Auto-advance stays on. This page only explains what you chose: press "Continue to application" on IRCC yourself, and auto-advance carries on from the next page.'
    );
  else if (autoAdvance) {
    if (page.kind === "wrong-portal") pauseAutoAdvance("this tab is on a different IRCC application.");
    else if (page.kind === "error") pauseAutoAdvance("IRCC showed its error page.");
    else if (isTrrtSummaryUrl(url2)) pauseAutoAdvance(SUMMARY_STOP);
    else if (page.kind !== "form") pauseAutoAdvance("this is not a form page auto-advance knows.");
    else if (!isAutoAdvanceUrl(url2))
      pauseAutoAdvance("this page is not one auto-advance knows. Check it and continue on IRCC yourself.");
  }
  if (page.kind !== "form") {
    if (followTimer) clearTimeout(followTimer);
    followTimer = null;
    lastRunPath = null;
    showError("");
    setStatus(page.message ?? "");
    if (page.kind === "review") showNeverFilled();
    return;
  }
  const path = followPageKey(url2);
  if (!path) return;
  if (path === lastRunPath && !(isServerPagedUrl(url2) && followLoads !== lastRunLoad)) return;
  const load = followLoads;
  if (followTimer) clearTimeout(followTimer);
  followTimer = setTimeout(() => {
    followTimer = null;
    void (async () => {
      const tab = await chrome.tabs.get(tabId).catch(() => null);
      if (!tab || !isPortalUrl(tab.url) || followPageKey(tab.url) !== path) return;
      if (followLoads !== load) return;
      if (!followToken || !socket?.connected || boundExecutionId || startRequested) return;
      let screen = null;
      if (isServerPagedUrl(tab.url)) {
        screen = await screenSignature(tabId);
        if (followLoads !== load || !followToken || boundExecutionId || startRequested) return;
        if (screen && filledScreens.has(screen)) {
          lastRunPath = path;
          lastRunLoad = load;
          showError("");
          setStatus(
            `This screen was filled already, so it is left as it is \u2014 your own changes stay. Check it and press ${isEappEditUrl(tab.url) ? "Update information" : "Next"} on IRCC.`
          );
          return;
        }
      }
      pendingScreen = screen;
      const approval = followToken;
      followToken = null;
      lastRunPath = path;
      lastRunLoad = load;
      startRequested = true;
      showError("");
      setStatus("New page \u2014 filling verified fields\u2026");
      startRun(approval);
    })();
  }, FOLLOW_SETTLE_MS);
}
chrome.tabs?.onUpdated?.addListener((tabId, changeInfo, tab) => {
  if (tab?.active && (changeInfo.url || tab.url)) showTipsFor(changeInfo.url ?? tab.url);
  if (tabId === followTabId && changeInfo.status === "loading") followLoads += 1;
  if (!changeInfo.url && changeInfo.status !== "complete") return;
  followTo(tabId, changeInfo.url ?? tab?.url);
});
function isEtaUrl(url2) {
  try {
    return new URL(url2 ?? "").hostname.toLowerCase() === "eta.onlineservices-servicesenligne.apps.cic.gc.ca";
  } catch {
    return false;
  }
}
function showTipsFor(url2) {
  if (!isPortalUrl(url2)) return;
  const eta = isEtaUrl(url2);
  const ircc = document.getElementById("ircc-tips");
  const etaTips = document.getElementById("eta-tips");
  if (ircc) ircc.style.display = eta ? "none" : "";
  if (etaTips) etaTips.style.display = eta ? "" : "none";
}
chrome.tabs?.onActivated?.addListener(({ tabId }) => {
  void chrome.tabs.get(tabId).then((tab) => showTipsFor(tab?.url)).catch(() => void 0);
});
void chrome.tabs?.query?.({ active: true, currentWindow: true })?.then((tabs) => showTipsFor(tabs?.[0]?.url))?.catch(() => void 0);
var readbackToken = null;
var resumeToken = null;
async function takePendingSession() {
  const stored = await chrome.storage.local.get("pendingSession");
  const pending = stored.pendingSession;
  if (!pending) return;
  await chrome.storage.local.remove("pendingSession");
  chrome.runtime.sendMessage({ type: "session-consumed" }).catch(() => {
  });
  if (pending.token === connectedToken) return;
  if (typeof pending.receivedAt === "number" && Date.now() - pending.receivedAt < PENDING_SESSION_TTL_MS) {
    readbackToken = pending.readbackToken ?? null;
    connect(pending.apiUrl, pending.token);
  }
}
var connectedToken = null;
void takePendingSession();
chrome.storage.onChanged?.addListener((changes, area) => {
  if (area !== "local" || !changes.pendingSession?.newValue) return;
  void takePendingSession();
});
$("connectBtn").addEventListener("click", () => {
  const apiUrl = $("apiUrl").value.trim();
  const token = $("token").value.trim();
  if (!apiUrl || !token) {
    showError("Enter both API URL and token");
    return;
  }
  connect(apiUrl, token);
});
function connect(apiUrl, token) {
  showError("");
  if (!isTrustedApiUrl(apiUrl)) {
    showError("That API URL is not a VisaAI server. Start the fill from the VisaAI submission page.");
    setStatus("Not connected.");
    return;
  }
  connectedToken = token;
  socket?.disconnect();
  resumeToken = null;
  followToken = null;
  lastRunPath = null;
  sessionPortalId = null;
  resetAutoAdvance();
  sessionWarningUp = false;
  bindGaveUp = false;
  filledThisLaunch.clear();
  filledScreens.clear();
  lastRemaining = [];
  runApproval = null;
  interruptedApproval = null;
  socket = lookup2(`${apiUrl}/automation`, {
    transports: ["websocket"],
    // Evaluated on every (re)connect: the first handshake spends the connect
    // token, every later one the latest resume token the server issued.
    auth: (cb) => cb(resumeToken ? { resumeToken } : { token })
  });
  socket.on("connect", () => {
    setStatus("Connected. Authenticating\u2026");
  });
  socket.on("automation:ready", (data) => {
    resumeToken = typeof data?.resumeToken === "string" ? data.resumeToken : null;
    if (typeof data?.portalId === "string" && data.portalId) {
      const changed = sessionPortalId !== data.portalId;
      sessionPortalId = data.portalId;
      if (changed) resetAutoAdvance();
    }
    if (data?.resumed === true) {
      setStatus("Reconnected.");
      if (!readbackToken && followToken) {
        setStatus("Reconnected. The next IRCC page you open fills automatically.");
        return;
      }
      if (!readbackToken && interruptedApproval) {
        followToken = interruptedApproval;
        interruptedApproval = null;
        lastRunPath = null;
        showError("");
        setStatus(
          `The connection dropped while filling, so the fill paused. Nothing after the last checked field was written. Click "${RESUME_LABEL}" to finish.`
        );
        const again = document.getElementById("fillAgain");
        if (again) {
          again.textContent = RESUME_LABEL;
          again.style.display = "block";
        }
        return;
      }
      if (!readbackToken) {
        showError(
          "The connection dropped, so the fill was stopped. Nothing further was written \u2014 check the form, then start the fill again from the VisaAI submission page."
        );
        return;
      }
    }
    if (!readbackToken) {
      setStatus("Connected \u2014 review only.");
      showError(
        "No execution approval was handed off. Start the fill from the VisaAI submission page."
      );
      return;
    }
    setStatus("Authenticated. Requesting verified fill\u2026");
    $("connect").style.display = "none";
    $("session").style.display = "block";
    startRequested = true;
    const approval = readbackToken;
    readbackToken = null;
    startRun(approval);
  });
  socket.on(
    "portal-fill:stage",
    async (msg, ack) => {
      if (!isPortalFillProtocolCompatible(msg?.protocol)) {
        showError("Extension is out of date for this server. Update it and retry.");
        ack?.({ bound: false });
        return;
      }
      if (msg.stage === "started") {
        if (!startRequested) {
          showError("Ignored an unrequested fill. Start the fill from the VisaAI submission page.");
          ack?.({ bound: false });
          return;
        }
        startRequested = false;
        let tabId = await resolvePortalTab();
        if (tabId == null) {
          if (!portalNotice) setStatus("Switch to the IRCC tab \u2014 filling starts as soon as it is in front.");
          tabId = await waitForPortalTab(PORTAL_TAB_WAIT_MS);
        }
        if (tabId == null) {
          startRequested = true;
          bindGaveUp = true;
          if (portalNotice) {
            showError(
              'The launch timed out before a form page of your application was open. Sign in and open the draft on IRCC, then click "Launch assistant" on VisaAI again.'
            );
            setStatus(portalNotice);
          } else {
            showError("Open the government portal tab in this window, then retry.");
            setStatus("No portal tab found.");
          }
          ack?.({ bound: false });
          return;
        }
        const res = await chrome.runtime.sendMessage({
          type: "pf-bind-session",
          executionId: msg.executionId,
          tabId
        });
        if (!res?.ok) {
          startRequested = true;
          showError("Could not bind the portal tab.");
          ack?.({ bound: false });
          return;
        }
        boundExecutionId = msg.executionId;
        bindGaveUp = false;
        reviewedRows = [];
        const staleEl = document.getElementById("stale");
        if (staleEl) staleEl.style.display = "none";
        followTabId = tabId;
        const boundTab = await chrome.tabs.get(tabId).catch(() => null);
        lastRunPath = followPageKey(boundTab?.url) ?? lastRunPath;
        lastRunLoad = followLoads;
        lastRunServerPaged = isServerPagedUrl(boundTab?.url);
        lastRunEditing = isEappEditUrl(boundTab?.url);
        if (lastRunServerPaged) {
          const screen = pendingScreen ?? await screenSignature(tabId);
          if (screen) filledScreens.add(screen);
        }
        pendingScreen = null;
        fieldCount = 0;
        $("steps").innerHTML = "";
        const next = document.getElementById("next");
        if (next) next.style.display = "none";
        const again = document.getElementById("fillAgain");
        if (again) again.style.display = "none";
        setStatus("Filling verified fields\u2026");
        ack?.({ bound: true, executionId: msg.executionId });
        return;
      }
      if (msg.stage === "completed") {
        runApproval = null;
        if (Array.isArray(msg.remaining)) {
          setStatus(
            `Filled ${fieldCount} verified ${fieldCount === 1 ? "entry" : "entries"} on this form. Check ${fieldCount === 1 ? "it" : "them"}.`
          );
          showRemaining(msg.remaining);
          pauseAutoAdvance("this page is not one auto-advance knows.");
          await showMissingUploads();
          await unbind();
          ack?.({ ok: true });
          return;
        }
        setStatus(
          `This page is filled: ${fieldCount} verified ${fieldCount === 1 ? "entry" : "entries"}. ` + (autoAdvance ? 'Auto-advance checks it before pressing "Save and continue".' : 'Check it, then click "Save and continue" on IRCC \u2014 the next page fills automatically.')
        );
        showNext(msg.nextPage ?? null);
        const staleShown = await showStaleRows();
        await showMissingUploads();
        await unbind();
        ack?.({ ok: true });
        await maybeAutoAdvance(msg.left, staleShown);
        return;
      }
      if (msg.stage === "failed" && bindGaveUp) {
        ack?.({ ok: true });
        return;
      }
      if (msg.stage === "failed") {
        runApproval = null;
        if (!onInfoPage)
          pauseAutoAdvance("a field on this page did not fill and verify. Fill the rest yourself, then press Save and continue.");
        showError(
          `Stopped at "${msg.failedLabel ?? msg.failedFieldKey ?? "unknown field"}" (${msg.reason ?? "unknown"}). Nothing after it was written \u2014 fill the rest of this page yourself.`
        );
        setStatus("Stopped on an unverified field.");
        showNext(msg.nextPage ?? null);
        await unbind();
        ack?.({ ok: true });
      }
    }
  );
  socket.on(
    "portal-fill:probe",
    async (msg, ack) => {
      const reply = (results, page) => ack?.({
        protocol: PORTAL_FILL_PROTOCOL_VERSION,
        kind: "probe_result",
        executionId: msg?.executionId,
        results,
        // Which IRCC page is open (path only). The server fills that page's
        // group and nothing else.
        ...page ? { page } : {}
      });
      if (!isPortalFillProtocolCompatible(msg?.protocol) || !boundExecutionId || msg.executionId !== boundExecutionId) {
        ack?.({ protocol: PORTAL_FILL_PROTOCOL_VERSION, kind: "probe_result", executionId: msg?.executionId, results: [] });
        return;
      }
      setStatus("Checking the portal page\u2026");
      const res = await chrome.runtime.sendMessage({
        type: "pf-probe",
        selectors: msg.selectors,
        ...Array.isArray(msg.ops) ? { ops: msg.ops } : {},
        ...Array.isArray(msg.awaitOptions) ? { awaitOptions: msg.awaitOptions.map((a) => a === true) } : {}
      });
      reply(res?.results ?? [], typeof res?.page === "string" ? res.page : null);
    }
  );
  socket.on(
    "portal-fill:write",
    async (command, ack) => {
      const result = await executeField(command);
      ack?.(result);
    }
  );
  socket.on(
    "portal-fill:renewed",
    (msg) => {
      if (!isPortalFillProtocolCompatible(msg?.protocol ?? -1)) return;
      if (typeof msg?.resumeToken === "string") resumeToken = msg.resumeToken;
      if (typeof msg?.readbackToken !== "string") return;
      followToken = msg.readbackToken;
      if (followTabId != null) {
        const id = followTabId;
        void chrome.tabs.get(id).then((tab) => followTo(id, tab?.url)).catch(() => void 0);
      }
    }
  );
  socket.on("automation:error", (data) => {
    if (bindGaveUp && /did not bind/i.test(data?.message ?? "")) {
      bindGaveUp = false;
      void unbind();
      return;
    }
    if (/can no longer be resumed|invalid or expired session token/i.test(data?.message ?? "")) {
      endSession();
      return;
    }
    if (autoAdvance && !(onInfoPage && /no reviewed values for this page/i.test(data?.message ?? "")) && !/can no longer be resumed|invalid or expired session token/i.test(data?.message ?? ""))
      pauseAutoAdvance(
        /no reviewed values for this page/i.test(data?.message ?? "") ? "nothing is mapped on this page. Answer what IRCC asks and press Save and continue yourself." : "the assistant could not fill this page."
      );
    if (/no reviewed values for this page/i.test(data?.message ?? "")) {
      setStatus("Nothing to fill on this page. Continue on IRCC \u2014 the next page fills automatically.");
      showError("");
    } else if (/^Nothing to fill on this screen/i.test(data?.message ?? "")) {
      setStatus(data.message.replace(/press Next\b/, `press ${eappButton()}`));
      showError("");
    } else {
      showError(data.message);
    }
    void showMissingUploads().then(unbind);
  });
  socket.on("connect_error", (err) => {
    showError(`Connection failed: ${err.message}`);
  });
  socket.on("disconnect", (reason) => {
    if ((boundExecutionId || startRequested) && runApproval) interruptedApproval = runApproval;
    runApproval = null;
    void unbind();
    if (reason !== "io server disconnect" && reason !== "io client disconnect" && resumeToken) {
      setStatus("Connection lost \u2014 reconnecting\u2026");
    } else if (reason === "io server disconnect") {
      endSession();
    }
  });
}
async function executeField(command) {
  const fail = (reason) => ({
    protocol: PORTAL_FILL_PROTOCOL_VERSION,
    kind: "field_result",
    executionId: command?.executionId ?? "",
    fieldKey: command?.fieldKey ?? "",
    outcome: "failed",
    reason,
    selectorFound: false
  });
  if (!isPortalFillProtocolCompatible(command?.protocol)) return fail("dom_change");
  if (!boundExecutionId || command.executionId !== boundExecutionId) {
    return fail("transport_error");
  }
  if (command.op === "dialog_open" && command.mappedValue) reviewedRows.push(command.mappedValue);
  const row = document.createElement("div");
  row.className = "step";
  row.textContent = command.label || command.fieldKey;
  $("steps").appendChild(row);
  try {
    const res = await chrome.runtime.sendMessage({
      type: "pf-execute-field",
      command
    });
    if (!res) {
      row.classList.add("fail");
      return fail("transport_error");
    }
    const ok = res.outcome === "verified";
    row.classList.add(ok ? "done" : "fail");
    if (ok) {
      fieldCount += 1;
      filledThisLaunch.add(answerLabel(command.label || command.fieldKey));
    }
    return res;
  } catch {
    row.classList.add("fail");
    return fail("transport_error");
  }
}
async function resolvePortalTab() {
  const tabs = await chrome.tabs.query({ currentWindow: true });
  const id = pickActivePortalTab(tabs);
  if (id == null) return null;
  portalNotice = null;
  const tab = tabs.find((t) => t.id === id);
  const page = classifyPortalPage(tab?.url, sessionPortalId);
  if (page.kind === "form" && tab?.status === "loading") return null;
  if (page.kind === "form") return id;
  portalNotice = page.message ?? null;
  setStatus(portalNotice ?? "");
  return null;
}
var portalNotice = null;
var bindGaveUp = false;
var PORTAL_TAB_WAIT_MS = 17e4;
async function waitForPortalTab(ms) {
  const deadline = Date.now() + ms;
  while (Date.now() < deadline) {
    await new Promise((r) => setTimeout(r, 500));
    const id = await resolvePortalTab();
    if (id == null) continue;
    await new Promise((r) => setTimeout(r, FOLLOW_SETTLE_MS));
    if (await resolvePortalTab() === id) return id;
  }
  return null;
}
async function unbind() {
  startRequested = false;
  if (!boundExecutionId) return;
  boundExecutionId = null;
  try {
    await chrome.runtime.sendMessage({ type: "pf-unbind-session" });
  } catch {
  }
}
function showRemaining(all) {
  lastRemaining = all;
  const remaining = all.filter((l) => !filledThisLaunch.has(answerLabel(l)));
  const el = document.getElementById("next");
  const again = document.getElementById("fillAgain");
  if (lastRunServerPaged) {
    if (el) {
      el.textContent = remaining.length ? `Check this screen, then press ${eappButton()} on IRCC \u2014 the next question the assistant has an answer for fills when it opens.` : 'Every reviewed answer is filled. Continue to "Review your answers" and check them: the assistant stops there.';
      el.style.display = "block";
    }
    if (again) again.style.display = "none";
    return;
  }
  if (el) {
    el.textContent = remaining.length ? `Not on the form yet: ${remaining.join(", ")}. Answer the questions shown and press the form's Next button, then "Fill newly shown questions".` : "Every reviewed answer is filled. Complete the rest of the form, the declaration, your signature and the payment yourself.";
    el.style.display = "block";
  }
  if (again) again.style.display = remaining.length ? "block" : "none";
}
var SESSION_ENDED_MESSAGE = 'The connection to VisaAI ended, so nothing more will be filled. Go to the VisaAI submission page and click "Launch assistant" again \u2014 answers already on the form stay there.';
function endSession() {
  pauseAutoAdvance("the connection to VisaAI ended.");
  followToken = null;
  startRequested = false;
  if (followTimer) clearTimeout(followTimer);
  followTimer = null;
  const again = document.getElementById("fillAgain");
  if (again) again.style.display = "none";
  setStatus("Disconnected.");
  showError(SESSION_ENDED_MESSAGE);
}
function fillAgain() {
  if (!socket?.connected) {
    endSession();
    return;
  }
  if (!followToken || boundExecutionId || startRequested) {
    showError(followToken ? "A fill is already running." : "Not ready yet \u2014 wait a moment and try again.");
    return;
  }
  const approval = followToken;
  followToken = null;
  startRequested = true;
  showError("");
  const again = document.getElementById("fillAgain");
  const resuming = again?.textContent === RESUME_LABEL;
  if (again) {
    again.style.display = "none";
    again.textContent = FILL_AGAIN_LABEL;
  }
  setStatus(resuming ? "Continuing the fill\u2026" : "Filling newly shown questions\u2026");
  startRun(approval);
}
document.getElementById("fillAgain")?.addEventListener("click", fillAgain);
function showNext(next) {
  const el = document.getElementById("next");
  if (!el) return;
  el.textContent = next ? `Next page with values to fill: "${next.title}". Save this page on IRCC and continue \u2014 keep this panel open and it fills automatically.` : (
    // Null also on a page outside the form (IRCC's opening questions,
    // live 2026-10-18), where "no later page" was false: every form page
    // was still ahead.
    "Continue on IRCC. Keep this panel open \u2014 each page the assistant has values for fills when you reach it."
  );
  el.style.display = "block";
}
async function showMissingUploads() {
  const el = document.getElementById("uploads");
  if (el) el.style.display = "none";
  const pr = !!lastRunPath && onPrCasePage(lastRunPath);
  if (!el || !(lastRunPath?.endsWith("/doc-upload") || pr) || !boundExecutionId) return;
  let rows = [];
  try {
    const res = await chrome.runtime.sendMessage({ type: "pf-upload-status" });
    rows = Array.isArray(res) ? res : [];
  } catch {
    return;
  }
  const missing = rows.filter((r) => !r.uploaded).map((r) => r.name);
  el.textContent = pr ? missing.length ? `Still required before you can submit on IRCC: ${missing.join(" \xB7 ")}. Upload ${missing.length === 1 ? "it" : "them"} on IRCC yourself \u2014 IMM 1344, 5532 and 5533 must be signed first, or IRCC returns the application.` : rows.length ? "Every required document shows a file. Check each one, then complete the consent and declaration and submit on IRCC yourself \u2014 paying, signing and submitting are yours." : "" : missing.length ? `Still required before IRCC lets you pay: ${missing.join(" \xB7 ")}. Upload ${missing.length === 1 ? "it" : "them"} on IRCC yourself \u2014 a form that needs a signature (such as IMM 5476) must be signed first, or IRCC returns the application.` : rows.length ? "Every required document is uploaded. Check each file, then continue on IRCC to Fees \u2014 the fees, declaration, signature and payment are yours." : "";
  el.style.display = el.textContent ? "block" : "none";
}
chrome.runtime.onMessage?.addListener((msg, sender) => {
  if (msg?.type !== "portal-session-warning") return;
  if (followTabId != null && sender.tab?.id !== followTabId) return;
  sessionWarningUp = msg.shown === true;
  if (sessionWarningUp) pauseAutoAdvance('IRCC is about to sign you out. Click "Continue session" on IRCC first.');
  const el = document.getElementById("sessionWarning");
  if (!el) return;
  el.textContent = msg.shown ? 'IRCC will sign you out in a few minutes. Go to the IRCC tab and click "Continue session" \u2014 answers you have not saved on that page are lost if it signs you out.' : "";
  el.style.display = msg.shown ? "block" : "none";
});
function setStatus(text) {
  $("status").textContent = text;
}
function showError(text) {
  $("error").textContent = text;
}
export {
  ADVANCE_NAV_MS,
  AUTO_ADVANCE_LABEL,
  FILL_AGAIN_LABEL,
  FOLLOW_SETTLE_MS,
  PORTAL_TAB_WAIT_MS,
  RESUME_LABEL,
  SESSION_ENDED_MESSAGE,
  SUMMARY_STOP,
  answerLabel,
  isEtaUrl
};
//# sourceMappingURL=sidepanel.js.map
