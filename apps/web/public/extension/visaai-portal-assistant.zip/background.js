// src/portal-messaging.ts
async function sendToPortalTab(tabId, message) {
  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    if (!/Receiving end does not exist|Could not establish connection/i.test(msg)) throw err;
    if (!chrome.scripting?.executeScript) throw err;
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    return await chrome.tabs.sendMessage(tabId, message);
  }
}

// src/portal-page.ts
var OPEN_DRAFT = 'open your application with "Continue" on the draft in your IRCC account. Keep this panel open \u2014 the next form page fills automatically.';
var MESSAGES = {
  signin: `Sign in to your IRCC account (you do this \u2014 the assistant never enters passwords), then ${OPEN_DRAFT}`,
  // IRCC shows its terms and sign-in steps at the same address after a
  // sign-out (live 2026-10-17), so this page may still need a sign-in.
  account: `You are on your IRCC account pages. Accept the terms and sign in if IRCC asks (you do this yourself), then ${OPEN_DRAFT}`,
  error: "IRCC showed its error page \u2014 usually an expired session or a bookmarked link. Nothing you saved is lost. Go to your IRCC account, sign in if asked, then " + OPEN_DRAFT,
  yours: "This page is yours: the assistant never fills fees, the declaration, your signature or payment. Complete it on IRCC yourself.",
  language: 'Switch the Permanent Residence Portal to English (the "English" link at the top of the page). The assistant fills its English pages only; nothing is written on a French page.',
  review: 'The questionnaire is done: the assistant stops here. Check every answer on this list (use "Modify my Answers" to correct one), then continue to your document checklist yourself. Uploads, signature and payment are yours.'
};
function isSignIn(host, path) {
  if (host === "portal-portail.apps.cic.gc.ca") return /^\/(signin|sign-in|login|logout)\b/i.test(path);
  if (host === "onlineservices-servicesenligne.cic.gc.ca") return /\/(mycic\/start|signin|login)\b/i.test(path);
  if (host === "ircc.canada.ca") return /\/portal\b/i.test(path);
  if (host === PR_HOST) return /^\/(en|fr)\/(login|logout)\b/i.test(path);
  return /(^|\.)clegc-gckey\.gc\.ca$/.test(host);
}
var YOURS = /^\/(fees?|pay|payment|consent|declaration|e-?sign|signature|complete|confirmation|submit)(\/|$|-)/i;
var PR_HOST = "prson-srpel.apps.cic.gc.ca";
var PR_YOURS = /\/(fee|fees|payment|declaration|consent|submit|submission)(\/|$|-)/i;
var EAPP_HOST = "onlineservices-servicesenligne.cic.gc.ca";
var EAPP_AFTER = /^\/eapp\/(comeToCanadaReviewPage|previousAnswers|comeToCanadaInstructions|documentsToSubmit|comeToCanadaResult|comeToCanadaHowToApply)\b/i;
var FLOW_OF_PORTAL = {
  ircc: "trrt",
  "ircc-eta": "eta",
  "ircc-study": "eapp",
  "ircc-work": "eapp",
  "ircc-pr-family": "pr"
};
var GO_TO = {
  trrt: "This visa is applied for on the IRCC Portal \u2014 sign in at portal-portail.apps.cic.gc.ca and start or continue your visitor visa application.",
  eta: "An eTA is applied for on its own IRCC form \u2014 open onlineservices-servicesenligne.cic.gc.ca/eta/welcome and start or continue your eTA application there.",
  eapp: 'This permit is applied for in your IRCC secure account \u2014 sign in, choose "Apply to come to Canada" and answer the eligibility questionnaire there.',
  pr: "This application is made on the IRCC Permanent Residence Portal \u2014 sign in at prson-srpel.apps.cic.gc.ca and open your application there."
};
var WRONG_PAGE = " This tab is on a different IRCC application, so the assistant fills nothing here. Keep this panel open \u2014 the right page fills automatically once you open it.";
function flowOfUrl(host, path) {
  if (host === "tr-rt.apps.cic.gc.ca") return "trrt";
  if (host === PR_HOST) return "pr";
  if (host === "eta.onlineservices-servicesenligne.apps.cic.gc.ca") return "eta";
  if (host === EAPP_HOST && /^\/eta\//i.test(path)) return "eta";
  if (host === EAPP_HOST && /^\/eapp\//i.test(path)) return "eapp";
  return null;
}
function classifyPortalPage(url, portalId) {
  const page = classifyUnscoped(url);
  const expected = portalId ? FLOW_OF_PORTAL[portalId] : void 0;
  if (!expected) return page;
  let u;
  try {
    u = new URL(url ?? "");
  } catch {
    return page;
  }
  const flow = flowOfUrl(u.hostname.toLowerCase(), u.pathname);
  if (flow && flow !== expected) return { kind: "wrong-portal", message: GO_TO[expected] + WRONG_PAGE };
  return page;
}
function classifyUnscoped(url) {
  let u;
  try {
    u = new URL(url ?? "");
  } catch {
    return { kind: "form" };
  }
  const host = u.hostname.toLowerCase();
  const path = u.pathname;
  if (isSignIn(host, path)) return { kind: "signin", message: MESSAGES.signin };
  if (host === "portal-portail.apps.cic.gc.ca") return { kind: "account", message: MESSAGES.account };
  if (host === EAPP_HOST && EAPP_AFTER.test(path)) return { kind: "review", message: MESSAGES.review };
  if (host === PR_HOST) {
    if (/^\/(en|fr)\/application\/(dashboard|start)\b/i.test(path)) return { kind: "account", message: MESSAGES.account };
    if (PR_YOURS.test(path)) return { kind: "yours", message: MESSAGES.yours };
    if (/^\/fr\//i.test(path)) return { kind: "language", message: MESSAGES.language };
  }
  if (host === "tr-rt.apps.cic.gc.ca") {
    if (/^\/error\b/i.test(path)) return { kind: "error", message: MESSAGES.error };
    if (path === "/" || /^\/landing-page\b/i.test(path)) return { kind: "account", message: MESSAGES.account };
    if (YOURS.test(path)) return { kind: "yours", message: MESSAGES.yours };
  }
  return { kind: "form" };
}

// src/portal-tab.ts
var PORTAL_HOSTS = [/\.cic\.gc\.ca$/, /\.canada\.ca$/, /^cic\.gc\.ca$/, /^canada\.ca$/];
function isPortalUrl(url) {
  if (!url) return false;
  try {
    const u = new URL(url);
    return u.protocol === "https:" && PORTAL_HOSTS.some((re) => re.test(u.hostname));
  } catch {
    return false;
  }
}
function pickPortalTabToFocus(tabs, pages) {
  const portals = tabs.filter((t) => t.id != null && isPortalUrl(t.url));
  if (portals.length === 0) return null;
  const recent = (a, b) => (b.lastAccessed ?? 0) - (a.lastAccessed ?? 0);
  const forms = portals.filter((t) => classifyPortalPage(t.url).kind === "form").sort(recent);
  const others = portals.filter((t) => classifyPortalPage(t.url).kind !== "form").sort(recent);
  if (!pages) return (forms[0] ?? others[0]).id;
  const roots = new Set(pages.map(rootOf));
  const ours = forms.find((t) => roots.has(rootOf(pathOf(t.url))));
  const foreign = (t) => rootOf(pathOf(t.url)) === "eta" !== roots.has("eta");
  return (ours ?? others[0] ?? forms.find((t) => !foreign(t)))?.id ?? null;
}
function pathOf(url) {
  try {
    return new URL(url ?? "").pathname;
  } catch {
    return "";
  }
}
function rootOf(path) {
  return path.split("/")[1] ?? "";
}

// src/shared.ts
var PENDING_SESSION_TTL_MS = 5 * 60 * 1e3;
var PORTAL_FILL_PROTOCOL_VERSION = 2;
function isPortalFillProtocolCompatible(protocol) {
  return protocol === PORTAL_FILL_PROTOCOL_VERSION;
}
function isTrustedApiUrl(apiUrl) {
  try {
    const u = new URL(apiUrl);
    const host = u.hostname;
    if (u.protocol === "https:" && (host === "visaai.co" || host.endsWith(".visaai.co")))
      return true;
    if ((u.protocol === "http:" || u.protocol === "https:") && (host === "localhost" || host === "127.0.0.1"))
      return true;
    return false;
  } catch {
    return false;
  }
}

// src/background.ts
void chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
var HANDLED_KEY = "handledSessionTokens";
var HANDLED_MAX = 10;
async function tokenHash(token) {
  const bytes = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(token)));
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}
async function wasHandled(token) {
  const h = await tokenHash(token);
  const stored = await chrome.storage.local.get(HANDLED_KEY);
  const list = Array.isArray(stored[HANDLED_KEY]) ? stored[HANDLED_KEY] : [];
  return list.includes(h);
}
async function markHandled(token) {
  const h = await tokenHash(token);
  const stored = await chrome.storage.local.get(HANDLED_KEY);
  const list = Array.isArray(stored[HANDLED_KEY]) ? stored[HANDLED_KEY] : [];
  if (!list.includes(h)) await chrome.storage.local.set({ [HANDLED_KEY]: [...list, h].slice(-HANDLED_MAX) });
}
var PENDING_PURGE_ALARM = "purge-pending-session";
async function purgeStalePendingSession() {
  const stored = await chrome.storage.local.get("pendingSession");
  const pending = stored.pendingSession;
  if (!pending) return;
  if (typeof pending.receivedAt === "number" && Date.now() - pending.receivedAt < PENDING_SESSION_TTL_MS) return;
  await chrome.storage.local.remove("pendingSession");
  await chrome.action.setBadgeText({ text: "" });
}
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === PENDING_PURGE_ALARM) void purgeStalePendingSession().catch(() => {
  });
});
chrome.runtime.onStartup.addListener(() => {
  void purgeStalePendingSession().catch(() => {
  });
});
void purgeStalePendingSession().catch(() => {
});
function isTrustedSenderOrigin(origin) {
  if (!origin) return false;
  try {
    const u = new URL(origin);
    const host = u.hostname;
    if (u.protocol === "https:" && (host === "visaai.co" || host.endsWith(".visaai.co")))
      return true;
    if ((u.protocol === "http:" || u.protocol === "https:") && (host === "localhost" || host === "127.0.0.1"))
      return true;
    return false;
  } catch {
    return false;
  }
}
function portalPagesOf(v) {
  if (!Array.isArray(v)) return void 0;
  const pages = v.filter((p) => typeof p === "string" && p.startsWith("/") && p.length <= 200).slice(0, 50);
  return pages.length ? pages : void 0;
}
chrome.runtime.onMessageExternal.addListener((msg, _sender, sendResponse) => {
  const senderOrigin = _sender.origin ?? (_sender.url ? new URL(_sender.url).origin : void 0);
  if (!isTrustedSenderOrigin(senderOrigin)) {
    sendResponse({ ok: false, detail: "untrusted sender" });
    return false;
  }
  if (msg.type === "open-panel") {
    const windowId = _sender.tab?.windowId;
    if (windowId == null) {
      sendResponse({ ok: false, detail: "no window" });
      return false;
    }
    chrome.sidePanel.open({ windowId }).then(() => sendResponse({ ok: true })).catch((err) => {
      console.warn("[VisaAI ext] side panel did not open from Launch:", err);
      sendResponse({ ok: false, detail: err instanceof Error ? err.message : "not opened" });
    });
    return true;
  }
  if (msg.type === "ping") {
    sendResponse({ ok: true, version: chrome.runtime.getManifest().version });
    return false;
  }
  if (msg.type === "session") {
    if (!msg.token || !msg.apiUrl) {
      sendResponse({ ok: false, detail: "token and apiUrl required" });
      return false;
    }
    if (!isTrustedApiUrl(msg.apiUrl)) {
      sendResponse({ ok: false, detail: "untrusted apiUrl" });
      return false;
    }
    const pending = {
      token: msg.token,
      apiUrl: msg.apiUrl,
      portalUrl: msg.portalUrl,
      readbackToken: msg.readbackToken,
      receivedAt: Date.now()
    };
    void (async () => {
      try {
        if (await wasHandled(pending.token)) {
          sendResponse({ ok: true });
          return;
        }
        await chrome.storage.local.set({ pendingSession: pending });
        await markHandled(pending.token);
        await chrome.alarms.create(PENDING_PURGE_ALARM, { when: pending.receivedAt + PENDING_SESSION_TTL_MS });
        await chrome.action.setBadgeBackgroundColor({ color: "#10c22b" });
        await chrome.action.setBadgeText({ text: "GO" });
        console.log("[VisaAI ext] session stored, badge set, version", chrome.runtime.getManifest().version);
        const windowId = _sender.tab?.windowId;
        if (windowId != null) {
          const target = pickPortalTabToFocus(await chrome.tabs.query({ windowId }), portalPagesOf(msg.portalPages));
          if (target != null) await chrome.tabs.update(target, { active: true }).catch(() => void 0);
        }
        sendResponse({ ok: true });
      } catch (err) {
        console.error("[VisaAI ext] session handoff failed:", err);
        sendResponse({ ok: false, detail: err instanceof Error ? err.message : "handoff failed" });
      }
    })();
    return true;
  }
  sendResponse({ ok: false, detail: "unknown message type" });
  return false;
});
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id) return false;
  if (msg.type === "execute-step") {
    void executeInActiveTab(msg.instruction).then((result) => sendResponse(result));
    return true;
  }
  if (msg.type === "pf-bind-session") {
    if (typeof msg.executionId !== "string" || typeof msg.tabId !== "number") {
      sendResponse({ ok: false, detail: "executionId + tabId required" });
      return false;
    }
    pfSession = { executionId: msg.executionId, tabId: msg.tabId };
    sendResponse({ ok: true });
    return false;
  }
  if (msg.type === "pf-unbind-session") {
    pfSession = null;
    sendResponse({ ok: true });
    return false;
  }
  if (msg.type === "pf-probe") {
    void pfProbe(msg.selectors, msg.ops, msg.awaitOptions).then(sendResponse);
    return true;
  }
  if (msg.type === "pf-page-rows") {
    if (!pfSession) {
      sendResponse([]);
      return false;
    }
    void pfWithTimeout(sendToPortalTab(pfSession.tabId, { type: "page-rows" }), PF_TIMEOUT_MS).then((rows) => sendResponse(Array.isArray(rows) ? rows : [])).catch(() => sendResponse([]));
    return true;
  }
  if (msg.type === "pf-upload-status") {
    if (!pfSession) {
      sendResponse([]);
      return false;
    }
    void pfWithTimeout(sendToPortalTab(pfSession.tabId, { type: "upload-status" }), PF_TIMEOUT_MS).then((rows) => sendResponse(Array.isArray(rows) ? rows : [])).catch(() => sendResponse([]));
    return true;
  }
  if (msg.type === "pf-execute-field") {
    void pfDispatch(msg.command).then(sendResponse);
    return true;
  }
  if (msg.type === "session-consumed") {
    void chrome.action.setBadgeText({ text: "" });
    return false;
  }
  return false;
});
var PF_TIMEOUT_MS = 15e3;
var pfSession = null;
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (pfSession?.tabId !== tabId) return;
  if (changeInfo.url !== void 0 || changeInfo.status === "loading") pfSession = null;
});
chrome.tabs.onRemoved.addListener((tabId) => {
  if (pfSession?.tabId === tabId) pfSession = null;
});
function pfFail(command, reason) {
  return {
    protocol: PORTAL_FILL_PROTOCOL_VERSION,
    kind: "field_result",
    executionId: command.executionId,
    fieldKey: command.fieldKey,
    outcome: "failed",
    reason,
    selectorFound: false
  };
}
async function pfProbe(selectors, ops, awaitOptions) {
  if (!pfSession) return { error: "no_session" };
  try {
    const raw = await pfWithTimeout(
      sendToPortalTab(pfSession.tabId, {
        type: "readback",
        selectors,
        ...ops ? { ops } : {},
        ...awaitOptions ? { awaitOptions } : {}
      }),
      PF_TIMEOUT_MS
    );
    if (!Array.isArray(raw)) return { error: "unreachable" };
    return {
      results: raw.map((r) => ({
        selector: r.selector,
        found: r.found,
        // Presence only: "its list lacks the answer" carries no value.
        ...r.optionMissing === true && !r.found ? { optionMissing: true } : {}
      })),
      page: await boundTabPath()
    };
  } catch {
    return { error: "unreachable" };
  }
}
async function boundTabPath() {
  if (!pfSession) return null;
  try {
    const tab = await chrome.tabs.get(pfSession.tabId);
    return tab?.url ? new URL(tab.url).pathname : null;
  } catch {
    return null;
  }
}
async function pfDispatch(command) {
  if (!pfSession) return pfFail(command, "transport_error");
  if (command.executionId !== pfSession.executionId) return pfFail(command, "transport_error");
  if (!isPortalFillProtocolCompatible(command.protocol)) return pfFail(command, "dom_change");
  try {
    const res = await pfWithTimeout(
      sendToPortalTab(pfSession.tabId, { type: "execute-field-intent", command }),
      PF_TIMEOUT_MS
    );
    return res;
  } catch (err) {
    const timedOut = err instanceof Error && err.message === "pf-timeout";
    return pfFail(command, timedOut ? "timeout" : "transport_error");
  }
}
function pfWithTimeout(p, ms) {
  let timer;
  const timeout = new Promise((_resolve, reject) => {
    timer = setTimeout(() => reject(new Error("pf-timeout")), ms);
  });
  return Promise.race([p, timeout]).finally(() => clearTimeout(timer));
}
async function executeInActiveTab(instruction) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return { ok: false, detail: "No active tab" };
  try {
    const response = await chrome.tabs.sendMessage(tab.id, { type: "execute-step", instruction });
    return response;
  } catch (err) {
    return { ok: false, detail: err instanceof Error ? err.message : "Content script not reachable" };
  }
}
//# sourceMappingURL=background.js.map
