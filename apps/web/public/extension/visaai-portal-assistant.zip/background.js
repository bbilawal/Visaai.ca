// src/shared.ts
var PENDING_SESSION_TTL_MS = 5 * 60 * 1e3;
var PORTAL_FILL_PROTOCOL_VERSION = 2;
function isPortalFillProtocolCompatible(protocol) {
  return protocol === PORTAL_FILL_PROTOCOL_VERSION;
}
function isTrustedApiUrl(apiUrl) {
  try {
    const u = new URL(apiUrl);
    const host = u.hostname;
    if (u.protocol === "https:" && (host === "visaai.co" || host.endsWith(".visaai.co")))
      return true;
    if ((u.protocol === "http:" || u.protocol === "https:") && (host === "localhost" || host === "127.0.0.1"))
      return true;
    return false;
  } catch {
    return false;
  }
}

// src/background.ts
void chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
var PENDING_PURGE_ALARM = "purge-pending-session";
async function purgeStalePendingSession() {
  const stored = await chrome.storage.local.get("pendingSession");
  const pending = stored.pendingSession;
  if (!pending) return;
  if (typeof pending.receivedAt === "number" && Date.now() - pending.receivedAt < PENDING_SESSION_TTL_MS) return;
  await chrome.storage.local.remove("pendingSession");
  await chrome.action.setBadgeText({ text: "" });
}
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === PENDING_PURGE_ALARM) void purgeStalePendingSession().catch(() => {
  });
});
chrome.runtime.onStartup.addListener(() => {
  void purgeStalePendingSession().catch(() => {
  });
});
void purgeStalePendingSession().catch(() => {
});
function isTrustedSenderOrigin(origin) {
  if (!origin) return false;
  try {
    const u = new URL(origin);
    const host = u.hostname;
    if (u.protocol === "https:" && (host === "visaai.co" || host.endsWith(".visaai.co")))
      return true;
    if ((u.protocol === "http:" || u.protocol === "https:") && (host === "localhost" || host === "127.0.0.1"))
      return true;
    return false;
  } catch {
    return false;
  }
}
chrome.runtime.onMessageExternal.addListener((msg, _sender, sendResponse) => {
  const senderOrigin = _sender.origin ?? (_sender.url ? new URL(_sender.url).origin : void 0);
  if (!isTrustedSenderOrigin(senderOrigin)) {
    sendResponse({ ok: false, detail: "untrusted sender" });
    return false;
  }
  if (msg.type === "ping") {
    sendResponse({ ok: true, version: chrome.runtime.getManifest().version });
    return false;
  }
  if (msg.type === "session") {
    if (!msg.token || !msg.apiUrl) {
      sendResponse({ ok: false, detail: "token and apiUrl required" });
      return false;
    }
    if (!isTrustedApiUrl(msg.apiUrl)) {
      sendResponse({ ok: false, detail: "untrusted apiUrl" });
      return false;
    }
    const pending = {
      token: msg.token,
      apiUrl: msg.apiUrl,
      portalUrl: msg.portalUrl,
      readbackToken: msg.readbackToken,
      receivedAt: Date.now()
    };
    void (async () => {
      try {
        await chrome.storage.local.set({ pendingSession: pending });
        await chrome.alarms.create(PENDING_PURGE_ALARM, { when: pending.receivedAt + PENDING_SESSION_TTL_MS });
        await chrome.action.setBadgeBackgroundColor({ color: "#10c22b" });
        await chrome.action.setBadgeText({ text: "GO" });
        console.log("[VisaAI ext] session stored, badge set, version", chrome.runtime.getManifest().version);
        sendResponse({ ok: true });
      } catch (err) {
        console.error("[VisaAI ext] session handoff failed:", err);
        sendResponse({ ok: false, detail: err instanceof Error ? err.message : "handoff failed" });
      }
    })();
    return true;
  }
  sendResponse({ ok: false, detail: "unknown message type" });
  return false;
});
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id) return false;
  if (msg.type === "execute-step") {
    void executeInActiveTab(msg.instruction).then((result) => sendResponse(result));
    return true;
  }
  if (msg.type === "pf-bind-session") {
    if (typeof msg.executionId !== "string" || typeof msg.tabId !== "number") {
      sendResponse({ ok: false, detail: "executionId + tabId required" });
      return false;
    }
    pfSession = { executionId: msg.executionId, tabId: msg.tabId };
    sendResponse({ ok: true });
    return false;
  }
  if (msg.type === "pf-unbind-session") {
    pfSession = null;
    sendResponse({ ok: true });
    return false;
  }
  if (msg.type === "pf-probe") {
    void pfProbe(msg.selectors, msg.ops).then(sendResponse);
    return true;
  }
  if (msg.type === "pf-execute-field") {
    void pfDispatch(msg.command).then(sendResponse);
    return true;
  }
  if (msg.type === "session-consumed") {
    void chrome.action.setBadgeText({ text: "" });
    return false;
  }
  return false;
});
var PF_TIMEOUT_MS = 15e3;
var pfSession = null;
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (pfSession?.tabId !== tabId) return;
  if (changeInfo.url !== void 0 || changeInfo.status === "loading") pfSession = null;
});
chrome.tabs.onRemoved.addListener((tabId) => {
  if (pfSession?.tabId === tabId) pfSession = null;
});
function pfFail(command, reason) {
  return {
    protocol: PORTAL_FILL_PROTOCOL_VERSION,
    kind: "field_result",
    executionId: command.executionId,
    fieldKey: command.fieldKey,
    outcome: "failed",
    reason,
    selectorFound: false
  };
}
async function pfProbe(selectors, ops) {
  if (!pfSession) return { error: "no_session" };
  try {
    const raw = await pfWithTimeout(
      chrome.tabs.sendMessage(pfSession.tabId, { type: "readback", selectors, ...ops ? { ops } : {} }),
      PF_TIMEOUT_MS
    );
    if (!Array.isArray(raw)) return { error: "unreachable" };
    return { results: raw.map((r) => ({ selector: r.selector, found: r.found })), page: await boundTabPath() };
  } catch {
    return { error: "unreachable" };
  }
}
async function boundTabPath() {
  if (!pfSession) return null;
  try {
    const tab = await chrome.tabs.get(pfSession.tabId);
    return tab?.url ? new URL(tab.url).pathname : null;
  } catch {
    return null;
  }
}
async function pfDispatch(command) {
  if (!pfSession) return pfFail(command, "transport_error");
  if (command.executionId !== pfSession.executionId) return pfFail(command, "transport_error");
  if (!isPortalFillProtocolCompatible(command.protocol)) return pfFail(command, "dom_change");
  try {
    const res = await pfWithTimeout(
      chrome.tabs.sendMessage(pfSession.tabId, { type: "execute-field-intent", command }),
      PF_TIMEOUT_MS
    );
    return res;
  } catch (err) {
    const timedOut = err instanceof Error && err.message === "pf-timeout";
    return pfFail(command, timedOut ? "timeout" : "transport_error");
  }
}
function pfWithTimeout(p, ms) {
  let timer;
  const timeout = new Promise((_resolve, reject) => {
    timer = setTimeout(() => reject(new Error("pf-timeout")), ms);
  });
  return Promise.race([p, timeout]).finally(() => clearTimeout(timer));
}
async function executeInActiveTab(instruction) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return { ok: false, detail: "No active tab" };
  try {
    const response = await chrome.tabs.sendMessage(tab.id, { type: "execute-step", instruction });
    return response;
  } catch (err) {
    return { ok: false, detail: err instanceof Error ? err.message : "Content script not reachable" };
  }
}
//# sourceMappingURL=background.js.map
