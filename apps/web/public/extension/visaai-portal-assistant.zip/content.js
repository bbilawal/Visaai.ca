// src/shared.ts
var PENDING_SESSION_TTL_MS = 5 * 60 * 1e3;
var PORTAL_FILL_PROTOCOL_VERSION = 2;
function isPortalFillProtocolCompatible(protocol) {
  return protocol === PORTAL_FILL_PROTOCOL_VERSION;
}

// src/readback-engine.ts
function normalizeValue(value) {
  return value.trim().normalize("NFC");
}
async function hashValue(value) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function verifyField(actualValue, expectedValueHash) {
  const actualValueHash = await hashValue(normalizeValue(actualValue));
  const match = actualValueHash === expectedValueHash;
  return {
    outcome: match ? "verified" : "failed",
    reason: match ? void 0 : "value_mismatch",
    actualValueHash
  };
}

// src/executor/resolve-target.ts
function resolveTarget(selector, root = document) {
  if (typeof selector !== "string" || selector === "") return { status: "invalid" };
  let matches;
  try {
    matches = root.querySelectorAll(selector);
  } catch {
    return { status: "invalid" };
  }
  if (matches.length === 0) return { status: "missing" };
  if (matches.length > 1) return { status: "ambiguous" };
  return { status: "found", el: matches[0] };
}
var DIALOG_SELECTOR = 'mat-dialog-container, [role="dialog"], [role="alertdialog"]';
function topDialog() {
  const all = document.querySelectorAll(DIALOG_SELECTOR);
  return all.length ? all[all.length - 1] : null;
}
function inDialog(el) {
  return !!el.closest(`${DIALOG_SELECTOR}, .cdk-overlay-container`);
}
function pageRowCount() {
  let n = 0;
  for (const r of Array.from(document.querySelectorAll('tr, mat-row, [role="row"]'))) {
    if (!inDialog(r)) n += 1;
  }
  return n;
}
async function waitForTarget(selector, scope = () => document, timeoutMs = 5e3, intervalMs = 100) {
  const deadline = Date.now() + timeoutMs;
  for (; ; ) {
    const root = scope();
    const r = root ? resolveTarget(selector, root) : { status: "missing" };
    if (r.status !== "missing") return r;
    if (Date.now() >= deadline) return r;
    await new Promise((resolve) => setTimeout(resolve, intervalMs));
  }
}
async function waitUntil(cond, timeoutMs = 5e3, intervalMs = 100) {
  const deadline = Date.now() + timeoutMs;
  for (; ; ) {
    if (cond()) return true;
    if (Date.now() >= deadline) return false;
    await new Promise((resolve) => setTimeout(resolve, intervalMs));
  }
}

// src/portal-fill-executor.ts
async function dryRunField(cmd) {
  const base = {
    protocol: PORTAL_FILL_PROTOCOL_VERSION,
    kind: "field_result",
    executionId: cmd.executionId,
    fieldKey: cmd.fieldKey
  };
  const target = resolveTarget(cmd.selector);
  if (target.status !== "found") {
    return { ...base, outcome: "failed", reason: "selector_missing", selectorFound: false };
  }
  const el = target.el;
  const result = await verifyField(el.value ?? "", cmd.expectedValueHash);
  return {
    ...base,
    selectorFound: true,
    actualValueHash: result.actualValueHash,
    outcome: result.outcome,
    reason: result.reason
  };
}

// src/executor/safety-guards.ts
var WRITABLE_TAGS = /* @__PURE__ */ new Set(["INPUT", "TEXTAREA", "SELECT"]);
var FORBIDDEN_INPUT_TYPES = /* @__PURE__ */ new Set([
  "submit",
  "button",
  "image",
  "reset",
  "file",
  "password",
  "hidden",
  "radio",
  "checkbox"
]);
function isSafeWriteTarget(el) {
  if (!WRITABLE_TAGS.has(el.tagName)) return false;
  if (el.tagName === "INPUT") {
    const type = (el.type || "text").toLowerCase();
    if (FORBIDDEN_INPUT_TYPES.has(type)) return false;
  }
  const ctl = el;
  if (ctl.disabled) return false;
  if ("readOnly" in ctl && ctl.readOnly) return false;
  if (!isVisible(el)) return false;
  return true;
}
function isSafeChoiceTarget(el, type) {
  if (el.tagName !== "INPUT") return false;
  const input = el;
  if ((input.type || "").toLowerCase() !== type) return false;
  if (input.disabled) return false;
  return isVisible(el);
}
function buttonText(el) {
  return (el.textContent ?? "").replace(/\s+/g, " ").trim();
}
var NEVER_CLICK = /\b(continue|next|submit|sign|pay|payment|transmit|send|delete|remove|back|previous|cancel)\b/i;
var NEVER_CLICK_IDS = /^(next_path|previous_path)$/i;
function isPlainButton(el) {
  const tag = el.tagName;
  const isBtn = tag === "BUTTON" || tag === "INPUT" && el.type.toLowerCase() === "button";
  if (!isBtn) return false;
  if (el.disabled) return false;
  if (NEVER_CLICK_IDS.test(el.id)) return false;
  if (!isVisible(el)) return false;
  return true;
}
function isSafeAddButton(el, inDialog2) {
  if (!isPlainButton(el) || inDialog2) return false;
  if (!/add/i.test(el.id)) return false;
  return !NEVER_CLICK.test(buttonText(el));
}
function isSafeDialogSave(el, dialog) {
  if (!isPlainButton(el) || !dialog.contains(el)) return false;
  const text = buttonText(el);
  if (!/\bsave\b/i.test(text)) return false;
  return !/continue|next|submit|sign|pay|transmit/i.test(text);
}
function isVisible(el) {
  const view = el.ownerDocument.defaultView;
  if (!view) return false;
  for (let n = el; n; n = n.parentElement) {
    if (n.hidden) return false;
    if (view.getComputedStyle(n).display === "none") return false;
  }
  const v = view.getComputedStyle(el).visibility;
  if (v === "hidden" || v === "collapse") return false;
  const check = el.checkVisibility;
  if (typeof check === "function" && !check.call(el, { visibilityProperty: true, checkVisibilityCSS: true })) return false;
  return true;
}

// src/executor/field-executor.ts
function resolveWritable(selector, root) {
  const target = resolveTarget(selector, root);
  if (target.status === "ambiguous") return { written: false, reason: "unsafe_target" };
  if (target.status !== "found") return { written: false, reason: "selector_missing" };
  if (!isSafeWriteTarget(target.el)) return { written: false, reason: "unsafe_target" };
  return target.el;
}
function setNative(input, value) {
  const proto = input instanceof HTMLTextAreaElement ? window.HTMLTextAreaElement.prototype : input instanceof HTMLSelectElement ? window.HTMLSelectElement.prototype : window.HTMLInputElement.prototype;
  const nativeSetter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
  if (nativeSetter) nativeSetter.call(input, value);
  else input.value = value;
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
  input.dispatchEvent(new Event("blur", { bubbles: true }));
}
function executeWrite(selector, value, root = document) {
  const el = resolveWritable(selector, root);
  if (!(el instanceof Element)) return el;
  setNative(el, value);
  return { written: true, node: el };
}
function optionLabel(text) {
  return (text ?? "").replace(/\s+/g, " ").trim().toLowerCase();
}
function executeSelectByText(selector, text, root = document) {
  const el = resolveWritable(selector, root);
  if (!(el instanceof Element)) return el;
  if (!(el instanceof HTMLSelectElement)) return { written: false, reason: "unsafe_target" };
  const want = optionLabel(text);
  const hits = Array.from(el.options).filter((o) => optionLabel(o.text) === want);
  if (hits.length !== 1) return { written: false, reason: "selector_missing" };
  setNative(el, hits[0].value);
  return { written: true, node: el };
}

// src/executor/readback.ts
async function readField(selector, writtenNode, settleMs = 250, root = document, mode = "value", answer = "") {
  await new Promise((resolve) => setTimeout(resolve, settleMs));
  const target = resolveTarget(selector, root);
  if (target.status !== "found") return { found: false, sameNode: false, value: "" };
  const el = target.el;
  const sameNode = writtenNode ? el === writtenNode : true;
  let raw;
  if (mode === "checked") {
    raw = el.checked ? answer : "";
  } else if (mode === "option") {
    const sel = el;
    const opt = sel.selectedIndex >= 0 ? sel.options[sel.selectedIndex] : void 0;
    const text = (opt?.text ?? "").replace(/\s+/g, " ").trim();
    raw = text.toLowerCase() === answer.replace(/\s+/g, " ").trim().toLowerCase() ? answer : text;
  } else {
    raw = el.value ?? "";
  }
  return { found: true, sameNode, value: raw.trim().normalize("NFC") };
}

// src/executor/control-actuator.ts
function chooseRadio(el) {
  if (!isSafeChoiceTarget(el, "radio")) return { done: false, reason: "unsafe_target" };
  const input = el;
  if (!input.checked) input.click();
  return { done: true, node: el };
}
function ensureChecked(el) {
  if (!isSafeChoiceTarget(el, "checkbox")) return { done: false, reason: "unsafe_target" };
  const input = el;
  if (!input.checked) input.click();
  return { done: true, node: el };
}
function openRowDialog(el) {
  if (!isSafeAddButton(el, inDialog(el))) return { done: false, reason: "unsafe_target" };
  el.click();
  return { done: true, node: el };
}
var DIALOG_SAVE = "::dialog-save";
function findDialogSave(selector) {
  const dialog = topDialog();
  if (!dialog) return { done: false, reason: "selector_missing" };
  let el = null;
  if (selector === DIALOG_SAVE) {
    const hits = Array.from(dialog.querySelectorAll("button")).filter((b) => /\bsave\b/i.test(buttonText(b)));
    if (hits.length === 0) return { done: false, reason: "selector_missing" };
    if (hits.length > 1) return { done: false, reason: "unsafe_target" };
    el = hits[0];
  } else {
    const r = resolveTarget(selector, dialog);
    if (r.status === "ambiguous") return { done: false, reason: "unsafe_target" };
    if (r.status !== "found") return { done: false, reason: "selector_missing" };
    el = r.el;
  }
  if (!isSafeDialogSave(el, dialog)) return { done: false, reason: "unsafe_target" };
  return { done: true, node: el };
}
function saveRowDialog(el) {
  const dialog = topDialog();
  if (!dialog || !isSafeDialogSave(el, dialog)) return { done: false, reason: "unsafe_target" };
  el.click();
  return { done: true, node: el };
}

// src/content.ts
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id) return false;
  if (msg.type === "readback") {
    sendResponse(readbackFields(msg.selectors, msg.ops));
    return true;
  }
  if (msg.type === "portal-fill-dry") {
    if (!isPortalFillProtocolCompatible(msg.command.protocol)) {
      sendResponse({ ok: false, detail: "protocol_mismatch" });
      return true;
    }
    void dryRunField(msg.command).then(sendResponse).catch(() => sendResponse({ ok: false, detail: "dry_run_failed" }));
    return true;
  }
  if (msg.type === "execute-field-intent") {
    void runFieldIntent(msg.command).then(sendResponse).catch(
      () => sendResponse({
        protocol: PORTAL_FILL_PROTOCOL_VERSION,
        kind: "field_result",
        executionId: msg.command?.executionId ?? "",
        fieldKey: msg.command?.fieldKey ?? "",
        outcome: "failed",
        reason: "dom_change",
        selectorFound: false
      })
    );
    return true;
  }
  if (msg.type === "field-readback") {
    void readField(msg.selector, void 0).then(
      (rb) => sendResponse({ selector: msg.selector, value: rb.value, found: rb.found })
    ).catch(() => sendResponse({ selector: msg.selector, value: "", found: false }));
    return true;
  }
  if (msg.type === "execute-step") {
    sendResponse({ ok: false, detail: "LEGACY_EXECUTION_DEPRECATED" });
    return true;
  }
  return false;
});
var APPEAR_MS = 5e3;
async function runFieldIntent(cmd) {
  const base = {
    protocol: PORTAL_FILL_PROTOCOL_VERSION,
    kind: "field_result",
    executionId: cmd.executionId,
    fieldKey: cmd.fieldKey
  };
  const failed = (reason, selectorFound = false) => ({
    ...base,
    outcome: "failed",
    reason,
    selectorFound
  });
  if (!isPortalFillProtocolCompatible(cmd.protocol)) return failed("dom_change");
  const scope = () => cmd.dialog ? topDialog() : document;
  const root = scope();
  if (!root) return failed("selector_missing");
  let readMode = "value";
  let node;
  if (cmd.op === "dialog_save") {
    const found = findDialogSave(cmd.selector);
    if (!found.done) return failed(found.reason);
    const before = pageRowCount();
    const saved = saveRowDialog(found.node);
    if (!saved.done) return failed(saved.reason, true);
    const ok = await waitUntil(() => !topDialog() && pageRowCount() > before, APPEAR_MS);
    if (!ok) return failed("controlled_rejected", true);
    return verified(base, cmd.mappedValue, cmd.expectedValueHash);
  }
  const target = cmd.reveal || cmd.dialog ? await waitForTarget(cmd.selector, scope, APPEAR_MS) : resolveTarget(cmd.selector, root);
  if (target.status === "ambiguous") return failed("unsafe_target");
  if (target.status !== "found") return failed("selector_missing");
  const here = scope() ?? document;
  if (cmd.op === "dialog_open") {
    const opened = openRowDialog(target.el);
    if (!opened.done) return failed(opened.reason, true);
    if (!await waitUntil(() => topDialog() !== null, APPEAR_MS)) return failed("dom_change", true);
    return verified(base, cmd.mappedValue, cmd.expectedValueHash);
  }
  if (cmd.op === "radio" || cmd.op === "check") {
    const act = cmd.op === "radio" ? chooseRadio(target.el) : ensureChecked(target.el);
    if (!act.done) return failed(act.reason, true);
    node = act.node;
    readMode = "checked";
  } else {
    const w = cmd.op === "select_text" ? executeSelectByText(cmd.selector, cmd.mappedValue, here) : executeWrite(cmd.selector, cmd.mappedValue, here);
    if (!w.written) return failed(w.reason ?? "selector_missing");
    node = w.node;
    if (cmd.op === "select_text") readMode = "option";
  }
  const rb = await readField(cmd.selector, node, 250, scope() ?? document, readMode, cmd.mappedValue);
  if (!rb.found) return failed("selector_missing");
  if (!rb.sameNode) return failed("portal_mutation", true);
  const v = await verifyField(rb.value, cmd.expectedValueHash);
  if (v.outcome !== "verified") return { ...base, outcome: v.outcome, reason: v.reason, selectorFound: true };
  return { ...base, outcome: v.outcome, actualValueHash: v.actualValueHash, selectorFound: true };
}
async function verified(base, mappedValue, expectedValueHash) {
  const v = await verifyField(mappedValue, expectedValueHash);
  if (v.outcome !== "verified") return { ...base, outcome: "failed", reason: v.reason, selectorFound: true };
  return { ...base, outcome: "verified", actualValueHash: v.actualValueHash, selectorFound: true };
}
function presentFor(el, op) {
  if (op === "radio") return isSafeChoiceTarget(el, "radio");
  if (op === "check") return isSafeChoiceTarget(el, "checkbox");
  if (op === "dialog_open") return isSafeAddButton(el, inDialog(el));
  return isSafeWriteTarget(el);
}
function readbackFields(selectors, ops) {
  return selectors.map((selector, i) => {
    const op = ops?.[i] ?? null;
    if (op === "dialog_save" || selector === DIALOG_SAVE) return { selector, value: "", found: false };
    const target = resolveTarget(selector);
    if (target.status === "ambiguous") return { selector, value: "", found: false, ambiguous: true };
    if (target.status !== "found") return { selector, value: "", found: false };
    if (!presentFor(target.el, op)) return { selector, value: "", found: false };
    if (op) return { selector, value: "", found: true };
    const el = target.el;
    return { selector, value: el.value ?? "", found: true };
  });
}
//# sourceMappingURL=content.js.map
