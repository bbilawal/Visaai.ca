// src/shared.ts
var PENDING_SESSION_TTL_MS = 5 * 60 * 1e3;
var PORTAL_FILL_PROTOCOL_VERSION = 2;
function isPortalFillProtocolCompatible(protocol) {
  return protocol === PORTAL_FILL_PROTOCOL_VERSION;
}

// src/readback-engine.ts
function normalizeValue(value) {
  return value.trim().normalize("NFC");
}
async function hashValue(value) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function verifyField(actualValue, expectedValueHash) {
  const actualValueHash = await hashValue(normalizeValue(actualValue));
  const match = actualValueHash === expectedValueHash;
  return {
    outcome: match ? "verified" : "failed",
    reason: match ? void 0 : "value_mismatch",
    actualValueHash
  };
}

// src/executor/resolve-target.ts
function resolveTarget(selector, root = document) {
  if (typeof selector !== "string" || selector === "") return { status: "invalid" };
  const scoped = parseScopedSelector(selector);
  if (scoped === null) return { status: "invalid" };
  let matches;
  let scope = root;
  if (scoped.dependant) {
    const form = dependantForm();
    if (!form) return { status: "missing" };
    if (root !== document && !root.contains(form)) return { status: "missing" };
    if (/#personalDetailsForm-dob\b/.test(scoped.css) && document.querySelectorAll("#personalDetailsForm-dob").length < 2)
      return { status: "ambiguous" };
    scope = form;
  }
  try {
    matches = Array.from(scope.querySelectorAll(scoped.css));
  } catch {
    return { status: "invalid" };
  }
  if (scoped.page && !scoped.page.test(screenText())) return { status: "missing" };
  if (scoped.principal && !principalFormHere()) return { status: "missing" };
  if (scoped.label) {
    const re = scoped.label;
    matches = matches.filter((el) => re.test(questionText(el)));
  }
  if (scoped.nth) {
    const { k, most } = scoped.nth;
    if (matches.length > most) return { status: "ambiguous" };
    matches = matches.length >= k ? [matches[k - 1]] : [];
  }
  if (matches.length === 0) return { status: "missing" };
  if (matches.length > 1) return { status: "ambiguous" };
  if (scoped.option && !listsOption(matches[0], scoped.option)) return { status: "no_option", el: matches[0] };
  return { status: "found", el: matches[0] };
}
function optionKey(text) {
  const t = (text ?? "").replace(/\s+/g, " ").trim().toLowerCase();
  return /^\d+$/.test(t) ? String(Number(t)) : t;
}
function listsOption(el, option) {
  if (!(el instanceof HTMLSelectElement)) return false;
  const opts = Array.from(el.options);
  const { by, value: wanted } = option;
  if (by === "value") return opts.some((o) => wanted === o.value);
  const want = optionKey(wanted);
  return opts.filter((o) => optionKey(o.text) === want).length === 1;
}
var SCOPE_SEPARATOR = " >> ";
var SCOPE_PART = /^(label|page)=\/(.+)\/([a-z]*)$/s;
var PRINCIPAL_PART = "principal";
var KEEP_PART = "keep";
var DEPENDANT_PART = "dependant";
var ROWS_PART = /^rows=([1-9]\d?)$/;
var NTH_PART = /^nth=([1-9])\/([1-9])$/;
var OPTION_PART = /^option=(value|text):(.+)$/s;
function parseScopedSelector(selector) {
  if (!selector.includes(SCOPE_SEPARATOR)) return { css: selector };
  const [css, ...parts] = selector.split(SCOPE_SEPARATOR);
  if (!css.trim() || parts.length === 0) return null;
  const out = { css };
  for (const part of parts) {
    const o = OPTION_PART.exec(part);
    if (o) {
      if (out.option) return null;
      out.option = { by: o[1], value: o[2] };
      continue;
    }
    if (out.option) return null;
    if (part === PRINCIPAL_PART) {
      if (out.principal) return null;
      out.principal = true;
      continue;
    }
    if (part === KEEP_PART) {
      if (out.keep) return null;
      out.keep = true;
      continue;
    }
    if (part === DEPENDANT_PART) {
      if (out.dependant) return null;
      out.dependant = true;
      continue;
    }
    const n = NTH_PART.exec(part);
    if (n) {
      const k = Number(n[1]);
      const most = Number(n[2]);
      if (out.nth !== void 0 || k > most) return null;
      out.nth = { k, most };
      continue;
    }
    const r = ROWS_PART.exec(part);
    if (r) {
      if (out.rows !== void 0) return null;
      out.rows = Number(r[1]);
      continue;
    }
    const m = SCOPE_PART.exec(part);
    if (!m) return null;
    const kind = m[1];
    if (out[kind]) return null;
    if (/[gy]/.test(m[3])) return null;
    try {
      out[kind] = new RegExp(m[2], m[3]);
    } catch {
      return null;
    }
  }
  return out;
}
var squash = (t) => (t ?? "").replace(/\s+/g, " ").trim();
function questionText(el) {
  const parts = [];
  const id = el.getAttribute("id");
  if (id) {
    for (const l of Array.from(el.ownerDocument.querySelectorAll("label"))) {
      if (l.htmlFor === id) parts.push(squash(l.textContent));
    }
  }
  const wrap = el.closest("label");
  if (wrap) parts.push(squash(wrap.textContent));
  const aria = el.getAttribute("aria-label");
  if (aria) parts.push(squash(aria));
  for (const ref of (el.getAttribute("aria-labelledby") ?? "").split(/\s+/).filter(Boolean)) {
    parts.push(squash(el.ownerDocument.getElementById(ref)?.textContent));
  }
  const legend = el.closest("fieldset")?.querySelector("legend");
  if (legend) parts.push(squash(legend.textContent));
  return parts.filter(Boolean).join("\n");
}
var NOT_SHOWN = 'script, style, noscript, template, option, optgroup, select, .wb-inv, [hidden], [aria-hidden="true"]';
function hiddenByAncestor(el) {
  for (let e = el; e; e = e.parentElement) {
    if (e.matches(NOT_SHOWN)) return true;
    const style = e.getAttribute("style") ?? "";
    if (/display\s*:\s*none|visibility\s*:\s*hidden/i.test(style)) return true;
  }
  return false;
}
function screenText(doc = document) {
  const body = doc.body;
  if (!body) return "";
  const out = [];
  const walker = doc.createTreeWalker(body, NodeFilter.SHOW_TEXT);
  for (let n = walker.nextNode(); n; n = walker.nextNode()) {
    const t = n.textContent ?? "";
    if (!t.trim()) continue;
    if (hiddenByAncestor(n.parentElement)) continue;
    out.push(t);
  }
  return squash(out.join(" "));
}
var DIALOG_SELECTOR = 'mat-dialog-container, [role="dialog"], [role="alertdialog"]';
function topDialog() {
  const all = Array.from(document.querySelectorAll(DIALOG_SELECTOR)).filter(
    (d) => d.tagName === "MAT-DIALOG-CONTAINER" || !!d.closest(".cdk-overlay-container")
  );
  const outer = all.filter((d) => !all.some((o) => o !== d && o.contains(d)));
  return outer.length ? outer[outer.length - 1] : null;
}
function pageRowTexts() {
  return Array.from(document.querySelectorAll('tr, mat-row, [role="row"]')).filter((r) => !inDialog(r)).map((r) => {
    const cells = Array.from(r.querySelectorAll('td, th, mat-cell, [role="cell"]'));
    return cells.length ? cells.map((c) => c.textContent ?? "").join(" ") : r.innerText ?? r.textContent ?? "";
  });
}
function inDialog(el) {
  return !!el.closest("mat-dialog-container, .cdk-overlay-container");
}
function pageRowCount() {
  let n = 0;
  for (const r of Array.from(document.querySelectorAll('tr, mat-row, [role="row"]'))) {
    if (!inDialog(r)) n += 1;
  }
  return n;
}
function gridPaginators() {
  return Array.from(document.querySelectorAll("mat-paginator")).filter((p) => !inDialog(p));
}
var PAGE_NAV = {
  first: {
    cls: ".mat-paginator-navigation-first, .mat-mdc-paginator-navigation-first",
    label: /first page|premi[eè]re page/i
  },
  previous: {
    cls: ".mat-paginator-navigation-previous, .mat-mdc-paginator-navigation-previous",
    label: /previous page|page pr[eé]c[eé]dente/i
  },
  next: {
    cls: ".mat-paginator-navigation-next, .mat-mdc-paginator-navigation-next",
    label: /next page|page suivante/i
  }
};
function pageNav(p, which) {
  const { cls, label } = PAGE_NAV[which];
  return p.querySelector(cls) ?? (Array.from(p.querySelectorAll("button")).find((b) => label.test(b.getAttribute("aria-label") ?? "")) ?? null);
}
var navOff = (b) => !b || b.disabled || b.getAttribute("aria-disabled") === "true";
var rangeLabel = (p) => p.querySelector(".mat-paginator-range-label, .mat-mdc-paginator-range-label")?.textContent ?? p.textContent ?? "";
function paginatorTotal(p) {
  const m = /\b(?:of|sur|de)\s+(\d+)/i.exec(rangeLabel(p));
  return m ? Number(m[1]) : null;
}
function pageRowTotal() {
  let n = pageRowCount();
  for (const p of gridPaginators()) n += paginatorTotal(p) ?? 0;
  return n;
}
async function waitForTarget(selector, scope = () => document, timeoutMs = 5e3, intervalMs = 100, ready) {
  const deadline = Date.now() + timeoutMs;
  for (; ; ) {
    const root = scope();
    const r = root ? resolveTarget(selector, root) : { status: "missing" };
    const waiting = r.status === "missing" || r.status === "found" && ready !== void 0 && !ready(r.el);
    if (!waiting) return r;
    if (Date.now() >= deadline) return r;
    await new Promise((resolve) => setTimeout(resolve, intervalMs));
  }
}
async function waitUntil(cond, timeoutMs = 5e3, intervalMs = 100) {
  const deadline = Date.now() + timeoutMs;
  for (; ; ) {
    if (cond()) return true;
    if (Date.now() >= deadline) return false;
    await new Promise((resolve) => setTimeout(resolve, intervalMs));
  }
}
var PR_HOST = "prson-srpel.apps.cic.gc.ca";
var PRINCIPAL_PAIRS = [
  ["principalAppYes", "principalAppNo"],
  // IMM 5406
  ["principalApplicant", "principalOther"]
  // IMM 5669
];
var PRINCIPAL_KEY = "visaai.prPrincipalDocuments";
var remembered = /* @__PURE__ */ new Set();
var loaded = false;
function storedDocuments() {
  if (!loaded) {
    loaded = true;
    try {
      const raw = window.sessionStorage.getItem(PRINCIPAL_KEY);
      const list = raw ? JSON.parse(raw) : [];
      if (Array.isArray(list)) {
        for (const d of list) if (typeof d === "string") remembered.add(d);
      }
    } catch {
    }
  }
  return remembered;
}
function saveDocuments() {
  try {
    window.sessionStorage.setItem(PRINCIPAL_KEY, JSON.stringify([...remembered].slice(-50)));
  } catch {
  }
}
function formKeyHere() {
  try {
    const m = /^\/(?:en|fr)\/application\/case\/([A-Za-z0-9-]{1,64})\/(imm5406|imm5669)\/?$/i.exec(window.location.pathname);
    const id = new URLSearchParams(window.location.search).get("documentId");
    if (!m || !id || !/^[A-Za-z0-9-]{1,64}$/.test(id)) return null;
    return `${m[1]}|${m[2].toLowerCase()}|${id}`;
  } catch {
    return null;
  }
}
function principalFormHere() {
  if (window.location.hostname.toLowerCase() !== PR_HOST) return false;
  const docs = storedDocuments();
  const key = formKeyHere();
  const pair = PRINCIPAL_PAIRS.map(([yes, other]) => [
    document.getElementById(yes),
    document.getElementById(other)
  ]).find(([yes, other]) => yes || other);
  if (pair) {
    const [yes, other] = pair;
    const principal = !!yes && yes.checked && !!other && !other.checked;
    if (key) {
      if (principal) docs.add(key);
      else docs.delete(key);
      saveDocuments();
    }
    return principal;
  }
  return key !== null && docs.has(key);
}
function scopesHold(selector) {
  const scoped = parseScopedSelector(selector);
  if (!scoped) return false;
  if (scoped.page && !scoped.page.test(screenText())) return false;
  if (scoped.principal && !principalFormHere()) return false;
  return true;
}
function rowSelector(selector, row) {
  const [css, ...rest] = selector.split(SCOPE_SEPARATOR);
  const m = /^(.*\D)(\d+)$/.exec(css);
  if (!m || row < 0) return null;
  return [`${m[1]}${row}`, ...rest].join(SCOPE_SEPARATOR);
}
function rowIndexOf(selector) {
  const css = selector.split(SCOPE_SEPARATOR)[0];
  const m = /(\d+)$/.exec(css);
  return m ? Number(m[1]) : null;
}
function dependantForm() {
  const rel = Array.from(document.querySelectorAll("#dependantForm-relationship"));
  if (rel.length !== 1) return null;
  for (let el = rel[0].parentElement; el && el !== document.body; el = el.parentElement) {
    const save = Array.from(el.querySelectorAll("button")).some((b) => /^save details$/i.test(squash(b.textContent)));
    if (!save) continue;
    if (el.querySelector("#profileForm-familyName, #personalDetailsForm-givenName")) return null;
    const dobs = el.querySelectorAll("#personalDetailsForm-dob");
    if (dobs.length > 1) return null;
    const firstDob = document.querySelector("#personalDetailsForm-dob");
    if (firstDob && el.contains(firstDob)) return null;
    if (inDialog(el) || el.closest('dialog, [role="dialog"]')) return null;
    return el;
  }
  return null;
}
function dependantFormHasValues(form) {
  for (const el of Array.from(form.querySelectorAll("input, select, textarea"))) {
    const type = (el.type || "").toLowerCase();
    if (type === "radio" || type === "checkbox") {
      if (el.checked) return true;
      continue;
    }
    if (["button", "submit", "reset", "hidden", "image", "file"].includes(type)) continue;
    if (el instanceof HTMLSelectElement) {
      const opt = el.selectedIndex >= 0 ? el.options[el.selectedIndex] : void 0;
      const v = (opt?.value ?? "").trim();
      if (opt && v !== "" && !/null/i.test(v) && !/^select\b/i.test(squash(opt.text))) return true;
      continue;
    }
    if (/[a-z0-9]/i.test(el.value ?? "")) return true;
  }
  return false;
}

// src/portal-fill-executor.ts
async function dryRunField(cmd) {
  const base = {
    protocol: PORTAL_FILL_PROTOCOL_VERSION,
    kind: "field_result",
    executionId: cmd.executionId,
    fieldKey: cmd.fieldKey
  };
  const target = resolveTarget(cmd.selector);
  if (target.status !== "found") {
    return { ...base, outcome: "failed", reason: "selector_missing", selectorFound: false };
  }
  const el = target.el;
  const result = await verifyField(el.value ?? "", cmd.expectedValueHash);
  return {
    ...base,
    selectorFound: true,
    actualValueHash: result.actualValueHash,
    outcome: result.outcome,
    reason: result.reason
  };
}

// src/trrt-pages.ts
var TRRT_HOST = "tr-rt.apps.cic.gc.ca";
var AUTO_ADVANCE_PAGES = Object.freeze([
  "/group-questions",
  "/purpose",
  "/special-event-code",
  "/representative",
  "/bio-data",
  "/bio-data-travel-docs",
  "/nationality",
  "/national-id-doc",
  "/other-names",
  "/contact-info",
  "/minors-guardian",
  "/biometrics",
  "/inviter-info",
  "/finances",
  "/activities",
  "/travel-history",
  "/validity-status",
  "/crime-activity",
  "/security-questions",
  "/medical-background-questions",
  "/medical-tuberculosis",
  "/medical-questions",
  "/family-info",
  "/family-info-children",
  "/family-info-parents",
  "/language",
  "/contact-info-email",
  "/contact-info-tel"
]);
function isAutoAdvancePath(path) {
  if (typeof path !== "string") return false;
  const p = path.replace(/\/+$/, "") || "/";
  return AUTO_ADVANCE_PAGES.includes(p.toLowerCase());
}

// src/executor/safety-guards.ts
var WRITABLE_TAGS = /* @__PURE__ */ new Set(["INPUT", "TEXTAREA", "SELECT"]);
var FORBIDDEN_INPUT_TYPES = /* @__PURE__ */ new Set([
  "submit",
  "button",
  "image",
  "reset",
  "file",
  "password",
  "hidden",
  "radio",
  "checkbox"
]);
function isSafeWriteTarget(el) {
  if (!WRITABLE_TAGS.has(el.tagName)) return false;
  if (el.tagName === "INPUT") {
    const type = (el.type || "text").toLowerCase();
    if (FORBIDDEN_INPUT_TYPES.has(type)) return false;
  }
  const ctl = el;
  if (ctl.disabled) return false;
  if ("readOnly" in ctl && ctl.readOnly) return false;
  if (!isVisible(el)) return false;
  return true;
}
function isSafeChoiceTarget(el, type) {
  if (el.tagName !== "INPUT") return false;
  const input = el;
  if ((input.type || "").toLowerCase() !== type) return false;
  if (input.disabled) return false;
  return isVisible(el);
}
function buttonText(el) {
  return (el.textContent ?? "").replace(/\s+/g, " ").trim();
}
var NEVER_CLICK = /\b(continue|next|submit|sign|pay|payment|transmit|send|delete|remove|back|previous|cancel|complete|consent)\b|\bdeclar|return to (the )?application/i;
var NEVER_CLICK_IDS = /^(next_path|previous_path)$/i;
function isPlainButton(el) {
  const tag = el.tagName;
  const isBtn = tag === "BUTTON" || tag === "INPUT" && el.type.toLowerCase() === "button";
  if (!isBtn) return false;
  if (el.disabled) return false;
  if (NEVER_CLICK_IDS.test(el.id)) return false;
  if (!isVisible(el)) return false;
  return true;
}
function isSafeAddButton(el, inDialog2) {
  if (!isPlainButton(el) || inDialog2) return false;
  if (!/add/i.test(el.id)) return false;
  return !NEVER_CLICK.test(buttonText(el));
}
function isSafeInlineAddButton(el) {
  if (el.ownerDocument.defaultView?.location.hostname.toLowerCase() !== "prson-srpel.apps.cic.gc.ca") return false;
  if (!isPlainButton(el)) return false;
  if (el.type !== "button") return false;
  if (el.closest('dialog, [role="dialog"], mat-dialog-container, .cdk-overlay-container')) return false;
  const text = buttonText(el);
  return /^add another$/i.test(text) && !NEVER_CLICK.test(text);
}
var PR_HOST2 = "prson-srpel.apps.cic.gc.ca";
var PR_PROFILE_PATH = /^\/en\/application\/profile\/\d+\/?$/i;
function onPrProfile(el) {
  const loc = el.ownerDocument.defaultView?.location;
  return loc?.hostname.toLowerCase() === PR_HOST2 && PR_PROFILE_PATH.test(loc.pathname);
}
var IN_DIALOG = 'dialog, [role="dialog"], [role="alertdialog"], mat-dialog-container, .cdk-overlay-container';
function isSafeDependantAddButton(el) {
  if (!onPrProfile(el)) return false;
  if (!isPlainButton(el)) return false;
  if (el.type !== "button") return false;
  if (el.closest(IN_DIALOG)) return false;
  const text = buttonText(el);
  return /^add dependant$/i.test(text) && !NEVER_CLICK.test(text);
}
function isSafeDependantSave(el, form) {
  if (!onPrProfile(el)) return false;
  if (!isPlainButton(el) || !form.contains(el)) return false;
  if (el.type !== "button") return false;
  if (el.closest(IN_DIALOG)) return false;
  const text = buttonText(el);
  return /^save details$/i.test(text) && !NEVER_CLICK.test(text);
}
function isSafeDialogSave(el, dialog) {
  if (!isPlainButton(el) || !dialog.contains(el)) return false;
  const text = buttonText(el);
  if (!/\bsave\b/i.test(text)) return false;
  return !/continue|next|submit|sign|pay|transmit|complete|consent|declar/i.test(text);
}
function isSafePagerButton(el, paginator) {
  if (!isPlainButton(el) || !paginator.contains(el)) return false;
  if (el.type !== "button") return false;
  if (paginator.tagName !== "MAT-PAGINATOR" || !!el.closest("mat-dialog-container, .cdk-overlay-container")) return false;
  return !NEVER_CLICK.test(buttonText(el));
}
function isSafeSaveAndContinue(el) {
  const loc = el.ownerDocument.defaultView?.location;
  if (!loc || loc.protocol !== "https:" || loc.hostname.toLowerCase() !== TRRT_HOST) return false;
  if (!isAutoAdvancePath(loc.pathname)) return false;
  if (el.tagName !== "BUTTON" || el.id !== "next_path") return false;
  const b = el;
  if (b.disabled || b.getAttribute("aria-disabled") === "true") return false;
  const type = (b.getAttribute("type") ?? "submit").toLowerCase();
  if (type !== "button" && type !== "submit") return false;
  if (el.closest(IN_DIALOG)) return false;
  if (!/^save and continue$/i.test(textWithoutIcons(el))) return false;
  return isVisible(el);
}
var ICON = "mat-icon, .material-icons";
function textWithoutIcons(el) {
  const copy = el.cloneNode(true);
  copy.querySelectorAll(ICON).forEach((i) => i.remove());
  return buttonText(copy);
}
function isVisible(el) {
  const view = el.ownerDocument.defaultView;
  if (!view) return false;
  for (let n = el; n; n = n.parentElement) {
    if (n.hidden) return false;
    if (view.getComputedStyle(n).display === "none") return false;
  }
  const v = view.getComputedStyle(el).visibility;
  if (v === "hidden" || v === "collapse") return false;
  const check = el.checkVisibility;
  if (typeof check === "function" && !check.call(el, { visibilityProperty: true, checkVisibilityCSS: true })) return false;
  return true;
}
function isSelectAwaitingOptions(el) {
  return el instanceof HTMLSelectElement && el.disabled && isVisible(el);
}

// src/executor/field-executor.ts
function resolveWritable(selector, root) {
  const target = resolveTarget(selector, root);
  if (target.status === "ambiguous") return { written: false, reason: "unsafe_target" };
  if (target.status !== "found") return { written: false, reason: "selector_missing" };
  if (!isSafeWriteTarget(target.el)) return { written: false, reason: "unsafe_target" };
  return target.el;
}
function setNative(input, value) {
  const proto = input instanceof HTMLTextAreaElement ? window.HTMLTextAreaElement.prototype : input instanceof HTMLSelectElement ? window.HTMLSelectElement.prototype : window.HTMLInputElement.prototype;
  const nativeSetter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
  if (nativeSetter) nativeSetter.call(input, value);
  else input.value = value;
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
  input.dispatchEvent(new Event("blur", { bubbles: true }));
}
function executeWrite(selector, value, root = document) {
  const el = resolveWritable(selector, root);
  if (!(el instanceof Element)) return el;
  setNative(el, value);
  return { written: true, node: el };
}
function optionLabel(text) {
  return optionKey(text);
}
function executeSelectByText(selector, text, root = document) {
  const el = resolveWritable(selector, root);
  if (!(el instanceof Element)) return el;
  if (!(el instanceof HTMLSelectElement)) return { written: false, reason: "unsafe_target" };
  const want = optionLabel(text);
  const hits = Array.from(el.options).filter((o) => optionLabel(o.text) === want);
  if (hits.length !== 1) return { written: false, reason: "selector_missing" };
  if (el.selectedIndex >= 0 && el.options[el.selectedIndex] === hits[0]) return { written: true, node: el };
  setNative(el, hits[0].value);
  return { written: true, node: el };
}
function listStillLoading(selector, text, root) {
  const target = resolveTarget(selector, root);
  if (target.status !== "found" || !(target.el instanceof HTMLSelectElement)) return false;
  const want = optionLabel(text);
  const hits = Array.from(target.el.options).filter((o) => optionLabel(o.text) === want).length;
  return hits === 0 || hits === 1 && target.el.disabled;
}
async function executeSelectByTextWhenListed(selector, text, root = document, waitMs = 8e3, intervalMs = 100, stillActive = () => true) {
  const deadline = Date.now() + waitMs;
  for (; ; ) {
    const out = executeSelectByText(selector, text, root);
    if (out.written || !listStillLoading(selector, text, root) || Date.now() >= deadline || !stillActive())
      return out;
    await new Promise((resolve) => setTimeout(resolve, intervalMs));
  }
}
function keepAllowsWrite(current, mapped) {
  const now = current.trim().normalize("NFC");
  const want = mapped.trim().normalize("NFC");
  if (now === "" || /^(?=.*_)[_/\s.-]+$/.test(now)) return true;
  if (now === want) return true;
  return /^null\s+/i.test(now) && now.replace(/^null\s+/i, "") === want;
}

// src/executor/readback.ts
async function readField(selector, writtenNode, settleMs = 250, root = document, mode = "value", answer = "") {
  await new Promise((resolve) => setTimeout(resolve, settleMs));
  const target = resolveTarget(selector, root);
  if (target.status !== "found") return { found: false, sameNode: false, value: "" };
  const el = target.el;
  const sameNode = writtenNode ? el === writtenNode : true;
  let raw;
  if (mode === "checked") {
    raw = el.checked ? answer : "";
  } else if (mode === "option") {
    const sel = el;
    const opt = sel.selectedIndex >= 0 ? sel.options[sel.selectedIndex] : void 0;
    const text = (opt?.text ?? "").replace(/\s+/g, " ").trim();
    raw = optionKey(text) === optionKey(answer) ? answer : text;
  } else {
    raw = el.value ?? "";
  }
  return { found: true, sameNode, value: raw.trim().normalize("NFC") };
}

// src/executor/row-match.ts
var ROW_FILLER = /* @__PURE__ */ new Set(["since", "born", "the", "and", "of", "to", "at", "now"]);
function rowSummaryPresent(summary, rows) {
  const norm = (t) => t.toLowerCase().replace(/[^a-z0-9\-]+/g, " ");
  const words = norm(summary).split(/\s+/).filter((w) => w.length >= 2 && !ROW_FILLER.has(w) && w !== "-");
  if (words.length < 2) return false;
  const need = /* @__PURE__ */ new Map();
  for (const w of words) need.set(w, (need.get(w) ?? 0) + 1);
  return rows.some((r) => {
    const have = /* @__PURE__ */ new Map();
    for (const w of norm(r).split(/\s+/)) have.set(w, (have.get(w) ?? 0) + 1);
    return [...need].every(([w, n]) => (have.get(w) ?? 0) >= n);
  });
}

// src/session-warning.ts
function sessionWarningShown(root = document) {
  return Array.from(root.querySelectorAll('mat-dialog-container, [role="dialog"]')).some(
    (d) => rendered(d) && /session timeout warning|your session (will|is about to) expire/i.test(
      d.innerText ?? d.textContent ?? ""
    )
  );
}
function rendered(el) {
  if (getComputedStyle(el).visibility === "hidden") return false;
  for (let e = el; e; e = e.parentElement) {
    if (e.hidden) return false;
    if (getComputedStyle(e).display === "none") return false;
  }
  return true;
}
var SESSION_CHECK_MS = 300;
var SESSION_POLL_MS = 5e3;
function watchSessionWarning(report, root = document.body) {
  let last = false;
  let pending;
  let obs;
  let poll;
  const stop = () => {
    obs?.disconnect();
    clearInterval(poll);
    clearTimeout(pending);
  };
  const check = () => {
    pending = void 0;
    try {
      const now = sessionWarningShown(document);
      if (now !== last) {
        last = now;
        report(now);
      }
    } catch {
      stop();
    }
  };
  const soon = () => {
    if (pending === void 0) pending = setTimeout(check, SESSION_CHECK_MS);
  };
  obs = new MutationObserver(soon);
  obs.observe(root, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["class", "style", "hidden"]
  });
  poll = setInterval(soon, SESSION_POLL_MS);
  check();
  return stop;
}

// src/executor/file-attach.ts
var UPLOAD_SELECTOR_PREFIX = "::upload:";
var UPLOAD_PAGE = "/doc-upload";
var UPLOAD_MAX_BYTES = 5 * 1024 * 1024;
var ALLOWED = {
  "application/pdf": ["pdf"],
  "image/jpeg": ["jpg", "jpeg"],
  "image/png": ["png"],
  "image/tiff": ["tif", "tiff"],
  "application/msword": ["doc"],
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ["docx"]
};
var FILE_NAME = /[\w()-]\.(pdf|jpe?g|png|tiff?|docx?)\b/i;
function isUploadSelector(selector) {
  return typeof selector === "string" && selector.startsWith(UPLOAD_SELECTOR_PREFIX);
}
function rowPattern(selector) {
  try {
    return new RegExp(selector.slice(UPLOAD_SELECTOR_PREFIX.length), "i");
  } catch {
    return null;
  }
}
function uploadRowOf(input) {
  let row = input;
  for (let el = input.parentElement; el && el !== document.body; el = el.parentElement) {
    if (el.querySelectorAll('input[type="file"]').length > 1) break;
    row = el;
  }
  return row;
}
function slotText(input, row, pr = false) {
  const unique = pr ? !!input.id && Array.from(document.querySelectorAll("[id]")).filter((e) => e.id === input.id).length === 1 : !!input.id;
  const byFor = unique ? Array.from(document.querySelectorAll("label[for]")).find((l) => l.htmlFor === input.id) : null;
  const parts = [byFor?.textContent ?? "", input.getAttribute("aria-label") ?? "", row.textContent ?? ""];
  return parts.join(" ").replace(/\s+/g, " ");
}
var PR_CASE_PAGE = /^\/(?:en|fr)\/application\/case\/\d+\/?$/i;
function onPrCasePage(path = location.pathname) {
  return PR_CASE_PAGE.test(path);
}
function onUploadPage(path = location.pathname) {
  return path === UPLOAD_PAGE || path.endsWith(UPLOAD_PAGE) || onPrCasePage(path);
}
function rowShown(row) {
  const view = row.ownerDocument.defaultView;
  if (!view) return false;
  for (let n = row; n; n = n.parentElement) {
    if (n.hidden) return false;
    if (view.getComputedStyle(n).display === "none") return false;
  }
  const v = view.getComputedStyle(row).visibility;
  if (v === "hidden" || v === "collapse") return false;
  const hasLayout = row.ownerDocument.documentElement.getClientRects().length > 0;
  if (hasLayout && row.getClientRects().length === 0) return false;
  return true;
}
function slotRowOf(input, pr) {
  if (pr) {
    const tr = input.closest("tr");
    if (tr && tr.querySelectorAll('input[type="file"]').length === 1) return tr;
  }
  return uploadRowOf(input);
}
function findUploadInput(selector, path) {
  if (!onUploadPage(path)) return { status: "wrong_page" };
  const re = rowPattern(selector);
  if (!re) return { status: "invalid" };
  const pr = onPrCasePage(path);
  const hits = [];
  for (const el of Array.from(document.querySelectorAll('input[type="file"]'))) {
    const input = el;
    if (input.disabled) continue;
    const row = slotRowOf(input, pr);
    if (pr && !rowShown(row)) continue;
    if (re.test(slotText(input, row, pr))) hits.push({ input, row });
  }
  if (hits.length === 0) return { status: "missing" };
  if (hits.length > 1) return { status: "ambiguous" };
  return { status: "found", ...hits[0] };
}
function slotHasFile(input, row) {
  if ((input.files?.length ?? 0) > 0) return true;
  if (onPrCasePage() && prAttachmentState(row) !== "empty") return true;
  const text = (row.textContent ?? "").replace(/\s+/g, " ");
  if (FILE_NAME.test(text)) return true;
  return Array.from(row.querySelectorAll("button, a")).some((b) => /\b(delete|remove)\b/i.test(b.textContent ?? ""));
}
function extensionOf(name) {
  const m = /\.([a-z0-9]+)$/i.exec(name);
  return m ? m[1].toLowerCase() : "";
}
async function sha256Hex(bytes) {
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function checkFile(file) {
  if (!file || typeof file.base64 !== "string" || typeof file.name !== "string") return { ok: false, reason: "no_file" };
  const exts = ALLOWED[file.mimeType];
  if (!exts || !exts.includes(extensionOf(file.name))) return { ok: false, reason: "type" };
  let bytes;
  try {
    const bin = atob(file.base64);
    bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  } catch {
    return { ok: false, reason: "encoding" };
  }
  if (bytes.length === 0 || bytes.length > UPLOAD_MAX_BYTES || bytes.length !== file.size) return { ok: false, reason: "size" };
  if (await sha256Hex(bytes) !== String(file.sha256).toLowerCase()) return { ok: false, reason: "hash" };
  return { ok: true, bytes };
}
function prAttachmentState(row) {
  const cells = row.querySelectorAll(".documents-upload-table__attachment");
  if (cells.length !== 1) return "missing";
  const cell = cells[0];
  return (cell.textContent ?? "").trim() === "" && cell.children.length === 0 ? "empty" : "filled";
}
function prAttachmentShows(row, fileName) {
  const cells = row.querySelectorAll(".documents-upload-table__attachment");
  return cells.length === 1 && (cells[0].textContent ?? "").includes(fileName);
}
function inputAccepts(input, file) {
  const accept = (input.getAttribute("accept") ?? "").trim();
  if (!accept) return true;
  const mime = file.mimeType.toLowerCase();
  const ext = extensionOf(file.name);
  return accept.split(",").map((t) => t.trim().toLowerCase()).filter(Boolean).some((t) => t.startsWith(".") ? t.slice(1) === ext : t.endsWith("/*") ? mime.startsWith(t.slice(0, -1)) : t === mime);
}
function setFile(input, file, bytes) {
  if (input.type !== "file") return false;
  const f = new File([bytes], file.name, { type: file.mimeType });
  const dt = new DataTransfer();
  dt.items.add(f);
  input.files = dt.files;
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}
function fileTaken(input, row, file) {
  const held = input.files?.[0];
  if (held && held.name === file.name && held.size === file.size) return true;
  return (row.textContent ?? "").includes(file.name);
}
function requiredUploads(path) {
  if (!onUploadPage(path)) return [];
  if (onPrCasePage(path)) return prRequiredUploads();
  const out = [];
  for (const el of Array.from(document.querySelectorAll('input[type="file"][id^="req_upload"]'))) {
    const row = el.closest("tr") ?? uploadRowOf(el);
    const label = row.querySelector("a.collapsible");
    const name = (label ? Array.from(label.childNodes).filter((n) => !(n.nodeType === 1 && n.tagName === "MAT-ICON")).map((n) => n.textContent ?? "").join(" ") : "").replace(/\s+/g, " ").trim();
    const status = (row.querySelector("td")?.textContent ?? "").replace(/\s+/g, " ");
    const uploaded = /not uploaded/i.test(status) ? false : /uploaded/i.test(status) || slotHasFile(el, row);
    out.push({ name: name || "A required document", uploaded });
  }
  return out;
}
function prRequiredUploads() {
  const out = [];
  const seen2 = /* @__PURE__ */ new Set();
  for (const el of Array.from(document.querySelectorAll('input[type="file"]'))) {
    const input = el;
    const row = slotRowOf(input, true);
    if (seen2.has(row) || !rowShown(row)) continue;
    seen2.add(row);
    const text = (row.textContent ?? "").replace(/\s+/g, " ").trim();
    const m = /^(.*?)\(required\)/i.exec(text);
    if (!m) continue;
    const name = m[1].replace(/^[\s*]+/, "").replace(/\s+/g, " ").trim();
    out.push({ name: name || "A required document", uploaded: slotHasFile(input, row) });
  }
  return out;
}

// src/executor/dependant-match.ts
var squash2 = (t) => (t ?? "").replace(/\s+/g, " ").trim();
var normText = (t) => squash2(t).toLowerCase();
var normDate = (t) => normText(t).replace(/\s*[-./]\s*/g, "/");
var FIELDS = [
  ["name", "name"],
  ["family", "family name"],
  ["dob", "date of birth"],
  ["relationship", "relationship"],
  ["accompanying", "accompanying"]
];
function parseReviewedDependant(value) {
  const parts = /* @__PURE__ */ new Map();
  for (const part of value.split(";")) {
    const m = /^\s*([^:]+):\s*(.*?)\s*$/.exec(part);
    if (!m) return null;
    parts.set(normText(m[1]), squash2(m[2]));
  }
  const out = {};
  for (const [k, label] of FIELDS) {
    const v = parts.get(label);
    if (!v) return null;
    out[k] = v;
  }
  return out;
}
function readDependantCards(doc = document) {
  return Array.from(doc.querySelectorAll("pra-dependant-card")).map((card) => {
    const out = {};
    for (const h of Array.from(card.querySelectorAll("h5"))) {
      const key = normText(h.textContent);
      const value = h.nextElementSibling;
      if (key && value && value.tagName !== "H5" && !(key in out)) out[key] = squash2(value.textContent);
    }
    return out;
  });
}
var sameName = (c, d) => normText(c["name"]) === normText(d.name);
var sameDob = (c, d) => !!c["date of birth"] && normDate(c["date of birth"]) === normDate(d.dob);
function cardIsDependant(c, d) {
  return sameName(c, d) && sameDob(c, d) && normText(c["relationship"]) === normText(d.relationship) && normText(c["accompanying"]) === normText(d.accompanying);
}
function dependantCardVerdict(cards, d) {
  if (cards.some((c) => cardIsDependant(c, d))) return "present";
  if (cards.some((c) => sameName(c, d) && sameDob(c, d))) return "differs";
  return cards.some((c) => sameDob(c, d)) ? "conflict" : "absent";
}

// src/executor/control-actuator.ts
function chooseRadio(el) {
  if (!isSafeChoiceTarget(el, "radio")) return { done: false, reason: "unsafe_target" };
  const input = el;
  if (!input.checked) input.click();
  return { done: true, node: el };
}
function ensureChecked(el) {
  if (!isSafeChoiceTarget(el, "checkbox")) return { done: false, reason: "unsafe_target" };
  const input = el;
  if (!input.checked) input.click();
  return { done: true, node: el };
}
function openRowDialog(el) {
  if (!isSafeAddButton(el, inDialog(el))) return { done: false, reason: "unsafe_target" };
  el.click();
  return { done: true, node: el };
}
function findInlineAddButton() {
  const hits = Array.from(document.querySelectorAll("button")).filter((b) => isSafeInlineAddButton(b));
  if (hits.length === 0) return { done: false, reason: "selector_missing" };
  if (hits.length > 1) return { done: false, reason: "unsafe_target" };
  return { done: true, node: hits[0] };
}
function addInlineRow(el) {
  if (!isSafeInlineAddButton(el)) return { done: false, reason: "unsafe_target" };
  el.click();
  return { done: true, node: el };
}
var DEPENDANT_ADD = "::dependant-add";
var DEPENDANT_SAVE = "::dependant-save";
function findDependantAddButton() {
  const hits = Array.from(document.querySelectorAll("button")).filter((b) => isSafeDependantAddButton(b));
  if (hits.length === 0) return { done: false, reason: "selector_missing" };
  if (hits.length > 1) return { done: false, reason: "unsafe_target" };
  return { done: true, node: hits[0] };
}
function openDependantForm(el) {
  if (!isSafeDependantAddButton(el)) return { done: false, reason: "unsafe_target" };
  el.click();
  return { done: true, node: el };
}
function findDependantSave() {
  const form = dependantForm();
  if (!form) return { done: false, reason: "selector_missing" };
  const hits = Array.from(form.querySelectorAll("button")).filter((b) => /^save details$/i.test(buttonText(b)));
  if (hits.length === 0) return { done: false, reason: "selector_missing" };
  if (hits.length > 1) return { done: false, reason: "unsafe_target" };
  return { done: true, node: hits[0] };
}
function saveDependantForm(el) {
  const form = dependantForm();
  if (!form || !isSafeDependantSave(el, form)) return { done: false, reason: "unsafe_target" };
  el.click();
  return { done: true, node: el };
}
var DIALOG_SAVE = "::dialog-save";
function findDialogSave(selector) {
  const dialog = topDialog();
  if (!dialog) return { done: false, reason: "selector_missing" };
  let el = null;
  if (selector === DIALOG_SAVE) {
    const hits = Array.from(dialog.querySelectorAll("button")).filter((b) => /\bsave\b/i.test(buttonText(b)));
    if (hits.length === 0) return { done: false, reason: "selector_missing" };
    if (hits.length > 1) return { done: false, reason: "unsafe_target" };
    el = hits[0];
  } else {
    const r = resolveTarget(selector, dialog);
    if (r.status === "ambiguous") return { done: false, reason: "unsafe_target" };
    if (r.status !== "found") return { done: false, reason: "selector_missing" };
    el = r.el;
  }
  if (!isSafeDialogSave(el, dialog)) return { done: false, reason: "unsafe_target" };
  return { done: true, node: el };
}
function saveRowDialog(el) {
  const dialog = topDialog();
  if (!dialog || !isSafeDialogSave(el, dialog)) return { done: false, reason: "unsafe_target" };
  el.click();
  return { done: true, node: el };
}
async function turnPage(p, which) {
  const b = pageNav(p, which);
  if (navOff(b)) return false;
  if (!isSafePagerButton(b, p)) throw new Error("unsafe pager button");
  const before = rangeLabel(p);
  b.click();
  return waitUntil(() => rangeLabel(p) !== before, 2e3, 50);
}
async function toFirstPage(p) {
  if (pageNav(p, "first")) {
    await turnPage(p, "first");
    return;
  }
  for (let i = 0; i < 50 && await turnPage(p, "previous"); i++) ;
}
async function allPageRowTexts() {
  const out = pageRowTexts();
  for (const p of gridPaginators()) {
    if (navOff(pageNav(p, "next")) && navOff(pageNav(p, "previous")) && navOff(pageNav(p, "first"))) continue;
    await toFirstPage(p);
    out.push(...pageRowTexts());
    for (let i = 0; i < 50 && await turnPage(p, "next"); i++) out.push(...pageRowTexts());
    await toFirstPage(p);
  }
  return out;
}
var pressedOnPath = null;
function pressSaveAndContinue() {
  const hits = document.querySelectorAll("#next_path");
  if (hits.length === 0) return { done: false, reason: "selector_missing" };
  if (hits.length > 1) return { done: false, reason: "unsafe_target" };
  const el = hits[0];
  if (topDialog()) return { done: false, reason: "unsafe_target" };
  if (!isSafeSaveAndContinue(el)) return { done: false, reason: "unsafe_target" };
  const path = el.ownerDocument.defaultView?.location.pathname ?? null;
  if (!path || path === pressedOnPath) return { done: false, reason: "unsafe_target" };
  pressedOnPath = path;
  el.click();
  return { done: true, node: el };
}

// src/executor/advance-check.ts
var ROWS_STABLE_MS = 3e3;
var SETTLE_MAX_MS = 2e4;
function shown(el) {
  for (let n = el; n; n = n.parentElement) {
    if (n.hidden) return false;
    const cs = getComputedStyle(n);
    if (cs.display === "none") return false;
  }
  const v = getComputedStyle(el).visibility;
  return v !== "hidden" && v !== "collapse";
}
var squash3 = (s) => (s ?? "").replace(/\s+/g, " ").trim();
var ERROR_SELECTOR = [
  "mat-error",
  ".error",
  '[class*="error-message"]',
  ".mat-error",
  ".mat-mdc-form-field-error",
  '[role="alert"]',
  ".alert-danger",
  ".alert-error",
  ".error-summary",
  ".label-danger",
  ".invalid-feedback",
  ".help-block.error"
].join(", ");
var UNSEEN = '.wb-inv, [aria-hidden="true"], script, style, noscript, template';
function textOf(el) {
  return squash3(el.innerText ?? el.textContent);
}
var ERROR_PREFIX = /^\s*error\s*:/i;
var seen = (el) => shown(el) && !el.closest(UNSEEN);
function irccErrors(root = document) {
  const out = [];
  const add = (t) => {
    if (t && !out.some((o) => o === t || o.includes(t) || t.includes(o))) out.push(t);
  };
  for (const el of Array.from(root.querySelectorAll(ERROR_SELECTOR))) {
    if (!seen(el)) continue;
    add(textOf(el));
  }
  const scope = root.querySelector?.("main") ?? (root instanceof Element ? root : null) ?? document.body;
  if (scope) {
    const starts = (el) => ERROR_PREFIX.test(el.textContent ?? "");
    for (const el of Array.from(scope.querySelectorAll("*"))) {
      if (!starts(el)) continue;
      const parent = el.parentElement;
      if (parent && parent !== scope && scope.contains(parent) && starts(parent)) continue;
      if (!seen(el)) continue;
      add(textOf(el).slice(0, 300));
    }
  }
  for (const el of Array.from(root.querySelectorAll('[aria-invalid="true"]'))) {
    if (!shown(el)) continue;
    const t = `Not accepted: ${squash3(questionText(el)) || el.id || "a field"}`;
    if (!out.includes(t)) out.push(t);
  }
  return out;
}
function emptyRequired(root = document) {
  const out = [];
  const label = (el) => squash3(questionText(el)).split("\n")[0] || el.id || "a required question";
  const radiosDone = /* @__PURE__ */ new Set();
  for (const el of Array.from(root.querySelectorAll("input, select, textarea"))) {
    const c = el;
    const required = c.required || c.getAttribute("aria-required") === "true";
    if (!required || c.disabled || !shown(el)) continue;
    const type = (c.type || "").toLowerCase();
    if (type === "hidden" || type === "button" || type === "submit" || type === "file") continue;
    if (type === "radio") {
      const name = c.name;
      if (!name || radiosDone.has(name)) continue;
      radiosDone.add(name);
      const group = Array.from(root.querySelectorAll(`input[type="radio"]`)).filter(
        (r) => r.name === name
      );
      if (!group.some((r) => r.checked)) out.push(label(el));
      continue;
    }
    if (type === "checkbox") continue;
    if (squash3(c.value) === "") out.push(label(el));
  }
  for (const m of Array.from(root.querySelectorAll('mat-select, [role="combobox"].mat-mdc-select, [role="combobox"].mat-select'))) {
    const required = m.getAttribute("aria-required") === "true" || m.hasAttribute("required") || /\bmat(-mdc)?-select-required\b/.test(m.className);
    if (!required || m.getAttribute("aria-disabled") === "true" || !shown(m)) continue;
    const valueText = m.querySelector(".mat-select-value-text, .mat-mdc-select-value-text");
    const empty = /\bmat(-mdc)?-select-empty\b/.test(m.className) || !valueText || squash3(valueText.textContent) === "";
    if (!empty) continue;
    const t = squash3(questionText(m)).split("\n")[0] || m.id || "a required question";
    if (!out.includes(t)) out.push(t);
  }
  for (const g of Array.from(root.querySelectorAll('[role="radiogroup"][aria-required="true"], mat-radio-group[required]'))) {
    if (!shown(g)) continue;
    const inputs = Array.from(g.querySelectorAll('input[type="radio"]'));
    if (inputs.length && !inputs.some((r) => r.checked)) {
      const t = squash3(g.getAttribute("aria-label")) || label(inputs[0]);
      if (!out.includes(t)) out.push(t);
    }
  }
  return out;
}
function pageBusy(root = document) {
  return Array.from(
    root.querySelectorAll('mat-spinner, mat-progress-spinner, mat-progress-bar, .cdk-overlay-backdrop, [aria-busy="true"]')
  ).some(shown);
}
function snapshot() {
  const dialogOpen = topDialog() !== null;
  const busy = pageBusy();
  const rows = pageRowTotal();
  return { key: `${dialogOpen}|${busy}|${rows}`, dialogOpen, busy, rows };
}
async function advanceCheck(stableMs = ROWS_STABLE_MS, maxMs = SETTLE_MAX_MS) {
  let last = snapshot();
  let since = Date.now();
  const settled = await waitUntil(
    () => {
      const now = snapshot();
      if (now.key !== last.key) {
        last = now;
        since = Date.now();
        return false;
      }
      return !now.dialogOpen && !now.busy && Date.now() - since >= stableMs;
    },
    maxMs,
    250
  );
  return {
    settled,
    dialogOpen: last.dialogOpen,
    busy: last.busy,
    rows: last.rows,
    errors: irccErrors(),
    required: emptyRequired(),
    sessionWarning: sessionWarningShown(document)
  };
}
function pageStillClean(rows) {
  const now = snapshot();
  if (now.dialogOpen) return "a dialog is open";
  if (now.busy) return "the page is still loading";
  if (now.rows !== rows) return "rows were still being added";
  if (irccErrors().length) return "IRCC shows a message";
  if (emptyRequired().length) return "a required question is empty";
  if (sessionWarningShown(document)) return "IRCC is about to sign you out";
  return null;
}

// src/content.ts
var LOADED_FLAG = "__visaaiPortalAssistantLoaded";
var alreadyLoaded = globalThis[LOADED_FLAG] === true;
globalThis[LOADED_FLAG] = true;
if (!alreadyLoaded) chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id) return false;
  if (msg.type === "readback") {
    sendResponse(readbackFields(msg.selectors, msg.ops, msg.awaitOptions));
    return true;
  }
  if (msg.type === "screen-questions") {
    sendResponse(screenSignature());
    return true;
  }
  if (msg.type === "page-rows") {
    sendResponse(pageRowTexts());
    return true;
  }
  if (msg.type === "upload-status") {
    sendResponse(requiredUploads());
    return true;
  }
  if (msg.type === "advance-check") {
    void advanceCheck().then(sendResponse).catch(() => sendResponse(null));
    return true;
  }
  if (msg.type === "advance-press") {
    if (typeof msg.path !== "string" || location.pathname !== msg.path) {
      sendResponse({ pressed: false, reason: "the page changed" });
      return true;
    }
    const dirty = pageStillClean(typeof msg.rows === "number" ? msg.rows : -1);
    if (dirty) {
      sendResponse({ pressed: false, reason: dirty });
      return true;
    }
    const r = pressSaveAndContinue();
    sendResponse(r.done ? { pressed: true } : { pressed: false, reason: r.reason });
    return true;
  }
  if (msg.type === "portal-fill-dry") {
    if (!isPortalFillProtocolCompatible(msg.command.protocol)) {
      sendResponse({ ok: false, detail: "protocol_mismatch" });
      return true;
    }
    void dryRunField(msg.command).then(sendResponse).catch(() => sendResponse({ ok: false, detail: "dry_run_failed" }));
    return true;
  }
  if (msg.type === "execute-field-intent") {
    void runFieldIntent(msg.command).then(sendResponse).catch(
      () => sendResponse({
        protocol: PORTAL_FILL_PROTOCOL_VERSION,
        kind: "field_result",
        executionId: msg.command?.executionId ?? "",
        fieldKey: msg.command?.fieldKey ?? "",
        outcome: "failed",
        reason: "dom_change",
        selectorFound: false
      })
    );
    return true;
  }
  if (msg.type === "field-readback") {
    void readField(msg.selector, void 0).then(
      (rb) => sendResponse({ selector: msg.selector, value: rb.value, found: rb.found })
    ).catch(() => sendResponse({ selector: msg.selector, value: "", found: false }));
    return true;
  }
  if (msg.type === "execute-step") {
    sendResponse({ ok: false, detail: "LEGACY_EXECUTION_DEPRECATED" });
    return true;
  }
  return false;
});
var APPEAR_MS = 5e3;
var PR_UPLOAD_MS = 3e4;
var OPTIONS_MS = 8e3;
var rowAlreadyPresent = false;
var dependantAlreadyPresent = false;
async function runFieldIntent(cmd) {
  const base = {
    protocol: PORTAL_FILL_PROTOCOL_VERSION,
    kind: "field_result",
    executionId: cmd.executionId,
    fieldKey: cmd.fieldKey
  };
  const failed = (reason, selectorFound = false) => ({
    ...base,
    outcome: "failed",
    reason,
    selectorFound
  });
  if (!isPortalFillProtocolCompatible(cmd.protocol)) return failed("dom_change");
  if (cmd.op === "attach_file") {
    rowAlreadyPresent = false;
    const t = findUploadInput(cmd.selector);
    if (t.status === "ambiguous") return failed("unsafe_target");
    if (t.status !== "found") return failed("selector_missing");
    if (onPrCasePage()) {
      if (prAttachmentState(t.row) !== "empty" || (t.input.files?.length ?? 0) > 0) return failed("unsafe_target", true);
      const checked2 = await checkFile(cmd.file);
      if (!checked2.ok) return failed("controlled_rejected", true);
      if (!inputAccepts(t.input, cmd.file)) return failed("controlled_rejected", true);
      if (!setFile(t.input, cmd.file, checked2.bytes)) return failed("unsafe_target", true);
      if (!await waitUntil(() => prAttachmentShows(t.row, cmd.file.name), PR_UPLOAD_MS))
        return failed("controlled_rejected", true);
      return verified(base, cmd.mappedValue, cmd.expectedValueHash);
    }
    if (slotHasFile(t.input, t.row)) return verified(base, cmd.mappedValue, cmd.expectedValueHash);
    const checked = await checkFile(cmd.file);
    if (!checked.ok) return failed("controlled_rejected", true);
    if (!setFile(t.input, cmd.file, checked.bytes)) return failed("unsafe_target", true);
    const took = await waitUntil(() => fileTaken(t.input, t.row, cmd.file), APPEAR_MS);
    if (!took) return failed("controlled_rejected", true);
    return verified(base, cmd.mappedValue, cmd.expectedValueHash);
  }
  if (cmd.op === "row_add") {
    rowAlreadyPresent = false;
    dependantAlreadyPresent = false;
    return addRow(cmd, base, failed);
  }
  if (cmd.op === "dependant_open") {
    rowAlreadyPresent = false;
    dependantAlreadyPresent = false;
    return openDependant(cmd, base, failed);
  }
  if (dependantAlreadyPresent && (cmd.op === "dependant_save" || parseScopedSelector(cmd.selector)?.dependant)) {
    if (cmd.op === "dependant_save") dependantAlreadyPresent = false;
    return verified(base, cmd.mappedValue, cmd.expectedValueHash);
  }
  dependantAlreadyPresent = false;
  if (cmd.op === "dependant_save") {
    rowAlreadyPresent = false;
    return saveDependant(cmd, base, failed);
  }
  if (rowAlreadyPresent && (cmd.dialog || cmd.op === "dialog_save")) {
    if (cmd.op === "dialog_save") rowAlreadyPresent = false;
    return verified(base, cmd.mappedValue, cmd.expectedValueHash);
  }
  rowAlreadyPresent = false;
  const scope = () => cmd.dialog ? topDialog() : document;
  const root = scope();
  if (!root) return failed("selector_missing");
  let readMode = "value";
  let node;
  if (cmd.op === "dialog_save") {
    const found = findDialogSave(cmd.selector);
    if (!found.done) return failed(found.reason);
    const before = pageRowTotal();
    const beforeRows = pageRowTexts();
    const summaryBefore = rowSummaryPresent(cmd.mappedValue, beforeRows);
    const saved = saveRowDialog(found.node);
    if (!saved.done) return failed(saved.reason, true);
    const rowAdded = () => {
      if (pageRowTotal() > before) return true;
      const after = pageRowTexts();
      if (!summaryBefore && rowSummaryPresent(cmd.mappedValue, after)) return true;
      return after.some((t) => t.trim() !== "" && !beforeRows.includes(t));
    };
    const ok = await waitUntil(() => !topDialog() && rowAdded(), APPEAR_MS);
    if (!ok) return failed("controlled_rejected", true);
    return verified(base, cmd.mappedValue, cmd.expectedValueHash);
  }
  const valueWrite = !cmd.op || cmd.op === "select_text";
  const writable = (el) => isSafeWriteTarget(el) || cmd.awaitOptions === true && cmd.op === "select_text" && isSelectAwaitingOptions(el);
  const target = cmd.reveal || cmd.dialog || cmd.op === "dialog_open" ? await waitForTarget(cmd.selector, scope, APPEAR_MS, 100, valueWrite ? writable : void 0) : resolveTarget(cmd.selector, root);
  if (target.status === "ambiguous") return failed("unsafe_target");
  if (target.status !== "found") return failed("selector_missing");
  const here = scope() ?? document;
  if (cmd.op === "dialog_open") {
    let present = false;
    if (!topDialog()) {
      present = rowSummaryPresent(cmd.mappedValue, pageRowTexts());
      if (!present) {
        try {
          present = rowSummaryPresent(cmd.mappedValue, await allPageRowTexts());
        } catch {
          return failed("unsafe_target");
        }
      }
    }
    if (present) {
      rowAlreadyPresent = true;
      return verified(base, cmd.mappedValue, cmd.expectedValueHash);
    }
    let addButton = target.el;
    if (!isSafeAddButton(addButton, inDialog(addButton)) && addButton.disabled) {
      await waitUntil(() => {
        const r = resolveTarget(cmd.selector);
        if (r.status !== "found" || !isSafeAddButton(r.el, inDialog(r.el))) return false;
        addButton = r.el;
        return true;
      }, APPEAR_MS);
    }
    const opened = openRowDialog(addButton);
    if (!opened.done) return failed(opened.reason, true);
    if (!await waitUntil(() => topDialog() !== null, APPEAR_MS)) return failed("dom_change", true);
    return verified(base, cmd.mappedValue, cmd.expectedValueHash);
  }
  if (cmd.op === "radio" || cmd.op === "check") {
    const act = cmd.op === "radio" ? chooseRadio(target.el) : ensureChecked(target.el);
    if (!act.done) return failed(act.reason, true);
    node = act.node;
    readMode = "checked";
  } else {
    if (parseScopedSelector(cmd.selector)?.keep && !cmd.op) {
      const el = target.el;
      if (!keepAllowsWrite(el.value ?? "", cmd.mappedValue)) return failed("value_mismatch", true);
    }
    const w = cmd.op === "select_text" ? (
      // Only a select the mapping marks as loading late waits for its
      // option (eTA job title); every other select answers at once.
      cmd.awaitOptions ? await executeSelectByTextWhenListed(
        cmd.selector,
        cmd.mappedValue,
        here,
        OPTIONS_MS,
        100,
        () => Boolean(chrome.runtime?.id)
      ) : executeSelectByText(cmd.selector, cmd.mappedValue, here)
    ) : executeWrite(cmd.selector, cmd.mappedValue, here);
    if (!w.written) return failed(w.reason ?? "selector_missing");
    node = w.node;
    if (cmd.op === "select_text") readMode = "option";
  }
  const rb = await readField(cmd.selector, node, 250, scope() ?? document, readMode, cmd.mappedValue);
  if (!rb.found) return failed("selector_missing");
  if (!rb.sameNode) return failed("portal_mutation", true);
  const v = await verifyField(rb.value, cmd.expectedValueHash);
  if (v.outcome !== "verified") return { ...base, outcome: v.outcome, reason: v.reason, selectorFound: true };
  return { ...base, outcome: v.outcome, actualValueHash: v.actualValueHash, selectorFound: true };
}
async function verified(base, mappedValue, expectedValueHash) {
  const v = await verifyField(mappedValue, expectedValueHash);
  if (v.outcome !== "verified") return { ...base, outcome: "failed", reason: v.reason, selectorFound: true };
  return { ...base, outcome: "verified", actualValueHash: v.actualValueHash, selectorFound: true };
}
async function addRow(cmd, base, failed) {
  if (tooManyRows(cmd.selector)) return failed("unsafe_target", true);
  const here = resolveTarget(cmd.selector);
  if (here.status === "found") return verified(base, cmd.mappedValue, cmd.expectedValueHash);
  if (here.status === "ambiguous" || here.status === "invalid") return failed("unsafe_target");
  const add = rowAddable(cmd.selector);
  if (!add.done) return failed(add.reason);
  const clicked = addInlineRow(add.node);
  if (!clicked.done) return failed(clicked.reason, true);
  const appeared = await waitUntil(() => resolveTarget(cmd.selector).status === "found", APPEAR_MS);
  if (!appeared) return failed("dom_change", true);
  return verified(base, cmd.mappedValue, cmd.expectedValueHash);
}
var SAVE_ENABLE_MS = 2e3;
async function openDependant(cmd, base, failed) {
  if (cmd.selector !== DEPENDANT_ADD) return failed("unsafe_target");
  const reviewed = parseReviewedDependant(cmd.mappedValue);
  if (!reviewed) return failed("unsafe_target");
  const verdict = dependantCardVerdict(readDependantCards(), reviewed);
  if (verdict === "present") {
    dependantAlreadyPresent = true;
    return verified(base, cmd.mappedValue, cmd.expectedValueHash);
  }
  if (verdict === "differs") return failed("value_mismatch", true);
  if (verdict === "conflict") return failed("unsafe_target", true);
  const open = dependantForm();
  if (open) {
    if (dependantFormHasValues(open)) return failed("unsafe_target", true);
    return verified(base, cmd.mappedValue, cmd.expectedValueHash);
  }
  if (document.querySelector("#dependantForm-relationship")) return failed("unsafe_target", true);
  let add = findDependantAddButton();
  if (!add.done && add.reason === "selector_missing")
    await waitUntil(() => {
      add = findDependantAddButton();
      return add.done || add.reason !== "selector_missing";
    }, APPEAR_MS);
  if (!add.done) return failed(add.reason);
  const clicked = openDependantForm(add.node);
  if (!clicked.done) return failed(clicked.reason, true);
  if (!await waitUntil(() => dependantForm() !== null, APPEAR_MS)) return failed("dom_change", true);
  return verified(base, cmd.mappedValue, cmd.expectedValueHash);
}
async function saveDependant(cmd, base, failed) {
  if (cmd.selector !== DEPENDANT_SAVE) return failed("unsafe_target");
  const reviewed = parseReviewedDependant(cmd.mappedValue);
  if (!reviewed) return failed("unsafe_target");
  const found = findDependantSave();
  if (!found.done) return failed(found.reason);
  const button = found.node;
  if (button.disabled)
    await waitUntil(() => {
      const form = dependantForm();
      return !!form && isSafeDependantSave(button, form);
    }, SAVE_ENABLE_MS);
  if (button.disabled) return failed("controlled_rejected", true);
  const saved = saveDependantForm(button);
  if (!saved.done) return failed(saved.reason, true);
  const ok = await waitUntil(
    () => dependantForm() === null && readDependantCards().some((c) => cardIsDependant(c, reviewed)),
    APPEAR_MS
  );
  if (!ok) return failed("controlled_rejected", true);
  return verified(base, cmd.mappedValue, cmd.expectedValueHash);
}
function tooManyRows(selector) {
  const max = parseScopedSelector(selector)?.rows;
  if (max === void 0) return false;
  const extra = rowSelector(selector, max);
  return !!extra && resolveTarget(extra).status === "found";
}
function rowAddable(selector) {
  const row = rowIndexOf(selector);
  if (row === null || row < 1) return { done: false, reason: "unsafe_target" };
  if (!scopesHold(selector)) return { done: false, reason: "selector_missing" };
  const previous = rowSelector(selector, row - 1);
  if (!previous || resolveTarget(previous).status !== "found") return { done: false, reason: "selector_missing" };
  const after = rowSelector(selector, row + 1);
  if (!after || resolveTarget(after).status !== "missing") return { done: false, reason: "unsafe_target" };
  return findInlineAddButton();
}
function presentFor(el, op, awaitOptions = false) {
  if (awaitOptions && op === "select_text" && isSelectAwaitingOptions(el)) return true;
  if (op === "radio") return isSafeChoiceTarget(el, "radio");
  if (op === "check") return isSafeChoiceTarget(el, "checkbox");
  if (op === "dialog_open") return isSafeAddButton(el, inDialog(el));
  return isSafeWriteTarget(el);
}
function readbackFields(selectors, ops, awaitOptions) {
  return selectors.map((selector, i) => {
    const op = ops?.[i] ?? null;
    if (op === "dialog_save" || selector === DIALOG_SAVE) return { selector, value: "", found: false };
    if (op === "dependant_save" || selector === DEPENDANT_SAVE) return { selector, value: "", found: false };
    if (op === "dependant_open")
      return { selector, value: "", found: findDependantAddButton().done || dependantForm() !== null };
    if (op === "attach_file" || isUploadSelector(selector)) {
      const t = findUploadInput(selector);
      return t.status === "ambiguous" ? { selector, value: "", found: false, ambiguous: true } : { selector, value: "", found: t.status === "found" };
    }
    if (op === "row_add") {
      const t = resolveTarget(selector);
      if (t.status === "ambiguous") return { selector, value: "", found: false, ambiguous: true };
      return { selector, value: "", found: t.status === "found" || rowAddable(selector).done };
    }
    const target = resolveTarget(selector);
    if (target.status === "ambiguous") return { selector, value: "", found: false, ambiguous: true };
    if (target.status === "no_option") return { selector, value: "", found: false, optionMissing: true };
    if (target.status !== "found") return { selector, value: "", found: false };
    if (!presentFor(target.el, op, awaitOptions?.[i] === true)) return { selector, value: "", found: false };
    if (op) return { selector, value: "", found: true };
    const el = target.el;
    return { selector, value: el.value ?? "", found: true };
  });
}
function screenSignature() {
  const labels = [];
  const ids = [];
  for (const el of Array.from(document.querySelectorAll("select, input, textarea"))) {
    const type = (el.type || "").toLowerCase();
    if (["hidden", "submit", "button", "image", "reset"].includes(type)) continue;
    const q = questionText(el);
    if (q && !labels.includes(q)) labels.push(q);
    const id = el.getAttribute("name") ?? el.id;
    if (id && !ids.includes(id)) ids.push(id);
  }
  if (labels.length === 0 && ids.length === 0) return [];
  return [...labels, `controls:${ids.join(",")}`, `text:${textHash(signatureText())}`];
}
var TRANSIENT = '[role="alert"], .alert, .label-danger, [class*="error"]';
function signatureText() {
  const gone = Array.from(document.querySelectorAll(TRANSIENT)).map((e) => e.textContent ?? "");
  let t = screenText();
  for (const g of gone) {
    const s = g.replace(/\s+/g, " ").trim();
    if (s) t = t.split(s).join(" ");
  }
  return t.replace(/\s+/g, " ").trim();
}
function textHash(text) {
  let h = 2166136261;
  for (let i = 0; i < text.length; i += 1) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16).padStart(8, "0");
}
if (!alreadyLoaded && document.body && chrome.runtime?.id)
  watchSessionWarning((shown2) => {
    void chrome.runtime?.sendMessage({ type: "portal-session-warning", shown: shown2 })?.catch(() => {
    });
  });
//# sourceMappingURL=content.js.map
